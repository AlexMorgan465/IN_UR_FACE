﻿param([ValidateSet('Agent','Manager','Tous')][string]$Cible='Tous')
$ErrorActionPreference='Stop'
try {
 $framework=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
 $csc=Join-Path $framework 'csc.exe'
 if(!(Test-Path $csc)){throw 'csc.exe .NET Framework introuvable'}
 $rel=(Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full').Release
 if($rel -lt 528040){throw '.NET Framework 4.8 requis'}
 $refs=@('System.dll','System.Core.dll','System.Xml.dll','System.Web.Extensions.dll','System.Xaml.dll','Microsoft.CSharp.dll') | ForEach-Object {Join-Path $framework $_}
 $refs+=@('WindowsBase.dll','PresentationCore.dll','PresentationFramework.dll') | ForEach-Object {Join-Path (Join-Path $framework 'WPF') $_}
 foreach($r in $refs){if(!(Test-Path $r)){throw "Reference manquante: $r"}}
 $roles=if($Cible -eq 'Tous'){@('Agent','Manager')}else{@($Cible)}
 foreach($role in $roles){
  $dir=Join-Path $PSScriptRoot $role
  $out=Join-Path $dir 'bin'
  New-Item -ItemType Directory -Force -Path $out | Out-Null
  $exe=Join-Path $out "Cofidis-Espana-$role.exe"
  $argsC=@('/nologo','/target:winexe','/platform:x64','/optimize+','/langversion:5','/codepage:65001',"/out:$exe")
  foreach($r in $refs){$argsC+="/reference:$r"}
  $argsC+=@(Get-ChildItem -Path $dir -Filter '*.cs' | ForEach-Object {$_.FullName})
  Write-Host "Compilation $role ..." -ForegroundColor Cyan
  & $csc @argsC
  if($LASTEXITCODE -ne 0){throw "Compilation $role echouee"}
  Copy-Item (Join-Path $dir 'MainWindow.xaml') $out -Force
  Copy-Item (Join-Path $dir 'config.json') $out -Force
  Write-Host "OK : $exe" -ForegroundColor Green
 }
} catch {Write-Host "ERREUR : $($_.Exception.Message)" -ForegroundColor Red;exit 1}
