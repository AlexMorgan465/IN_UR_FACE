[CmdletBinding()]
param([switch]$Lancer)
$ErrorActionPreference = 'Stop'
$racine = $PSScriptRoot
try {
    if (-not [Environment]::Is64BitOperatingSystem) { throw 'Cette version cible Windows x64.' }
    $release = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -ErrorAction Stop).Release
    if ($release -lt 528040) { throw '.NET Framework 4.8 ou 4.8.1 est requis.' }
    $framework = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
    $csc = Join-Path $framework 'csc.exe'
    if (-not (Test-Path -LiteralPath $csc)) { throw 'Compilateur C# Windows introuvable (.NET Framework).' }
    $wpf = Join-Path $framework 'WPF'
    $sortie = Join-Path $racine 'bin'
    if (-not (Test-Path -LiteralPath $sortie)) { New-Item -ItemType Directory -Path $sortie | Out-Null }
    $xaml = Join-Path $racine 'ui\MainWindow.xaml'
    $references = @(
        (Join-Path $framework 'System.dll'),
        (Join-Path $framework 'System.Core.dll'),
        (Join-Path $framework 'System.Drawing.dll'),
        (Join-Path $framework 'System.Windows.Forms.dll'),
        (Join-Path $framework 'System.Web.Extensions.dll'),
        (Join-Path $framework 'System.Xaml.dll'),
        (Join-Path $wpf 'WindowsBase.dll'),
        (Join-Path $wpf 'PresentationCore.dll'),
        (Join-Path $wpf 'PresentationFramework.dll')
    )
    foreach ($ref in $references) { if (-not (Test-Path -LiteralPath $ref)) { throw "Reference manquante : $ref" } }
    $exe = Join-Path $sortie 'Cofidis_Espana.exe'
    $argsCompilation = @('/nologo', '/target:winexe', '/platform:x64', '/optimize+', '/codepage:65001', '/langversion:5', "/out:$exe", "/resource:$xaml,Cofidis.MainWindow.xaml", "/win32manifest:$(Join-Path $racine 'src\app.manifest')")
    foreach ($ref in $references) { $argsCompilation += "/reference:$ref" }
    foreach ($fichier in @('Program.cs', 'MainController.cs', 'AjustesVentana.cs', 'Tratamiento.cs', 'AlmacenJson.cs')) { $argsCompilation += (Join-Path $racine "src\$fichier") }
    & $csc @argsCompilation
    if ($LASTEXITCODE -ne 0) { throw "La compilation C# a echoue (code $LASTEXITCODE)." }
    Copy-Item -LiteralPath (Join-Path $racine 'src\app.config') -Destination ($exe + '.config') -Force
    # config.json : copie uniquement s'il n'existe pas, pour ne pas ecraser la ruta deja choisie.
    $configuracion = Join-Path $sortie 'config.json'
    if (-not (Test-Path -LiteralPath $configuracion)) { Copy-Item -LiteralPath (Join-Path $racine 'config.json') -Destination $configuracion }
    Write-Host "EXE cree : $exe" -ForegroundColor Green
    Write-Host 'Le dossier bin complet peut etre lance sans PowerShell.'
    if ($Lancer) { Start-Process -FilePath $exe -WorkingDirectory $sortie }
}
catch {
    Write-Host "ERREUR : $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
