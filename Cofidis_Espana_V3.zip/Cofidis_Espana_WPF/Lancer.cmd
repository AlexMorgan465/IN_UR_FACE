@echo off
setlocal
if not exist "%~dp0bin\Cofidis_Espana.exe" (
  powershell.exe -NoProfile -File "%~dp0Compiler.ps1" -Lancer
  if errorlevel 1 pause
) else (
  start "Cofidis Espana" "%~dp0bin\Cofidis_Espana.exe"
)
endlocal
