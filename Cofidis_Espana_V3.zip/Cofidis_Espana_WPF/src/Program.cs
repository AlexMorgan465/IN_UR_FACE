using System;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Markup;

namespace Cofidis_Espana
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            try
            {
                Application app = new Application();
                app.DispatcherUnhandledException += delegate(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
                {
                    MessageBox.Show(e.Exception.Message, "Cofidis Espa\u00f1a \u2014 error", MessageBoxButton.OK, MessageBoxImage.Error);
                    e.Handled = true;
                };
                Window ventana;
                using (Stream flujo = Assembly.GetExecutingAssembly().GetManifestResourceStream("Cofidis.MainWindow.xaml"))
                {
                    if (flujo == null) throw new InvalidOperationException("Interfaz incrustada no encontrada.");
                    ventana = (Window)XamlReader.Load(flujo);
                }
                new MainController(ventana);
                app.Run(ventana);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Cofidis Espa\u00f1a \u2014 inicio imposible", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
