using System;

namespace Cofidis_Espana.Models
{
    public sealed class Tratamiento
    {
        public Tratamiento()
        {
            Id = Guid.NewGuid().ToString("N");
            Usuario = "";
            Referencia = "";
            Taf = "";
            Decision = "";
            Comentario = "";
            Estado = "En curso";
        }

        public string Id { get; set; }
        public string Usuario { get; set; }
        public string Referencia { get; set; }
        public string Taf { get; set; }
        public string Decision { get; set; }
        public string Comentario { get; set; }
        public DateTime FechaInicio { get; set; }
        public DateTime? FechaFin { get; set; }
        public string Estado { get; set; }

        public double? DmtSegundos
        {
            get
            {
                if (!FechaFin.HasValue) return null;
                return Math.Max(0, (FechaFin.Value - FechaInicio).TotalSeconds);
            }
        }

        public string Dmt
        {
            get
            {
                double? s = DmtSegundos;
                if (!s.HasValue) return "-";
                return TimeSpan.FromSeconds(s.Value).ToString(@"hh\:mm\:ss");
            }
        }
    }
}
