using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;
using Cofidis_Espana.Models;

namespace Cofidis_Espana.Services
{
    public sealed class AlmacenJson
    {
        private readonly string raiz;
        private readonly string usuario = Environment.UserName;
        private static readonly UTF8Encoding Utf8 = new UTF8Encoding(false);

        public string RutaDatos { get { return raiz; } }

        public static string ArchivoConfiguracion
        {
            get { return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "config.json"); }
        }

        private static JavaScriptSerializer Serializador()
        {
            return new JavaScriptSerializer { MaxJsonLength = int.MaxValue, RecursionLimit = 100 };
        }

        public AlmacenJson()
        {
            string configuracion = ArchivoConfiguracion;
            if (!File.Exists(configuracion)) throw new FileNotFoundException("No se encuentra config.json", configuracion);
            var datos = Serializador().Deserialize<Dictionary<string, object>>(File.ReadAllText(configuracion, Encoding.UTF8));
            object valor;
            if (datos == null || !datos.TryGetValue("RutaDatos", out valor) || valor == null || string.IsNullOrWhiteSpace(valor.ToString()))
                throw new InvalidDataException("RutaDatos está vacía en config.json");
            raiz = Path.GetFullPath(Environment.ExpandEnvironmentVariables(valor.ToString()));
            Directory.CreateDirectory(raiz);
        }

        // Valida la carpeta (se crea si no existe y se comprueba que se puede escribir) y la guarda en config.json.
        public static void GuardarRuta(string ruta)
        {
            if (string.IsNullOrWhiteSpace(ruta)) throw new ArgumentException("La ruta está vacía.");
            string completa = Path.GetFullPath(Environment.ExpandEnvironmentVariables(ruta.Trim()));
            Directory.CreateDirectory(completa);
            string prueba = Path.Combine(completa, ".escritura-" + Guid.NewGuid().ToString("N") + ".tmp");
            File.WriteAllText(prueba, "ok");
            File.Delete(prueba);
            var contenido = new Dictionary<string, object>();
            contenido["RutaDatos"] = ruta.Trim();
            File.WriteAllText(ArchivoConfiguracion, Sangrar(Serializador().Serialize(contenido)), Utf8);
        }

        private string Archivo(DateTime fecha)
        {
            string mes = fecha.ToString("MM-yyyy", CultureInfo.InvariantCulture);
            return Path.Combine(raiz, mes, usuario + "-" + mes + ".json");
        }

        public List<Tratamiento> LeerArchivo(string ruta)
        {
            var lista = new List<Tratamiento>();
            if (!File.Exists(ruta)) return lista;
            object raizJson = Serializador().DeserializeObject(File.ReadAllText(ruta, Encoding.UTF8));
            var elementos = raizJson as IEnumerable;
            if (elementos == null || raizJson is string) throw new InvalidDataException("JSON vacío o inválido: " + ruta);
            foreach (object elemento in elementos)
            {
                var d = elemento as Dictionary<string, object>;
                if (d == null) throw new InvalidDataException("JSON vacío o inválido: " + ruta);
                var t = new Tratamiento();
                t.Id = Texto(d, "Id", t.Id);
                t.Usuario = Texto(d, "Usuario", "");
                t.Referencia = Texto(d, "Referencia", "");
                t.Taf = Texto(d, "Taf", "");
                t.Decision = Texto(d, "Decision", "");
                t.Comentario = Texto(d, "Comentario", "");
                t.Estado = Texto(d, "Estado", "En curso");
                t.FechaInicio = Fecha(Texto(d, "FechaInicio", null)) ?? DateTime.Now;
                t.FechaFin = Fecha(Texto(d, "FechaFin", null));
                lista.Add(t);
            }
            return lista;
        }

        private static string Texto(Dictionary<string, object> d, string clave, string porDefecto)
        {
            foreach (var par in d)
                if (string.Equals(par.Key, clave, StringComparison.OrdinalIgnoreCase))
                    return par.Value == null ? porDefecto : par.Value.ToString();
            return porDefecto;
        }

        private static DateTime? Fecha(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto)) return null;
            DateTime f;
            if (DateTime.TryParse(texto, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out f)) return f;
            return null;
        }

        public List<Tratamiento> LeerMes(DateTime fecha)
        {
            return LeerArchivo(Archivo(fecha));
        }

        public List<Tratamiento> LeerTodos()
        {
            var lista = new List<Tratamiento>();
            if (!Directory.Exists(raiz)) return lista;
            foreach (string ruta in Directory.EnumerateFiles(raiz, usuario + "-*.json", SearchOption.AllDirectories))
                lista.AddRange(LeerArchivo(ruta).Where(x => string.Equals(x.Usuario, usuario, StringComparison.OrdinalIgnoreCase)));
            return lista;
        }

        public void Guardar(Tratamiento registro)
        {
            string ruta = Archivo(registro.FechaInicio);
            Directory.CreateDirectory(Path.GetDirectoryName(ruta));
            var registros = LeerArchivo(ruta);
            int posicion = registros.FindIndex(x => x.Id == registro.Id);
            if (posicion >= 0) registros[posicion] = registro;
            else registros.Add(registro);

            var salida = new List<Dictionary<string, object>>();
            foreach (Tratamiento t in registros)
            {
                var d = new Dictionary<string, object>();
                d["Id"] = t.Id;
                d["Usuario"] = t.Usuario;
                d["Referencia"] = t.Referencia;
                d["Taf"] = t.Taf;
                d["Decision"] = t.Decision;
                d["Comentario"] = t.Comentario;
                d["FechaInicio"] = t.FechaInicio.ToString("o", CultureInfo.InvariantCulture);
                d["FechaFin"] = t.FechaFin.HasValue ? t.FechaFin.Value.ToString("o", CultureInfo.InvariantCulture) : null;
                d["Estado"] = t.Estado;
                d["DmtSegundos"] = t.DmtSegundos;
                d["Dmt"] = t.Dmt;
                salida.Add(d);
            }
            string texto = Sangrar(Serializador().Serialize(salida));
            string temporal = ruta + ".tmp";
            File.WriteAllText(temporal, texto, Utf8);
            if (File.Exists(ruta)) File.Replace(temporal, ruta, null);
            else File.Move(temporal, ruta);
        }

        // Sangrado sencillo para que el JSON sea legible.
        private static string Sangrar(string json)
        {
            var sb = new StringBuilder();
            int nivel = 0;
            bool enTexto = false;
            for (int i = 0; i < json.Length; i++)
            {
                char c = json[i];
                if (enTexto)
                {
                    sb.Append(c);
                    if (c == '\\' && i + 1 < json.Length) { sb.Append(json[++i]); }
                    else if (c == '"') enTexto = false;
                    continue;
                }
                switch (c)
                {
                    case '"': enTexto = true; sb.Append(c); break;
                    case '{':
                    case '[':
                        sb.Append(c);
                        if (i + 1 < json.Length && (json[i + 1] == '}' || json[i + 1] == ']')) break;
                        nivel++;
                        sb.Append("\r\n").Append(' ', nivel * 2);
                        break;
                    case '}':
                    case ']':
                        if (i > 0 && (json[i - 1] == '{' || json[i - 1] == '[')) { sb.Append(c); break; }
                        nivel--;
                        sb.Append("\r\n").Append(' ', nivel * 2).Append(c);
                        break;
                    case ',': sb.Append(c).Append("\r\n").Append(' ', nivel * 2); break;
                    case ':': sb.Append(": "); break;
                    default: sb.Append(c); break;
                }
            }
            return sb.ToString();
        }
    }
}
