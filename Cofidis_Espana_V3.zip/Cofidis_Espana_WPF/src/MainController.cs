using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Cofidis_Espana.Models;
using Cofidis_Espana.Services;

namespace Cofidis_Espana
{
    // Logica de la ventana principal. La interfaz se carga desde ui\MainWindow.xaml (incrustado).
    internal sealed class MainController
    {
        private readonly Window ventana;
        private AlmacenJson almacen;
        private Tratamiento activo;
        private List<Tratamiento> registros = new List<Tratamiento>();
        private readonly string usuario = Environment.UserName;
        private static readonly string[] Taf = { "46580", "46603", "46578", "46650", "46628", "46575" };
        private static readonly string[] Decisiones = {
            "fecha", "Tratados", "sin informaci\u00f3n para pre-estudio", "RExBU", "RExB1", "RExIG",
            "RExRECIENTE", "RExNT", "RExPR", "RExVEDACON", "RExFICHEROS NEG",
            "RExTIPO CTTO", "RExSCORE", "RExRIESGO", "RExLI", "RExAN", "RExBQ"
        };

        private readonly TextBox referenciaCaja, comentarioCaja, busquedaCaja;
        private readonly ComboBox tafCaja, decisionCaja;
        private readonly Button agregarBoton, finalizarBoton, actualizarBoton, ajustesBoton;
        private readonly TextBlock usuarioTexto, rutaTexto, estadoTexto, inicioTexto, resumenTexto;
        private readonly DataGrid tabla;

        private T Obtener<T>(string nombre) where T : class
        {
            T elemento = ventana.FindName(nombre) as T;
            if (elemento == null) throw new InvalidOperationException("Elemento de interfaz no encontrado: " + nombre);
            return elemento;
        }

        public MainController(Window ventana)
        {
            this.ventana = ventana;
            referenciaCaja = Obtener<TextBox>("ReferenciaCaja");
            comentarioCaja = Obtener<TextBox>("ComentarioCaja");
            busquedaCaja = Obtener<TextBox>("BusquedaCaja");
            tafCaja = Obtener<ComboBox>("TafCaja");
            decisionCaja = Obtener<ComboBox>("DecisionCaja");
            agregarBoton = Obtener<Button>("AgregarBoton");
            finalizarBoton = Obtener<Button>("FinalizarBoton");
            actualizarBoton = Obtener<Button>("ActualizarBoton");
            ajustesBoton = Obtener<Button>("AjustesBoton");
            usuarioTexto = Obtener<TextBlock>("UsuarioTexto");
            rutaTexto = Obtener<TextBlock>("RutaTexto");
            estadoTexto = Obtener<TextBlock>("EstadoTexto");
            inicioTexto = Obtener<TextBlock>("InicioTexto");
            resumenTexto = Obtener<TextBlock>("ResumenTexto");
            tabla = Obtener<DataGrid>("Tabla");

            agregarBoton.Click += Agregar_Click;
            finalizarBoton.Click += Finalizar_Click;
            actualizarBoton.Click += Actualizar_Click;
            ajustesBoton.Click += Ajustes_Click;
            busquedaCaja.TextChanged += delegate { MostrarTabla(); };

            tafCaja.ItemsSource = Taf;
            decisionCaja.ItemsSource = Decisiones;
            usuarioTexto.Text = "Hola, " + usuario;
            try
            {
                almacen = new AlmacenJson();
                rutaTexto.Text = almacen.RutaDatos;
                Cargar();
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pueden cargar los datos.\n" + ex.Message, "Error de almacenamiento", MessageBoxButton.OK, MessageBoxImage.Error);
                agregarBoton.IsEnabled = false;
                finalizarBoton.IsEnabled = false;
            }
        }

        private void Cargar()
        {
            if (almacen == null) return;
            registros = almacen.LeerTodos();
            var abiertos = registros.Where(x => x.Estado == "En curso").OrderBy(x => x.FechaInicio).ToList();
            bool incidencia = abiertos.Count > 1;
            activo = abiertos.FirstOrDefault();
            if (activo != null)
            {
                referenciaCaja.Text = activo.Referencia;
                tafCaja.SelectedItem = activo.Taf;
                decisionCaja.SelectedItem = string.IsNullOrEmpty(activo.Decision) ? null : activo.Decision;
                comentarioCaja.Text = activo.Comentario;
            }
            ActualizarEstado();
            MostrarTabla();
            if (incidencia)
            {
                agregarBoton.IsEnabled = false;
                MessageBox.Show("Hay varios tratamientos abiertos. Se bloquea la creaci\u00f3n de nuevos registros hasta resolver la incidencia.", "Revisi\u00f3n necesaria", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void ActualizarEstado()
        {
            bool enCurso = activo != null;
            referenciaCaja.IsEnabled = !enCurso;
            tafCaja.IsEnabled = !enCurso;
            agregarBoton.IsEnabled = !enCurso && almacen != null;
            decisionCaja.IsEnabled = enCurso;
            comentarioCaja.IsEnabled = enCurso;
            finalizarBoton.IsEnabled = enCurso && almacen != null;
            estadoTexto.Text = enCurso ? "En curso \u00b7 " + activo.Referencia + " \u00b7 TAF " + activo.Taf : "Sin tratamiento activo";
            inicioTexto.Text = enCurso ? "Inicio: " + activo.FechaInicio.ToString("dd/MM/yyyy HH:mm:ss") : "Puede iniciar una nueva llamada";
        }

        private void MostrarTabla()
        {
            string filtro = busquedaCaja.Text.Trim();
            var hoy = registros.Where(x => x.FechaInicio.Date == DateTime.Today &&
                    (filtro.Length == 0 ||
                     x.Referencia.IndexOf(filtro, StringComparison.OrdinalIgnoreCase) >= 0 ||
                     x.Taf.IndexOf(filtro, StringComparison.OrdinalIgnoreCase) >= 0 ||
                     x.Decision.IndexOf(filtro, StringComparison.OrdinalIgnoreCase) >= 0))
                .OrderByDescending(x => x.FechaInicio).ToList();
            tabla.ItemsSource = hoy;
            int terminados = registros.Count(x => x.FechaInicio.Date == DateTime.Today && x.Estado == "Finalizado");
            resumenTexto.Text = terminados + " finalizados hoy  \u00b7  " + (activo == null ? "Sin llamada activa" : "1 llamada en curso");
        }

        private void Agregar_Click(object sender, RoutedEventArgs e)
        {
            if (almacen == null || activo != null) return;
            string referencia = referenciaCaja.Text.Trim();
            string taf = tafCaja.SelectedItem as string;
            if (string.IsNullOrWhiteSpace(referencia) || string.IsNullOrWhiteSpace(taf))
            {
                MessageBox.Show("Introduzca una referencia y seleccione un guichet TAF.", "Campos obligatorios", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            var nuevo = new Tratamiento { Usuario = usuario, Referencia = referencia, Taf = taf, FechaInicio = DateTime.Now };
            try
            {
                // Volver a leer antes de escribir para recuperar cualquier sesion anterior.
                var actual = almacen.LeerTodos();
                if (actual.Any(x => x.Estado == "En curso"))
                {
                    MessageBox.Show("Ya existe un tratamiento en curso. Actualice la pantalla.", "Tratamiento pendiente", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                almacen.Guardar(nuevo);
                activo = nuevo;
                registros = almacen.LeerTodos();
                decisionCaja.SelectedItem = null;
                comentarioCaja.Clear();
                ActualizarEstado();
                MostrarTabla();
            }
            catch (Exception ex) { MessageBox.Show("No se pudo guardar el inicio:\n" + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error); }
        }

        private void Finalizar_Click(object sender, RoutedEventArgs e)
        {
            if (almacen == null || activo == null) return;
            string decision = decisionCaja.SelectedItem as string;
            if (string.IsNullOrWhiteSpace(decision))
            {
                MessageBox.Show("Seleccione una decisi\u00f3n para finalizar.", "Campo obligatorio", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            var terminado = new Tratamiento
            {
                Id = activo.Id, Usuario = activo.Usuario, Referencia = activo.Referencia, Taf = activo.Taf,
                FechaInicio = activo.FechaInicio, FechaFin = DateTime.Now, Decision = decision,
                Comentario = comentarioCaja.Text.Trim(), Estado = "Finalizado"
            };
            try
            {
                almacen.Guardar(terminado);
                activo = null;
                registros = almacen.LeerTodos();
                referenciaCaja.Clear();
                tafCaja.SelectedItem = null;
                decisionCaja.SelectedItem = null;
                comentarioCaja.Clear();
                ActualizarEstado();
                MostrarTabla();
            }
            catch (Exception ex) { MessageBox.Show("No se pudo finalizar:\n" + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error); }
        }

        private void Actualizar_Click(object sender, RoutedEventArgs e)
        {
            try { Cargar(); }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Error al actualizar", MessageBoxButton.OK, MessageBoxImage.Error); }
        }

        private void Ajustes_Click(object sender, RoutedEventArgs e)
        {
            if (activo != null)
            {
                MessageBox.Show("Finalice el tratamiento en curso antes de cambiar la ruta de guardado.", "Tratamiento en curso", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            var dialogo = new AjustesVentana(almacen != null ? almacen.RutaDatos : string.Empty) { Owner = ventana };
            if (dialogo.ShowDialog() != true) return;
            try
            {
                almacen = new AlmacenJson();
                rutaTexto.Text = almacen.RutaDatos;
                Cargar();
                MessageBox.Show("Nueva ruta de guardado:\n" + almacen.RutaDatos, "Ruta actualizada", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo aplicar la nueva ruta:\n" + ex.Message, "Error de almacenamiento", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
