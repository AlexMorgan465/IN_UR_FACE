'use strict';
let clics = 0;
const bouton = document.getElementById('action');
bouton.addEventListener('click', () => {
    clics += 1;
    document.getElementById('compteur').textContent = clics;
    console.log('Interaction réussie — clic numéro', clics);
});
console.info('Bienvenue dans votre atelier. Le script est prêt.');
