// Script C# simple : les instructions sont enveloppées dans Main.
var valeurs = new[] { 5, 10, 15 };
Console.WriteLine("Somme du script : " + valeurs.Sum());
