using System;
using System.Linq;
internal static class MonProgramme
{
    private static void Main()
    {
        Console.WriteLine("Bienvenue dans WorkStudio !");
        var montants = new[] { 120, 85, 240 };
        Console.WriteLine("Total : " + montants.Sum());
        Console.WriteLine("Modifiez ce fichier, puis appuyez sur F5.");
    }
}
