@echo off
start "" "%~dp0bin\WorkStudio.exe"
