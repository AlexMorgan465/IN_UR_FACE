@echo off
setlocal
cd /d "%~dp0.."
set "STUDIO_TEST_HOME=%TEMP%\WorkStudioTests-%RANDOM%-%RANDOM%"
mkdir "%STUDIO_TEST_HOME%"
"%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe" /nologo /target:exe /langversion:5 /codepage:65001 /out:"%STUDIO_TEST_HOME%\CoreTests.exe" /reference:lib\Newtonsoft.Json.dll /reference:System.Core.dll /reference:System.Numerics.dll src\Workspace.cs src\Inspector.cs src\Runner.cs validation\CoreTests.cs
if errorlevel 1 exit /b 1
copy /Y lib\Newtonsoft.Json.dll "%STUDIO_TEST_HOME%\Newtonsoft.Json.dll" >nul
"%STUDIO_TEST_HOME%\CoreTests.exe" "%STUDIO_TEST_HOME%\fixtures"
set "STUDIO_TEST_RESULT=%ERRORLEVEL%"
echo Resultats et fichiers de test : %STUDIO_TEST_HOME%
exit /b %STUDIO_TEST_RESULT%
