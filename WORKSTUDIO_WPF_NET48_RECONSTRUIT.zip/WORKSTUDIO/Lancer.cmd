@echo off
setlocal
cd /d "%~dp0"
call "%~dp0Recompiler.cmd"
if errorlevel 1 (echo Compilation de WorkStudio impossible. Consultez le message ci-dessus. & pause & exit /b 1)
start "" "%~dp0bin\WorkStudio.exe"
endlocal
