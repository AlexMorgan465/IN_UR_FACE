﻿@echo off
setlocal
cd /d "%~dp0"
set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
set "FW=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319"
if not exist "%CSC%" (echo Compilateur .NET Framework x64 absent. & exit /b 1)
if not exist bin mkdir bin
"%CSC%" /nologo /target:winexe /platform:x64 /optimize+ /langversion:5 /codepage:65001 /out:bin\WorkStudio.exe /win32manifest:src\app.manifest /reference:System.dll /reference:System.Core.dll /reference:System.Numerics.dll /reference:System.Xaml.dll /reference:System.Windows.Forms.dll /reference:"%FW%\WPF\WindowsBase.dll" /reference:"%FW%\WPF\PresentationCore.dll" /reference:"%FW%\WPF\PresentationFramework.dll" /reference:lib\Newtonsoft.Json.dll /reference:lib\Microsoft.Web.WebView2.Core.dll /reference:lib\Microsoft.Web.WebView2.Wpf.dll /resource:ui\index.html,WorkStudio.UI.index.html /resource:ui\style.css,WorkStudio.UI.style.css /resource:ui\app.js,WorkStudio.UI.app.js /resource:ui\bridge.js,WorkStudio.UI.bridge.js /resource:ui\preview.js,WorkStudio.UI.preview.js /resource:ui\xaml-tools.js,WorkStudio.UI.xaml-tools.js /resource:examples\web\index.html,WorkStudio.Templates.demo.html /resource:examples\web\style.css,WorkStudio.Templates.demo.css /resource:examples\web\app.js,WorkStudio.Templates.demo.js /resource:examples\csharp\Main.cs,WorkStudio.Templates.demo.cs src\*.cs
if errorlevel 1 exit /b 1
copy /Y src\app.config bin\WorkStudio.exe.config >nul
copy /Y lib\*.dll bin\ >nul
echo WorkStudio compile. Lancez Lancer.cmd ou bin\WorkStudio.exe.
endlocal
