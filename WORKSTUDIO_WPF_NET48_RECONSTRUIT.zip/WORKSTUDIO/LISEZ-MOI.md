﻿# WorkStudio — atelier C# et Web portable

## Démarrer

Décompresser tout le ZIP, puis lancer **Lancer.cmd**. Ce lanceur recompile automatiquement WorkStudio depuis `src/` et `ui/` avant de démarrer. Vous pouvez aussi lancer `Recompiler.cmd` séparément. Pour démarrer directement `bin\WorkStudio.exe`, recompilez d’abord après une modification des sources. Conserver ensemble le contenu complet de bin. L’exécutable est déjà compilé pour Windows x64.

Prérequis déjà présents sur le poste : **.NET Framework 4.8/4.8.1** et le **runtime Microsoft Edge WebView2**. Aucune installation ni aucun téléchargement automatique. Pas de Node, Python, npm, NuGet, service, serveur HTTP, port local ou droit administrateur nécessaires à l’utilisation.

Les exemples HTML/CSS/JS et C# sont fournis. Au premier lancement, un exemple éditable est préparé dans `%LOCALAPPDATA%\WorkStudio\Mon premier atelier`. Vos projets ÉPITHÈTE et JSON Studio ne sont pas modifiés automatiquement.

## Le parcours le plus simple

1. **Ouvrir** : choisir le dossier complet du projet. Cliquer sur un fichier dans l’explorateur ouvre son onglet.
2. Modifier le code. Les brouillons sont conservés localement ; ils ne remplacent pas immédiatement les fichiers d’origine.
3. **Exécuter / F5** : affiche le HTML à droite ou compile et lance le C# courant. Les brouillons sont inclus, sans obligation d’écraser d’abord le projet.
4. **Inspecter** : sélectionner un élément de la page. Le panneau indique la source HTML et sa ligne, son ID, ses classes, ses propriétés et les règles CSS correspondantes.
5. Changer le texte simple ou le style, puis **Appliquer au code HTML**. Le brouillon et l’aperçu sont mis à jour. **Aller à la source** retrouve la ligne ; un bouton de règle CSS ouvre son fichier et recherche le sélecteur.
6. **Enregistrer / Ctrl S** écrit le fichier et crée une sauvegarde locale de la version précédente. **Ctrl Maj S** enregistre les onglets modifiés.

**Nouveau projet** crée un dossier Web, C# console, hybride ou WPF C# + XAML (.NET Framework 4.8). Le modèle WPF fournit App.xaml, MainWindow.xaml, les fichiers C# associés et un .csproj ouvrable dans Visual Studio. **＋** crée un fichier dans le projet. **Copie…** conserve une autre version sans écraser un fichier existant. **Relire** recharge le disque et archive le brouillon précédent. **Ctrl F** ouvre la recherche/remplacement exact, sensible à la casse.

Le séparateur entre code et aperçu est déplaçable. La console affiche les messages JavaScript, les erreurs de page, la sortie du programme C# et les erreurs du compilateur. Les erreurs associées à un fichier sont cliquables. Le champ d’expression de la console évalue du JavaScript dans l’aperçu, pas du C#.

## Compilation C#

Le moteur appelle directement le compilateur Windows `.NET Framework\Framework64\v4.0.30319\csc.exe`, sans passer par PowerShell et sans changer la politique d’exécution.

- **C# · projet console** : compile les .cs de src/ si ce dossier existe, sinon les .cs du projet. Les dossiers bin, obj, lib, node_modules, .git, validation et tests sont exclus.
- **C# · fichier courant / script** : compile le .cs courant ou enveloppe un .csx simple dans Main. Les directives using simples sont prises en charge.
- **C# · application WPF** : cible Windows avec les références Framework WPF et les DLL managées de lib/.
- **ÉPITHÈTE · Agent / Manager** : ajoute les ressources ui/agent ou ui/manager avec le préfixe attendu et définit MANAGER pour le profil Manager.
- **JSON Studio** : regroupe les CSS/JS locaux de ui/index.html dans la ressource JSONStudio.UI, comme le compilateur du projet existant.

Le profil WPF des projets créés compile les fichiers C# avec le moteur fourni pour un lancement de test autonome ; le fichier .csproj permet aussi une compilation WPF classique avec MSBuild/Visual Studio et le rendu XAML natif. Les profils proposent les références Framework courantes, les DLL de lib/, src/app.manifest et app.config. desktop-config.json est copié à côté du programme de test ; ses chemins relatifs dataDirectory/sourceDirectory sont résolus depuis le projet d’origine.

Les compilations sont créées sous `%LOCALAPPDATA%\WorkStudio\Builds`, avec les sources de brouillon utilisées. Elles ne remplacent pas les EXE de production dans votre projet. Un programme lancé conserve toutefois les droits Windows du compte et ses propres effets : il peut donc modifier les données auxquelles SON code accède. Tester les programmes métier sur une copie et une configuration de test.

**Arrêter** termine le groupe du programme lancé, y compris ses enfants ordinaires, et interrompt le JavaScript de l’aperçu. Il ne ferme pas les autres programmes de l’utilisateur.

## Sauvegardes et brouillons

Les paramètres, brouillons et sauvegardes restent dans `%LOCALAPPDATA%\WorkStudio` :

- `preferences.json` : dernier dossier ouvert ;
- `Drafts\<projet>` : brouillons, texte et empreinte de la version disque ;
- `Backups\<projet>` : copies des fichiers avant enregistrement ;
- `History\<projet>` : brouillons archivés par Relire ;
- `Builds\<projet>` : compilations de test ;
- `Sessions` et `Profiles` : interface extraite et profils WebView2.

L’enregistrement vérifie si le fichier a changé depuis son ouverture et refuse un écrasement détecté. Une erreur conserve le brouillon et reste visible. Les sauvegardes locales doivent réussir avant d’écrire la source. La fermeture récupère les textes encore ouverts et signale les modifications non enregistrées/programmes actifs. Une sauvegarde multi-fichiers est séquentielle, pas une transaction de tout le projet.

Les écritures emploient des fichiers temporaires et un remplacement atomique. Les sauvegardes et compilations ne sont pas purgées automatiquement. Conserver une sauvegarde du poste : les fichiers locaux ne protègent pas contre la perte du disque.

## Limites de cette première version

- Éditeur léger avec coloration, indentation, onglets et recherche ; pas d’IntelliSense complet, de débogage C# pas à pas, de points d’arrêt ni de débogueur .NET attaché.
- **C# 5 / .NET Framework**, pas le compilateur moderne du SDK .NET. Un projet .NET récent ou un .csproj avec NuGet/MSBuild n’est pas automatiquement pris en charge.
- Les profils intégrés reconnaissent les structures des versions ÉPITHÈTE et JSON Studio présentes lors de la création. Un autre mécanisme d’intégration de ressources doit être adapté.
- Les fichiers .ps1/.cmd sont éditables mais ne sont pas exécutés par ce moteur.
- Aperçu local uniquement : les ressources externes, permissions, téléchargements et navigations externes sont bloqués. Copier les dépendances nécessaires dans le projet. Les appels fetch vers des JSON locaux au projet sont possibles.
- L’aperçu et l’éditeur utilisent des WebView2/profils séparés. Les messages d’une page ne peuvent pas appeler les commandes d’écriture de l’éditeur. Le C# compilé n’est pas un bac à sable de sécurité.
- Une interface Web qui exige son pont C# métier, comme ÉPITHÈTE/JSON Studio, doit être compilée/lancée avec son profil pour fonctionner complètement ; l’aperçu seul ne fournit pas ce moteur.
- L’inspecteur modifie le HTML source et ses styles en ligne. Il refuse d’aplatir les enfants HTML pour changer le texte d’un conteneur. Un élément créé uniquement par JavaScript n’a pas de ligne HTML à réécrire ; ses règles CSS peuvent être explorées et son script se modifie dans l’éditeur.
- Une modification externe à l’inspection impose de relancer l’aperçu avant d’appliquer une ancienne sélection. Après une modification effectuée par l’inspecteur, la sélection est actualisée pour permettre de continuer les ajustements.
- UTF-8, UTF-16 avec BOM et Windows-1252 pris en charge ; limite de 4 Mio par document, 32 Mio par ressource d’aperçu et 4 000 fichiers texte par projet. Les liens symboliques et jonctions ne sont pas suivis. Les chemins Windows trop longs peuvent être refusés.

## Sources et vérification

src/ contient le moteur C#, ui/ l’interface de l’éditeur et le script d’inspection, examples/ les exemples. **Recompiler.cmd** recompile WorkStudio avec le compilateur existant et les DLL fournies, sans installation. Fermer WorkStudio avant de recompiler.

Les tests dans validation/ couvrent les chemins, la reprise des brouillons, les sauvegardes, les conflits externes, le lien élément/ligne, les modifications inspectées, les contenus HTML imbriqués, les encodages, les scripts, les erreurs cliquables et l’arrêt des processus enfants. Les profils de compilation ÉPITHÈTE Manager et JSON Studio ont également été exécutés sur leurs sources existantes, sans lancement des applications métier ni écriture dans leurs dossiers.

Un essai WPF/WebView2 réel a validé l’ouverture de l’exemple, son rendu, la console JavaScript, la modification d’un titre depuis l’inspecteur et l’exécution C# avec résultat dans la console. La version finale de l’inspecteur a également été testée dans la fenêtre Windows : changement de couleur appliqué au HTML et au rendu sans rechargement, avec le compteur JavaScript conservé. Les changements successifs de la même sélection passent les tests de régression. La console est bornée pour éviter qu’un programme très bavard bloque l’atelier. Il n’y a eu aucune modification des réglages Office, Windows, pare-feu, antivirus ou des politiques du poste.
