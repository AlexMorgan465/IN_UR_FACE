$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
dotnet build .\Cofidis_Espana_Manager.csproj -c Release
if ($LASTEXITCODE -ne 0) { throw 'Compilacion fallida' }
Write-Host 'EXE: bin\Release\net8.0-windows\Cofidis_Espana_Manager.exe'
