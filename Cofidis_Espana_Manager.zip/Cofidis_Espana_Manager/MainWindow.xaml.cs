using System.IO;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using Cofidis_Espana_Manager.Services;
namespace Cofidis_Espana_Manager;
public partial class MainWindow : Window
{
 private List<Tratamiento> todos=new();
 private List<Tratamiento> filtrados=new();
 private List<EstadisticaDia> estadisticas=new();
 private bool inicializando=true;
 private readonly Lector lector;
 private static readonly string[] Decisiones={"sin información para pre-estudio","RExBU","RExB1","RExIG","RExRECIENTE","RExNT","RExPR","RExVEDACON","RExFICHEROS NEG","RExTIPO CTTO","RExSCORE","RExRIESGO","RExLI","RExAN","RExBQ"};
 public MainWindow()
 {
  InitializeComponent();
  try {lector=new Lector();RutaTexto.Text=lector.Raiz;}
  catch(Exception ex){MessageBox.Show("Error en config.json: "+ex.Message);lector=null!;return;}
  inicializando=false;
  Actualizar();
 }
 private void Actualizar_Click(object sender,RoutedEventArgs e)=>Actualizar();
 private void Actualizar()
 {
  if(lector is null)return;
  try
  {
   var (datos,errores)=lector.Leer();todos=datos;
   inicializando=true;
   string? agente=Agente.SelectedItem?.ToString(),taf=Taf.SelectedItem?.ToString(),estado=Estado.SelectedItem?.ToString();
   Agente.ItemsSource=new[]{"Todos"}.Concat(todos.Select(x=>x.Usuario).Where(x=>!string.IsNullOrWhiteSpace(x)).Distinct().OrderBy(x=>x)).ToList();
   Taf.ItemsSource=new[]{"Todos"}.Concat(todos.Select(x=>x.Taf).Where(x=>!string.IsNullOrWhiteSpace(x)).Distinct().OrderBy(x=>x)).ToList();
   Estado.ItemsSource=new[]{"Todos"}.Concat(todos.Select(x=>x.Estado).Where(x=>!string.IsNullOrWhiteSpace(x)).Distinct().OrderBy(x=>x)).ToList();
   Agente.SelectedItem=Agente.Items.Contains(agente)?agente:"Todos";
   Taf.SelectedItem=Taf.Items.Contains(taf)?taf:"Todos";
   Estado.SelectedItem=Estado.Items.Contains(estado)?estado:"Todos";
   inicializando=false;Filtrar();
   EstadoTexto.Text=$"{todos.Count} registros cargados · {errores.Count} archivo(s) con error";
   if(errores.Count>0)MessageBox.Show("Algunos archivos no se pudieron leer:\n"+string.Join("\n",errores.Take(8)),"Advertencia",MessageBoxButton.OK,MessageBoxImage.Warning);
  }
  catch(Exception ex){MessageBox.Show("Error al actualizar: "+ex.Message);}
 }
 private void Filtro_Changed(object sender,EventArgs e) {if(!inicializando && Agente is not null && Taf is not null && Estado is not null)Filtrar();}
 private void Limpiar_Click(object sender,RoutedEventArgs e)
 {
  inicializando=true;Desde.SelectedDate=null;Hasta.SelectedDate=null;
  Agente.SelectedItem="Todos";Taf.SelectedItem="Todos";Estado.SelectedItem="Todos";
  inicializando=false;Filtrar();
 }
 private void Filtrar()
 {
  DateTime? desde=Desde.SelectedDate,hasta=Hasta.SelectedDate;
  string a=Agente.SelectedItem?.ToString()??"Todos",t=Taf.SelectedItem?.ToString()??"Todos",s=Estado.SelectedItem?.ToString()??"Todos";
  filtrados=todos.Where(x=>(!desde.HasValue||x.FechaInicio.Date>=desde.Value.Date)&&(!hasta.HasValue||x.FechaInicio.Date<=hasta.Value.Date)
   &&(a=="Todos"||x.Usuario==a)&&(t=="Todos"||x.Taf==t)&&(s=="Todos"||x.Estado==s)).OrderByDescending(x=>x.FechaInicio).ToList();
  TablaDetalle.ItemsSource=filtrados;
  var terminados=filtrados.Where(x=>EsFinalizado(x)).ToList();
  KpiTotal.Text=filtrados.Count.ToString("N0");KpiFinal.Text=terminados.Count.ToString("N0");KpiCurso.Text=filtrados.Count(x=>!x.FechaFin.HasValue).ToString("N0");
  KpiAgentes.Text=filtrados.Select(x=>x.Usuario).Distinct().Count().ToString();
  KpiDmt.Text=terminados.Count==0?"—":TimeSpan.FromSeconds(terminados.Average(x=>x.DmtSegundos??0)).ToString(@"hh\:mm\:ss");
  estadisticas=terminados.GroupBy(x=>x.FechaInicio.Date).OrderBy(g=>g.Key).Select(g=>CrearEstadistica(g.Key,g.ToList())).ToList();
  TablaStats.ItemsSource=estadisticas;Evolucion.ItemsSource=estadisticas;
  BarrasDecision.ItemsSource=CrearBarras(terminados.GroupBy(x=>x.Decision).Where(g=>!string.IsNullOrWhiteSpace(g.Key)).Select(g=>(g.Key,(double)g.Count())));
  BarrasTaf.ItemsSource=CrearBarras(terminados.GroupBy(x=>x.Taf).Select(g=>(g.Key,(double)g.Count())));
  BarrasDmt.ItemsSource=CrearBarras(terminados.GroupBy(x=>x.Taf).Select(g=>(g.Key,g.Average(x=>x.DmtSegundos??0))));
 }
 private static bool EsFinalizado(Tratamiento x)=>x.FechaFin.HasValue && (x.Estado.Equals("Finalizado",StringComparison.OrdinalIgnoreCase)||x.Estado.Equals("Terminado",StringComparison.OrdinalIgnoreCase)||x.Estado.Equals("Termine",StringComparison.OrdinalIgnoreCase)||x.Estado.Equals("Terminé",StringComparison.OrdinalIgnoreCase));
 private static List<Barra> CrearBarras(IEnumerable<(string nombre,double valor)> origen)
 {
  var lista=origen.OrderByDescending(x=>x.valor).Take(18).ToList();double max=lista.Count==0?1:Math.Max(1,lista.Max(x=>x.valor));
  return lista.Select(x=>new Barra{Nombre=x.nombre,Valor=x.valor.ToString("N0"),Anchura=Math.Max(2,x.valor/max*220)}).ToList();
 }
 private static EstadisticaDia CrearEstadistica(DateTime dia,List<Tratamiento> items)
 {
  int Contar(string decision)=>items.Count(x=>string.Equals(x.Decision.Trim(),decision,StringComparison.OrdinalIgnoreCase));
  int rechazados=Decisiones.Skip(1).Sum(Contar);
  return new EstadisticaDia{
   Fecha=dia.ToString("dd/MM/yyyy"),Tratados=items.Count,SinInformacion=Contar("sin información para pre-estudio"),
   RExBU=Contar("RExBU"),RExB1=Contar("RExB1"),RExIG=Contar("RExIG"),RExRECIENTE=Contar("RExRECIENTE"),
   RExNT=Contar("RExNT"),RExPR=Contar("RExPR"),RExVEDACON=Contar("RExVEDACON"),
   RExFICHEROSNEG=Contar("RExFICHEROS NEG"),RExTIPOCTTO=Contar("RExTIPO CTTO"),RExSCORE=Contar("RExSCORE"),
   RExRIESGO=Contar("RExRIESGO"),RExLI=Contar("RExLI"),RExAN=Contar("RExAN"),RExBQ=Contar("RExBQ"),
   OkParaEstudio=items.Count-rechazados-Contar("sin información para pre-estudio"),
   PorcentajeRechazo=items.Count==0?0:(double)rechazados/items.Count
  };
 }
 private void Exportar(bool excel,bool stats)
 {
  try
  {
   var dialog=new SaveFileDialog{Title=stats?"Exportar estadísticas":"Exportar consolidación",Filter=excel?"Excel (*.xlsx)|*.xlsx":"CSV (*.csv)|*.csv",FileName=(stats?"estadisticas_":"consolidacion_")+DateTime.Now.ToString("yyyyMMdd")+(excel?".xlsx":".csv")};
   if(dialog.ShowDialog()!=true)return;
   var encabezados=stats?Exportador.CabecerasEstadisticas:Exportador.CabecerasDetalle;
   var filas=stats?estadisticas.Select(Exportador.Estadistica):filtrados.Select(Exportador.Detalle);
   if(excel)Exportador.Xlsx(dialog.FileName,encabezados,filas);else Exportador.Csv(dialog.FileName,encabezados,filas);
   EstadoTexto.Text="Exportación completada: "+dialog.FileName;
  }catch(Exception ex){MessageBox.Show("Error al exportar: "+ex.Message);}
 }
 private void CsvDetalle_Click(object sender,RoutedEventArgs e)=>Exportar(false,false);
 private void XlsxDetalle_Click(object sender,RoutedEventArgs e)=>Exportar(true,false);
 private void CsvStats_Click(object sender,RoutedEventArgs e)=>Exportar(false,true);
 private void XlsxStats_Click(object sender,RoutedEventArgs e)=>Exportar(true,true);
}
