using System.Windows;
namespace Cofidis_Espana_Manager;
public partial class App : Application { }
