using System.IO;
using System.Text.Json;
namespace Cofidis_Espana_Manager.Services;
public sealed class Lector
{
 public string Raiz {get;}
 public Lector()
 {
  string cfg=Path.Combine(AppContext.BaseDirectory,"config.json");
  using var doc=JsonDocument.Parse(File.ReadAllText(cfg));
  string path=doc.RootElement.GetProperty("RutaDatos").GetString() ?? throw new InvalidDataException("RutaDatos vacía");
  Raiz=Path.GetFullPath(Environment.ExpandEnvironmentVariables(path));
 }
 public (List<Tratamiento> datos,List<string> errores) Leer()
 {
  var datos=new List<Tratamiento>(); var errores=new List<string>();
  if(!Directory.Exists(Raiz)) {errores.Add("La carpeta no existe: "+Raiz); return(datos,errores);}
  foreach(var archivo in Directory.EnumerateFiles(Raiz,"*.json",SearchOption.AllDirectories))
  {
   if(Path.GetFileName(archivo).Equals("config.json",StringComparison.OrdinalIgnoreCase)) continue;
   try {
    var leidos=JsonSerializer.Deserialize<List<Tratamiento>>(File.ReadAllText(archivo),new JsonSerializerOptions{PropertyNameCaseInsensitive=true});
    if(leidos is null) throw new InvalidDataException("Archivo JSON sin registros");
    datos.AddRange(leidos);
   } catch(Exception ex) {errores.Add(Path.GetFileName(archivo)+": "+ex.Message);}
  }
  // Si un archivo se copió dos veces, un mismo ID se contabiliza una sola vez.
  datos=datos.GroupBy(x=>string.IsNullOrWhiteSpace(x.Id)?Guid.NewGuid().ToString():x.Id).Select(g=>g.First()).ToList();
  return(datos,errores);
 }
}
