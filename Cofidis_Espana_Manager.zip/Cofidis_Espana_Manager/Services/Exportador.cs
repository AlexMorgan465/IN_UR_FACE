using System.IO;
using System.IO.Compression;
using System.Text;
using System.Xml;
namespace Cofidis_Espana_Manager.Services;
public static class Exportador
{
 public static string[] CabecerasDetalle={"Usuario","Fecha","Referencia","TAF","Decisión","Comentario","Inicio","Fin","DMT","Estado"};
 public static string[] Detalle(Tratamiento t)=>new[]{t.Usuario,t.Fecha,t.Referencia,t.Taf,t.Decision,t.Comentario,t.FechaInicio.ToString("yyyy-MM-dd HH:mm:ss"),t.FechaFin?.ToString("yyyy-MM-dd HH:mm:ss")??"",t.Dmt,t.Estado};
 public static string[] CabecerasEstadisticas={"Fecha","Tratados","Sin información para pre-estudio","RExBU","RExB1","RExIG","RExRECIENTE","RExNT","RExPR","RExVEDACON","RExFICHEROS NEG","RExTIPO CTTO","RExSCORE","RExRIESGO","RExLI","RExAN","RExBQ","OK para estudio","% rechazos"};
 public static string[] Estadistica(EstadisticaDia s)=>new[]{s.Fecha,s.Tratados.ToString(),s.SinInformacion.ToString(),s.RExBU.ToString(),s.RExB1.ToString(),s.RExIG.ToString(),s.RExRECIENTE.ToString(),s.RExNT.ToString(),s.RExPR.ToString(),s.RExVEDACON.ToString(),s.RExFICHEROSNEG.ToString(),s.RExTIPOCTTO.ToString(),s.RExSCORE.ToString(),s.RExRIESGO.ToString(),s.RExLI.ToString(),s.RExAN.ToString(),s.RExBQ.ToString(),s.OkParaEstudio.ToString(),s.Rechazo};
 public static void Csv(string ruta,string[] cabeceras,IEnumerable<string[]> filas)
 {
  static string Esc(string s)=>"\""+(s??"").Replace("\"","\"\"")+"\"";
  using var w=new StreamWriter(ruta,false,new UTF8Encoding(true));
  w.WriteLine(string.Join(";",cabeceras.Select(Esc)));
  foreach(var fila in filas) w.WriteLine(string.Join(";",fila.Select(Esc)));
 }
 public static void Xlsx(string ruta,string[] cabeceras,IEnumerable<string[]> filas)
 {
  using var zip=ZipFile.Open(ruta,ZipArchiveMode.Create);
  void Escribir(string nombre,string contenido) {using var s=new StreamWriter(zip.CreateEntry(nombre).Open(),new UTF8Encoding(false));s.Write(contenido);}
  Escribir("[Content_Types].xml","<?xml version=\"1.0\" encoding=\"utf-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>");
  Escribir("_rels/.rels","<?xml version=\"1.0\" encoding=\"utf-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
  Escribir("xl/workbook.xml","<?xml version=\"1.0\" encoding=\"utf-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"Datos\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");
  Escribir("xl/_rels/workbook.xml.rels","<?xml version=\"1.0\" encoding=\"utf-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>");
  using var stream=zip.CreateEntry("xl/worksheets/sheet1.xml").Open();
  using var writer=XmlWriter.Create(stream,new XmlWriterSettings{Encoding=new UTF8Encoding(false),Indent=false});
  const string ns="http://schemas.openxmlformats.org/spreadsheetml/2006/main";
  writer.WriteStartDocument();writer.WriteStartElement("worksheet",ns);writer.WriteStartElement("sheetData",ns);
  int n=0;
  void Fila(string[] c) {writer.WriteStartElement("row",ns);writer.WriteAttributeString("r",(++n).ToString());foreach(string value in c){writer.WriteStartElement("c",ns);writer.WriteAttributeString("t","inlineStr");writer.WriteStartElement("is",ns);writer.WriteElementString("t",ns,value??"");writer.WriteEndElement();writer.WriteEndElement();}writer.WriteEndElement();}
  Fila(cabeceras);foreach(var f in filas) Fila(f);
  writer.WriteEndElement();writer.WriteEndElement();writer.WriteEndDocument();
 }
}
