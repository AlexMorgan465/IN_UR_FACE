@echo off
pwsh -NoProfile -File "%~dp0LANCER_PORTABLE.ps1" -App Both -Build
pause
