@echo off
pwsh -NoProfile -File "%~dp0LANCER_PORTABLE.ps1" -App Manager -Run
if errorlevel 1 pause
