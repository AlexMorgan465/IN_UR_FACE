﻿param([ValidateSet('Agent','Manager','Both')][string]$App='Both',[switch]$Run,[switch]$Build)
$ErrorActionPreference='Stop'
$base=$PSScriptRoot
function Find-Dotnet {
 $candidates=@()
 if ($env:DOTNET_ROOT) { $candidates+= (Join-Path $env:DOTNET_ROOT 'dotnet.exe') }
 $candidates+= (Join-Path $base 'tools\dotnet\dotnet.exe')
 $candidates+= (Join-Path $HOME '.dotnet\dotnet.exe')
 $candidates+= "$env:ProgramFiles\dotnet\dotnet.exe"
 $cmd=Get-Command dotnet -ErrorAction SilentlyContinue
 if ($cmd) {$candidates+=$cmd.Source}
 foreach($candidate in $candidates) {
  if (!(Test-Path $candidate)) {continue}
  $sdks=@(& $candidate --list-sdks 2>$null)
  if ($LASTEXITCODE -eq 0 -and ($sdks | Where-Object {$_ -match '^8\.'})) {return $candidate}
 }
 return $null
}
$dotnet=Find-Dotnet
$projects=@()
if ($App -in @('Agent','Both')) {$projects+=@{Name='Agent';Dir='Cofidis_Espana_WPF';Project='Cofidis_Espana.csproj';Exe='Cofidis_Espana.exe'}}
if ($App -in @('Manager','Both')) {$projects+=@{Name='Manager';Dir='Cofidis_Espana_Manager';Project='Cofidis_Espana_Manager.csproj';Exe='Cofidis_Espana_Manager.exe'}}
foreach($p in $projects) {
 $dir=Join-Path $base $p.Dir
 $exe=Join-Path $dir ('bin\Release\net8.0-windows\'+$p.Exe)
 $publish=Join-Path $dir ('bin\Release\net8.0-windows\win-x64\publish\'+$p.Exe)
 if ($Build -or (!$Run -and $dotnet)) {
  if (!$dotnet) {Write-Warning "SDK .NET 8 absent: compilation impossible pour $($p.Name).";continue}
  Write-Host "Compilation $($p.Name) avec $dotnet" -ForegroundColor Cyan
  & $dotnet publish (Join-Path $dir $p.Project) -c Release -r win-x64 --self-contained false -p:PublishSingleFile=false
  if ($LASTEXITCODE -ne 0) {Write-Warning "Echec de compilation $($p.Name)";continue}
 }
 if ($Run -or (!$Build -and !$dotnet)) {
  $target=if(Test-Path $publish){$publish}else{$exe}
  if(Test-Path $target) {Write-Host "Lancement $($p.Name): $target" -ForegroundColor Green;Start-Process -FilePath $target -WorkingDirectory (Split-Path $target)}
  else {Write-Warning "Executable absent pour $($p.Name)"}
 }
}
if (!$dotnet) {Write-Host 'SDK .NET 8 introuvable. Pour compiler, placer un SDK portable dans tools\dotnet ou configurer DOTNET_ROOT.' -ForegroundColor Yellow}
