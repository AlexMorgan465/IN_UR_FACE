COFIDIS ESPANA - ADAPTATION PORTABLE

1. Les sources C#/XAML et executables precompiles sont conserves.
2. LANCER_AGENT.cmd et LANCER_MANAGER.cmd lancent les versions precompilees.
3. COMPILER.cmd tente de compiler les deux applications avec un SDK .NET 8.
4. Le SDK .NET 8 peut etre place dans tools\dotnet\ (dotnet.exe) ou dans ~/.dotnet, sans installation systeme.
5. Pour executer les binaires existants, le runtime Windows Desktop .NET 8 doit etre present. Le SDK seul n est pas requis.
6. Si aucun runtime Desktop .NET 8 n est installe, utiliser un SDK portable pour publier en --self-contained true, puis distribuer le dossier publish complet.
7. Ce package ne contient PAS le SDK et ne contourne aucun controle de securite.
8. Les fichiers config.json definissent les chemins de donnees; verifier avant usage.
9. ATTENTION: le verrouillage de session multi-postes et les droits d acces au partage doivent etre testes avant production.
10. Les executables inclus proviennent de l archive originale; aucune compilation Windows n a ete effectuee ici.
