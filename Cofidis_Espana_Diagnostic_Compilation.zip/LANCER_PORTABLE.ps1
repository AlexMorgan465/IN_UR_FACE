﻿param([ValidateSet('Agent','Manager','Both')][string]$App='Both',[switch]$Build)
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
function Find-Dotnet {
 $candidates=@()
 if($env:DOTNET_ROOT){$candidates+=Join-Path $env:DOTNET_ROOT 'dotnet.exe'}
 $candidates+=Join-Path $root 'dotnet\dotnet.exe'
 $candidates+=Join-Path $root 'sdk\dotnet.exe'
 $candidates+=Join-Path $env:USERPROFILE '.dotnet\dotnet.exe'
 if($env:ProgramFiles){$candidates+=Join-Path $env:ProgramFiles 'dotnet\dotnet.exe'}
 $cmd=Get-Command dotnet.exe -ErrorAction SilentlyContinue
 if($cmd){$candidates+=$cmd.Source}
 foreach($p in ($candidates|Select-Object -Unique)){
  if(!(Test-Path $p)){continue}
  $sdks=@(& $p --list-sdks 2>$null)
  if($sdks -match '^8\.'){return $p}
 }
 return $null
}
$dotnet=Find-Dotnet
if(!$dotnet){
 Write-Host 'SDK .NET 8 introuvable (y compris les emplacements portables).' -ForegroundColor Yellow
 Write-Host 'Le compilateur csc.exe du Framework 4.8 utilise par Epithete ne peut pas compiler directement ce projet XAML net8.'
 Write-Host 'Placez une distribution autorisee du SDK .NET 8 dans le dossier dotnet a cote de ce script, ou utilisez un poste de compilation autorise.'
 if($Build){exit 2}
}
$apps=if($App -eq 'Both'){@('Agent','Manager')}else{@($App)}
foreach($a in $apps){
 $dir=if($a -eq 'Agent'){'Cofidis_Espana_WPF'}else{'Cofidis_Espana_Manager'}
 $project=if($a -eq 'Agent'){'Cofidis_Espana.csproj'}else{'Cofidis_Espana_Manager.csproj'}
 $exe=if($a -eq 'Agent'){'Cofidis_Espana.exe'}else{'Cofidis_Espana_Manager.exe'}
 $projPath=Join-Path $root "$dir\$project"
 if($Build){
  Write-Host "Compilation $a..." -ForegroundColor Cyan
  & $dotnet publish $projPath -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o (Join-Path $root "sortie\$a")
  if($LASTEXITCODE -ne 0){throw "Echec compilation $a"}
  Write-Host "Compilation $a terminee." -ForegroundColor Green
 }else{
  $choices=@((Join-Path $root "sortie\$a\$exe"),(Join-Path $root "$dir\bin\Release\net8.0-windows\win-x64\publish\$exe"),(Join-Path $root "$dir\bin\Release\net8.0-windows\win-x64\$exe"),(Join-Path $root "$dir\bin\Release\net8.0-windows\$exe"))
  $target=$choices|Where-Object {Test-Path $_}|Select-Object -First 1
  if(!$target){Write-Host "Executable $a introuvable. Compilez d'abord sur un poste avec SDK." -ForegroundColor Red;continue}
  Write-Host "Lancement $a : $target"
  Start-Process -FilePath $target -WorkingDirectory (Split-Path $target)
 }
}
