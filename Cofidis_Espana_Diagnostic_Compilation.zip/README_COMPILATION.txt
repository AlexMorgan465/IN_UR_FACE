Cofidis Espagne - diagnostic et compilation

COMPILER.cmd : necessite le SDK .NET 8, eventuellement portable dans ./dotnet/.
LANCER_AGENT.cmd et LANCER_MANAGER.cmd : lancent les executables existants.
La compilation de projets XAML net8 avec le seul csc.exe du .NET Framework 4.8 n est pas prise en charge.
Une publication self-contained requiert le SDK et la disponibilite des packages NuGet sur le poste de compilation.
Les executables preexistants ne sont pas des publications self-contained et peuvent necessiter le runtime Desktop .NET 8.
Aucune compilation Windows n a ete executee dans cet environnement.
