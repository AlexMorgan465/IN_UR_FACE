$ErrorActionPreference = 'Continue'
Write-Host 'Verification de Java...' -ForegroundColor Cyan
Get-Command java,javac,jar -ErrorAction SilentlyContinue | Select-Object Name,Source
java -version
javac -version
Read-Host 'Entree pour fermer'
