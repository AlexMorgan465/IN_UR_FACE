$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Test-Path 'Calculatrice.jar')) { throw 'Calculatrice.jar absent. Lancez Compiler.ps1.' }
& java -jar Calculatrice.jar
if ($LASTEXITCODE -ne 0) { throw 'Execution Java echouee.' }
