$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Get-Command javac -ErrorAction SilentlyContinue)) { throw 'JDK absent : javac introuvable. Demandez un JDK approuve a votre equipe IT.' }
if (-not (Get-Command jar -ErrorAction SilentlyContinue)) { throw 'Outil jar introuvable.' }
& javac -encoding UTF-8 Calculatrice.java
if ($LASTEXITCODE -ne 0) { throw 'Compilation Java echouee.' }
& jar --create --file Calculatrice.jar --main-class Calculatrice Calculatrice.class
if ($LASTEXITCODE -ne 0) { throw 'Creation JAR echouee.' }
Write-Host 'Compilation reussie : Calculatrice.jar' -ForegroundColor Green
