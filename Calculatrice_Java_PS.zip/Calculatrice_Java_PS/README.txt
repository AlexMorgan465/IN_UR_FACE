TEST CALCULATRICE JAVA + POWERSHELL

1. Ouvrir PowerShell 7 dans ce dossier.
2. Executer : .\Verifier.ps1
3. Si un JDK approuve est installe : .\Compiler.ps1
4. Puis : .\Lancer.ps1

Alternative sans script :
  javac -encoding UTF-8 Calculatrice.java
  java Calculatrice

Un JDK est necessaire pour compiler. Un runtime Java suffit pour lancer le JAR.
Ce projet ne contourne pas les controles de securite. Faites valider l'execution par l'equipe IT si necessaire.
