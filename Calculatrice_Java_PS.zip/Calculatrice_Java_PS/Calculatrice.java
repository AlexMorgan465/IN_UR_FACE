import javax.swing.*;
import java.awt.*;

public class Calculatrice {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(Calculatrice::createUI);
    }
    private static void createUI() {
        JFrame frame = new JFrame("Calculatrice Java - Test");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(360, 210);
        frame.setLocationRelativeTo(null);
        JPanel panel = new JPanel(new GridLayout(4, 2, 8, 8));
        panel.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        JTextField a = new JTextField("10");
        JTextField b = new JTextField("2");
        JComboBox<String> operation = new JComboBox<>(new String[]{"+", "-", "*", "/"});
        JLabel result = new JLabel("Resultat : ");
        JButton calculate = new JButton("Calculer");
        calculate.addActionListener(e -> {
            try {
                double x = Double.parseDouble(a.getText().trim().replace(',', '.'));
                double y = Double.parseDouble(b.getText().trim().replace(',', '.'));
                String op = (String) operation.getSelectedItem();
                double value;
                switch (op) {
                    case "-": value = x - y; break;
                    case "*": value = x * y; break;
                    case "/":
                        if (y == 0) { result.setText("Division par zero impossible"); return; }
                        value = x / y; break;
                    default: value = x + y;
                }
                result.setText("Resultat : " + value);
            } catch (NumberFormatException ex) {
                result.setText("Saisir deux nombres valides");
            }
        });
        panel.add(new JLabel("Nombre 1")); panel.add(a);
        panel.add(new JLabel("Nombre 2")); panel.add(b);
        panel.add(operation); panel.add(calculate);
        panel.add(result); panel.add(new JLabel(""));
        frame.setContentPane(panel);
        frame.setVisible(true);
    }
}
