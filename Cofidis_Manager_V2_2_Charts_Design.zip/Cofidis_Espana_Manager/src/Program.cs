using System;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Markup;

namespace Cofidis_Espana_Manager
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            try
            {
                Application app = new Application();
                app.DispatcherUnhandledException += delegate(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
                {
                    MessageBox.Show(e.Exception.Message, "Cofidis España Manager — error", MessageBoxButton.OK, MessageBoxImage.Error);
                    e.Handled = true;
                };
                Window ventana;
                using (Stream flujo = Assembly.GetExecutingAssembly().GetManifestResourceStream("Manager.MainWindow.xaml"))
                {
                    if (flujo == null) throw new InvalidOperationException("Interfaz incrustada no encontrada.");
                    ventana = (Window)XamlReader.Load(flujo);
                }
                new MainController(ventana);
                app.Run(ventana);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Cofidis España Manager — inicio imposible", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
