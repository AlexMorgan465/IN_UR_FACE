using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;

namespace Cofidis_Espana_Manager
{
    public sealed class ResultadoLectura
    {
        public ResultadoLectura() { Datos = new List<Tratamiento>(); Errores = new List<string>(); }
        public List<Tratamiento> Datos { get; private set; }
        public List<string> Errores { get; private set; }
    }

    public sealed class Lector
    {
        public string Raiz { get; private set; }

        public static string ArchivoConfiguracion
        {
            get { return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "config.json"); }
        }

        private static JavaScriptSerializer Serializador()
        {
            return new JavaScriptSerializer { MaxJsonLength = int.MaxValue, RecursionLimit = 100 };
        }

        public Lector()
        {
            string cfg = ArchivoConfiguracion;
            if (!File.Exists(cfg)) throw new FileNotFoundException("No se encuentra config.json", cfg);
            var datos = Serializador().Deserialize<Dictionary<string, object>>(File.ReadAllText(cfg, Encoding.UTF8));
            object valor;
            if (datos == null || !datos.TryGetValue("RutaDatos", out valor) || valor == null || string.IsNullOrWhiteSpace(valor.ToString()))
                throw new InvalidDataException("RutaDatos vacía");
            Raiz = Path.GetFullPath(Environment.ExpandEnvironmentVariables(valor.ToString()));
        }

        // Comprueba que la carpeta existe (el panel solo lee) y guarda la ruta en config.json.
        public static void GuardarRuta(string ruta)
        {
            if (string.IsNullOrWhiteSpace(ruta)) throw new ArgumentException("La ruta está vacía.");
            string completa = Path.GetFullPath(Environment.ExpandEnvironmentVariables(ruta.Trim()));
            if (!Directory.Exists(completa)) throw new DirectoryNotFoundException("La carpeta no existe o no es accesible: " + completa);
            string texto = "{\r\n  \"RutaDatos\": " + Serializador().Serialize(ruta.Trim()) + "\r\n}";
            // Escritura directa (sin temporal ni renombrado).
            byte[] bytes = new UTF8Encoding(false).GetBytes(texto);
            using (var f = new FileStream(ArchivoConfiguracion, FileMode.OpenOrCreate, FileAccess.Write, FileShare.None))
            {
                f.Write(bytes, 0, bytes.Length);
                f.SetLength(bytes.Length);
            }
        }

        public ResultadoLectura Leer()
        {
            var res = new ResultadoLectura();
            if (!Directory.Exists(Raiz)) { res.Errores.Add("La carpeta no existe: " + Raiz); return res; }
            foreach (string archivo in Directory.EnumerateFiles(Raiz, "*.json", SearchOption.AllDirectories))
            {
                if (Path.GetFileName(archivo).Equals("config.json", StringComparison.OrdinalIgnoreCase)) continue;
                try { res.Datos.AddRange(LeerArchivo(archivo)); }
                catch (Exception ex) { res.Errores.Add(Path.GetFileName(archivo) + ": " + ex.Message); }
            }
            // Si un archivo se copio dos veces, un mismo ID se contabiliza una sola vez.
            var unicos = res.Datos.GroupBy(x => string.IsNullOrWhiteSpace(x.Id) ? Guid.NewGuid().ToString() : x.Id).Select(g => g.First()).ToList();
            res.Datos.Clear();
            res.Datos.AddRange(unicos);
            return res;
        }

        private static List<Tratamiento> LeerArchivo(string ruta)
        {
            string texto;
            // Lectura permitiendo que un agente escriba a la vez; solo lectura, nunca modifica el archivo.
            using (var fs = new FileStream(ruta, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
            using (var sr = new StreamReader(fs, Encoding.UTF8, true))
                texto = sr.ReadToEnd();
            object raizJson = Serializador().DeserializeObject(texto);
            var elementos = raizJson as IEnumerable;
            if (elementos == null || raizJson is string) throw new InvalidDataException("Archivo JSON sin registros");
            var lista = new List<Tratamiento>();
            foreach (object elemento in elementos)
            {
                var d = elemento as Dictionary<string, object>;
                if (d == null) throw new InvalidDataException("Formato JSON inesperado");
                var t = new Tratamiento();
                t.Id = Texto(d, "Id", "");
                t.Usuario = Texto(d, "Usuario", "");
                t.Referencia = Texto(d, "Referencia", "");
                t.Taf = Texto(d, "Taf", "");
                t.Decision = Texto(d, "Decision", "");
                t.Comentario = Texto(d, "Comentario", "");
                t.Estado = Texto(d, "Estado", "");
                t.FechaInicio = Fecha(Texto(d, "FechaInicio", null)) ?? default(DateTime);
                t.FechaFin = Fecha(Texto(d, "FechaFin", null));
                lista.Add(t);
            }
            return lista;
        }

        private static string Texto(Dictionary<string, object> d, string clave, string porDefecto)
        {
            foreach (var par in d)
                if (string.Equals(par.Key, clave, StringComparison.OrdinalIgnoreCase))
                    return par.Value == null ? porDefecto : par.Value.ToString();
            return porDefecto;
        }

        private static DateTime? Fecha(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto)) return null;
            DateTime f;
            if (DateTime.TryParse(texto, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out f)) return f;
            return null;
        }
    }
}
