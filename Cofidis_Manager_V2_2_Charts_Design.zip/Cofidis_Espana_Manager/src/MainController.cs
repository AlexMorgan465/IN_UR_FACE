using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace Cofidis_Espana_Manager
{
    // Logica del panel. La interfaz se carga desde ui\MainWindow.xaml (incrustado en el EXE).
    internal sealed class MainController
    {
        private readonly Window ventana;
        private List<Tratamiento> todos = new List<Tratamiento>();
        private List<Tratamiento> filtrados = new List<Tratamiento>();
        private List<EstadisticaDia> estadisticas = new List<EstadisticaDia>();
        private bool inicializando = true;
        private Lector lector;
        private static readonly string[] Decisiones = { "sin información para pre-estudio", "RExBU", "RExB1", "RExIG", "RExRECIENTE", "RExNT", "RExPR", "RExVEDACON", "RExFICHEROS NEG", "RExTIPO CTTO", "RExSCORE", "RExRIESGO", "RExLI", "RExAN", "RExBQ" };

        private readonly DatePicker desde, hasta;
        private readonly ComboBox agente, taf, estado;
        private readonly TextBlock rutaTexto, estadoTexto, kpiTotal, kpiFinal, kpiCurso, kpiDmt, kpiAgentes;
        private readonly ItemsControl barrasDecision, barrasTaf, barrasDmt;
        private readonly DataGrid evolucion, tablaDetalle, tablaStats;
        private readonly Canvas chartCanvas;
        private readonly ComboBox chartType;
        private static readonly string[] ColoresGrafico = { "#CC0033", "#E3A52F", "#287C8E", "#5969B0", "#7A5195", "#2D9B75", "#E07845", "#718096", "#D65A7A", "#3F879E" };

        private T Obtener<T>(string nombre) where T : class
        {
            T elemento = ventana.FindName(nombre) as T;
            if (elemento == null) throw new InvalidOperationException("Elemento de interfaz no encontrado: " + nombre);
            return elemento;
        }

        public MainController(Window ventana)
        {
            this.ventana = ventana;
            desde = Obtener<DatePicker>("Desde");
            hasta = Obtener<DatePicker>("Hasta");
            agente = Obtener<ComboBox>("Agente");
            taf = Obtener<ComboBox>("Taf");
            estado = Obtener<ComboBox>("Estado");
            rutaTexto = Obtener<TextBlock>("RutaTexto");
            estadoTexto = Obtener<TextBlock>("EstadoTexto");
            kpiTotal = Obtener<TextBlock>("KpiTotal");
            kpiFinal = Obtener<TextBlock>("KpiFinal");
            kpiCurso = Obtener<TextBlock>("KpiCurso");
            kpiDmt = Obtener<TextBlock>("KpiDmt");
            kpiAgentes = Obtener<TextBlock>("KpiAgentes");
            barrasDecision = Obtener<ItemsControl>("BarrasDecision");
            barrasTaf = Obtener<ItemsControl>("BarrasTaf");
            barrasDmt = Obtener<ItemsControl>("BarrasDmt");
            evolucion = Obtener<DataGrid>("Evolucion");
            tablaDetalle = Obtener<DataGrid>("TablaDetalle");
            tablaStats = Obtener<DataGrid>("TablaStats");
            chartCanvas = Obtener<Canvas>("ChartCanvas");
            chartType = Obtener<ComboBox>("ChartType");
            chartType.SelectionChanged += delegate { RenderChart(); };
            chartCanvas.SizeChanged += delegate { RenderChart(); };

            Obtener<Button>("ActualizarBoton").Click += delegate { Actualizar(); };
            Obtener<Button>("LimpiarBoton").Click += Limpiar_Click;
            Obtener<Button>("AjustesBoton").Click += Ajustes_Click;
            Obtener<Button>("CsvDetalleBoton").Click += delegate { Exportar(false, false); };
            Obtener<Button>("XlsxDetalleBoton").Click += delegate { Exportar(true, false); };
            Obtener<Button>("CsvStatsBoton").Click += delegate { Exportar(false, true); };
            Obtener<Button>("XlsxStatsBoton").Click += delegate { Exportar(true, true); };
            SelectionChangedEventHandler filtro = delegate { if (!inicializando) Filtrar(); };
            EventHandler<SelectionChangedEventArgs> filtroFecha = delegate { if (!inicializando) Filtrar(); };
            desde.SelectedDateChanged += filtroFecha;
            hasta.SelectedDateChanged += filtroFecha;
            agente.SelectionChanged += filtro;
            taf.SelectionChanged += filtro;
            estado.SelectionChanged += filtro;

            try { lector = new Lector(); rutaTexto.Text = lector.Raiz; }
            catch (Exception ex)
            {
                MessageBox.Show("Error en config.json: " + ex.Message + "\n\nPuede corregir la ruta con el botón de ajustes.");
                lector = null;
                inicializando = false;
                return;
            }
            inicializando = false;
            Actualizar();
        }

        private static List<string> ConTodos(IEnumerable<string> valores)
        {
            return new[] { "Todos" }.Concat(valores.Where(x => !string.IsNullOrWhiteSpace(x)).Distinct().OrderBy(x => x)).ToList();
        }

        private void Actualizar()
        {
            if (lector == null) return;
            try
            {
                var lectura = lector.Leer();
                todos = lectura.Datos;
                inicializando = true;
                string a = agente.SelectedItem as string, t = taf.SelectedItem as string, s = estado.SelectedItem as string;
                agente.ItemsSource = ConTodos(todos.Select(x => x.Usuario));
                taf.ItemsSource = ConTodos(todos.Select(x => x.Taf));
                estado.ItemsSource = ConTodos(todos.Select(x => x.Estado));
                agente.SelectedItem = (a != null && agente.Items.Contains(a)) ? a : "Todos";
                taf.SelectedItem = (t != null && taf.Items.Contains(t)) ? t : "Todos";
                estado.SelectedItem = (s != null && estado.Items.Contains(s)) ? s : "Todos";
                inicializando = false;
                Filtrar();
                estadoTexto.Text = todos.Count + " registros cargados · " + lectura.Errores.Count + " archivo(s) con error";
                if (lectura.Errores.Count > 0)
                    MessageBox.Show("Algunos archivos no se pudieron leer:\n" + string.Join("\n", lectura.Errores.Take(8)), "Advertencia", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            catch (Exception ex) { inicializando = false; MessageBox.Show("Error al actualizar: " + ex.Message); }
        }

        private void Limpiar_Click(object sender, RoutedEventArgs e)
        {
            inicializando = true;
            desde.SelectedDate = null; hasta.SelectedDate = null;
            agente.SelectedItem = "Todos"; taf.SelectedItem = "Todos"; estado.SelectedItem = "Todos";
            inicializando = false;
            Filtrar();
        }

        private void Ajustes_Click(object sender, RoutedEventArgs e)
        {
            var dialogo = new AjustesVentana(lector != null ? lector.Raiz : string.Empty) { Owner = ventana };
            if (dialogo.ShowDialog() != true) return;
            try
            {
                lector = new Lector();
                rutaTexto.Text = lector.Raiz;
                Actualizar();
            }
            catch (Exception ex) { MessageBox.Show("No se pudo aplicar la nueva ruta:\n" + ex.Message); }
        }

        private static bool EsFinalizado(Tratamiento x)
        {
            return x.FechaFin.HasValue && (x.Estado.Equals("Finalizado", StringComparison.OrdinalIgnoreCase) || x.Estado.Equals("Terminado", StringComparison.OrdinalIgnoreCase) || x.Estado.Equals("Termine", StringComparison.OrdinalIgnoreCase) || x.Estado.Equals("Terminé", StringComparison.OrdinalIgnoreCase));
        }

        private void Filtrar()
        {
            DateTime? d = desde.SelectedDate, h = hasta.SelectedDate;
            string a = (agente.SelectedItem as string) ?? "Todos", t = (taf.SelectedItem as string) ?? "Todos", s = (estado.SelectedItem as string) ?? "Todos";
            filtrados = todos.Where(x => (!d.HasValue || x.FechaInicio.Date >= d.Value.Date) && (!h.HasValue || x.FechaInicio.Date <= h.Value.Date)
                && (a == "Todos" || x.Usuario == a) && (t == "Todos" || x.Taf == t) && (s == "Todos" || x.Estado == s)).OrderByDescending(x => x.FechaInicio).ToList();
            tablaDetalle.ItemsSource = filtrados;
            var terminados = filtrados.Where(x => EsFinalizado(x)).ToList();
            kpiTotal.Text = filtrados.Count.ToString("N0");
            kpiFinal.Text = terminados.Count.ToString("N0");
            kpiCurso.Text = filtrados.Count(x => !x.FechaFin.HasValue).ToString("N0");
            kpiAgentes.Text = filtrados.Select(x => x.Usuario).Distinct().Count().ToString();
            kpiDmt.Text = terminados.Count == 0 ? "-" : TimeSpan.FromSeconds(terminados.Average(x => x.DmtSegundos ?? 0)).ToString(@"hh\:mm\:ss");
            estadisticas = terminados.GroupBy(x => x.FechaInicio.Date).OrderBy(g => g.Key).Select(g => CrearEstadistica(g.Key, g.ToList())).ToList();
            tablaStats.ItemsSource = estadisticas;
            evolucion.ItemsSource = estadisticas;
            barrasDecision.ItemsSource = CrearBarras(terminados.GroupBy(x => x.Decision).Where(g => !string.IsNullOrWhiteSpace(g.Key)).Select(g => new KeyValuePair<string, double>(g.Key, g.Count())));
            barrasTaf.ItemsSource = CrearBarras(terminados.GroupBy(x => x.Taf).Select(g => new KeyValuePair<string, double>(g.Key, g.Count())));
            barrasDmt.ItemsSource = CrearBarras(terminados.GroupBy(x => x.Taf).Select(g => new KeyValuePair<string, double>(g.Key, g.Average(x => x.DmtSegundos ?? 0))));
            RenderChart();
        }

        private Brush Pinceau(string couleur)
        {
            return (Brush)new BrushConverter().ConvertFromString(couleur);
        }

        private void AjouterTexte(string texte, double x, double y, double taille, Brush couleur, bool gras)
        {
            var bloc = new TextBlock { Text = texte, FontSize = taille, Foreground = couleur, FontWeight = gras ? FontWeights.SemiBold : FontWeights.Normal, TextTrimming = TextTrimming.CharacterEllipsis, MaxWidth = 180 };
            Canvas.SetLeft(bloc, x); Canvas.SetTop(bloc, y); chartCanvas.Children.Add(bloc);
        }

        private void RenderChart()
        {
            if (chartCanvas == null) return;
            double largeur = chartCanvas.ActualWidth, hauteur = chartCanvas.ActualHeight;
            if (largeur < 180 || hauteur < 120) return;
            chartCanvas.Children.Clear();
            var finis = filtrados.Where(x => EsFinalizado(x)).ToList();
            int index = chartType == null ? 0 : chartType.SelectedIndex;
            if (index == 1) DessinerBarres(finis.GroupBy(x => x.Usuario).Select(g => new KeyValuePair<string, double>(g.Key, g.Count())).OrderByDescending(x => x.Value).Take(12).ToList(), "Traitements finalisés par agent", largeur, hauteur, true);
            else if (index == 2) DessinerLigne(estadisticas.Select(x => new KeyValuePair<string, double>(x.Fecha, x.Tratados)).ToList(), "Évolution quotidienne des traitements", largeur, hauteur);
            else if (index == 3) DessinerBarres(finis.GroupBy(x => x.Taf).Select(g => new KeyValuePair<string, double>(g.Key, g.Count())).OrderByDescending(x => x.Value).Take(12).ToList(), "Volume des traitements par TAF", largeur, hauteur, false);
            else DessinerAnneau(finis, largeur, hauteur);
        }

        private void DessinerAnneau(List<Tratamiento> items, double largeur, double hauteur)
        {
            AjouterTexte("Répartition des décisions", 18, 10, 14, Pinceau("#243650"), true);
            var donnees = items.Where(x => !string.IsNullOrWhiteSpace(x.Decision)).GroupBy(x => x.Decision.Trim()).Select(g => new { Nom = g.Key, Valeur = g.Count() }).OrderByDescending(g => g.Valeur).Take(9).ToList();
            double total = donnees.Sum(x => x.Valeur);
            if (total <= 0) { AjouterTexte("Aucune donnée disponible pour les filtres sélectionnés", 24, 90, 13, Pinceau("#718096"), false); return; }
            double cx = Math.Min(largeur * 0.34, 230), cy = hauteur * 0.55, rayon = Math.Min(hauteur * 0.37, 112), angle = -90;
            for (int i = 0; i < donnees.Count; i++)
            {
                double sweep = donnees[i].Valeur / total * 359.8;
                double a1 = angle * Math.PI / 180.0, a2 = (angle + sweep) * Math.PI / 180.0;
                var centre = new Point(cx, cy);
                var debut = new Point(cx + rayon * Math.Cos(a1), cy + rayon * Math.Sin(a1));
                var fin = new Point(cx + rayon * Math.Cos(a2), cy + rayon * Math.Sin(a2));
                var geo = new StreamGeometry();
                using (var ctx = geo.Open()) { ctx.BeginFigure(centre, true, true); ctx.LineTo(debut, true, true); ctx.ArcTo(fin, new Size(rayon, rayon), 0, sweep > 180, SweepDirection.Clockwise, true, true); }
                geo.Freeze();
                chartCanvas.Children.Add(new Path { Data = geo, Fill = Pinceau(ColoresGrafico[i % ColoresGrafico.Length]), Stroke = Brushes.White, StrokeThickness = 2 });
                angle += sweep;
            }
            chartCanvas.Children.Add(new Ellipse { Width = rayon * 1.18, Height = rayon * 1.18, Fill = Brushes.White, Stroke = Pinceau("#EEF1F6"), StrokeThickness = 1 });
            AjouterTexte(total.ToString("N0"), cx - 30, cy - 18, 23, Pinceau("#172B4D"), true);
            AjouterTexte("traitements", cx - 37, cy + 10, 10, Pinceau("#718096"), false);
            double lx = Math.Min(largeur * 0.58, 420), ly = 38;
            for (int i = 0; i < donnees.Count; i++)
            {
                chartCanvas.Children.Add(new Ellipse { Width = 10, Height = 10, Fill = Pinceau(ColoresGrafico[i % ColoresGrafico.Length]) });
                Canvas.SetLeft(chartCanvas.Children[chartCanvas.Children.Count - 1], lx);
                Canvas.SetTop(chartCanvas.Children[chartCanvas.Children.Count - 1], ly + i * 25 + 4);
                AjouterTexte(donnees[i].Nom, lx + 18, ly + i * 25, 11, Pinceau("#394B63"), false);
                AjouterTexte(donnees[i].Valeur.ToString("N0") + "  ·  " + (donnees[i].Valeur * 100.0 / total).ToString("0.0") + "%", Math.Min(largeur - 105, lx + 205), ly + i * 25, 10, Pinceau("#718096"), true);
            }
        }

        private void DessinerBarres(List<KeyValuePair<string, double>> donnees, string titre, double largeur, double hauteur, bool vertical)
        {
            AjouterTexte(titre, 18, 10, 14, Pinceau("#243650"), true);
            if (donnees.Count == 0) { AjouterTexte("Aucune donnée disponible pour les filtres sélectionnés", 24, 90, 13, Pinceau("#718096"), false); return; }
            double max = Math.Max(1, donnees.Max(x => x.Value));
            if (vertical)
            {
                double gauche = 55, bas = hauteur - 48, zoneH = hauteur - 105, slot = Math.Max(24, (largeur - 90) / donnees.Count), bw = Math.Min(42, slot * 0.62);
                for (int i = 0; i < 4; i++) { double y = bas - zoneH * i / 3.0; var ligne = new System.Windows.Shapes.Line { X1 = gauche, X2 = largeur - 18, Y1 = y, Y2 = y, Stroke = Pinceau("#E9EDF3"), StrokeThickness = 1 }; chartCanvas.Children.Add(ligne); }
                for (int i = 0; i < donnees.Count; i++)
                {
                    double h = zoneH * donnees[i].Value / max, x = gauche + i * slot + (slot - bw) / 2;
                    chartCanvas.Children.Add(new Rectangle { Width = bw, Height = Math.Max(2, h), Fill = Pinceau(ColoresGrafico[i % ColoresGrafico.Length]), RadiusX = 5, RadiusY = 5 });
                    Canvas.SetLeft(chartCanvas.Children[chartCanvas.Children.Count - 1], x); Canvas.SetTop(chartCanvas.Children[chartCanvas.Children.Count - 1], bas - h);
                    AjouterTexte(donnees[i].Value.ToString("N0"), x - 4, bas - h - 20, 10, Pinceau("#394B63"), true);
                    AjouterTexte(donnees[i].Key, x - 14, bas + 8, 9, Pinceau("#718096"), false);
                }
            }
            else
            {
                double y0 = 43, row = Math.Min(29, (hauteur - 55) / donnees.Count), x0 = Math.Min(largeur * 0.36, 240), zone = largeur - x0 - 75;
                for (int i = 0; i < donnees.Count; i++)
                {
                    double y = y0 + i * row, w = Math.Max(2, zone * donnees[i].Value / max);
                    AjouterTexte(donnees[i].Key, 15, y, 10, Pinceau("#394B63"), false);
                    chartCanvas.Children.Add(new Border { Width = zone, Height = 12, Background = Pinceau("#F0F3F8"), CornerRadius = new CornerRadius(6) });
                    Canvas.SetLeft(chartCanvas.Children[chartCanvas.Children.Count - 1], x0); Canvas.SetTop(chartCanvas.Children[chartCanvas.Children.Count - 1], y + 2);
                    chartCanvas.Children.Add(new Border { Width = w, Height = 12, Background = Pinceau(ColoresGrafico[i % ColoresGrafico.Length]), CornerRadius = new CornerRadius(6) });
                    Canvas.SetLeft(chartCanvas.Children[chartCanvas.Children.Count - 1], x0); Canvas.SetTop(chartCanvas.Children[chartCanvas.Children.Count - 1], y + 2);
                    AjouterTexte(donnees[i].Value.ToString("N0"), x0 + zone + 8, y, 10, Pinceau("#394B63"), true);
                }
            }
        }

        private void DessinerLigne(List<KeyValuePair<string, double>> donnees, string titre, double largeur, double hauteur)
        {
            AjouterTexte(titre, 18, 10, 14, Pinceau("#243650"), true);
            if (donnees.Count == 0) { AjouterTexte("Aucune donnée disponible pour les filtres sélectionnés", 24, 90, 13, Pinceau("#718096"), false); return; }
            double gauche = 55, droite = largeur - 25, haut = 48, bas = hauteur - 45, max = Math.Max(1, donnees.Max(x => x.Value));
            var points = new PointCollection();
            for (int i = 0; i < 5; i++) { double y = bas - (bas - haut) * i / 4.0; chartCanvas.Children.Add(new System.Windows.Shapes.Line { X1 = gauche, X2 = droite, Y1 = y, Y2 = y, Stroke = Pinceau("#E9EDF3"), StrokeThickness = 1 }); }
            for (int i = 0; i < donnees.Count; i++)
            {
                double x = donnees.Count == 1 ? (gauche + droite) / 2 : gauche + (droite - gauche) * i / (donnees.Count - 1);
                double y = bas - (bas - haut) * donnees[i].Value / max;
                points.Add(new Point(x, y));
                if (i == 0 || i == donnees.Count - 1 || i % Math.Max(1, donnees.Count / 6) == 0) AjouterTexte(donnees[i].Key, x - 28, bas + 9, 9, Pinceau("#718096"), false);
            }
            if (points.Count > 1) chartCanvas.Children.Add(new Polyline { Points = points, Stroke = Pinceau("#CC0033"), StrokeThickness = 3, StrokeLineJoin = PenLineJoin.Round });
            for (int i = 0; i < points.Count; i++)
            {
                chartCanvas.Children.Add(new Ellipse { Width = 8, Height = 8, Fill = Brushes.White, Stroke = Pinceau("#CC0033"), StrokeThickness = 2 });
                Canvas.SetLeft(chartCanvas.Children[chartCanvas.Children.Count - 1], points[i].X - 4);
                Canvas.SetTop(chartCanvas.Children[chartCanvas.Children.Count - 1], points[i].Y - 4);
            }
        }

        private static List<Barra> CrearBarras(IEnumerable<KeyValuePair<string, double>> origen)
        {
            var lista = origen.OrderByDescending(x => x.Value).Take(18).ToList();
            double max = lista.Count == 0 ? 1 : Math.Max(1, lista.Max(x => x.Value));
            return lista.Select(x => new Barra { Nombre = x.Key, Valor = x.Value.ToString("N0"), Anchura = Math.Max(2, x.Value / max * 220) }).ToList();
        }

        private static EstadisticaDia CrearEstadistica(DateTime dia, List<Tratamiento> items)
        {
            Func<string, int> contar = decision => items.Count(x => string.Equals(x.Decision.Trim(), decision, StringComparison.OrdinalIgnoreCase));
            int rechazados = Decisiones.Skip(1).Sum(x => contar(x));
            int sinInfo = contar("sin información para pre-estudio");
            return new EstadisticaDia
            {
                Fecha = dia.ToString("dd/MM/yyyy"), Tratados = items.Count, SinInformacion = sinInfo,
                RExBU = contar("RExBU"), RExB1 = contar("RExB1"), RExIG = contar("RExIG"), RExRECIENTE = contar("RExRECIENTE"),
                RExNT = contar("RExNT"), RExPR = contar("RExPR"), RExVEDACON = contar("RExVEDACON"),
                RExFICHEROSNEG = contar("RExFICHEROS NEG"), RExTIPOCTTO = contar("RExTIPO CTTO"), RExSCORE = contar("RExSCORE"),
                RExRIESGO = contar("RExRIESGO"), RExLI = contar("RExLI"), RExAN = contar("RExAN"), RExBQ = contar("RExBQ"),
                OkParaEstudio = items.Count - rechazados - sinInfo,
                PorcentajeRechazo = items.Count == 0 ? 0 : (double)rechazados / items.Count
            };
        }

        private void Exportar(bool excel, bool stats)
        {
            try
            {
                var dialog = new SaveFileDialog
                {
                    Title = stats ? "Exportar estadísticas" : "Exportar consolidación",
                    Filter = excel ? "Excel (*.xlsx)|*.xlsx" : "CSV (*.csv)|*.csv",
                    FileName = (stats ? "estadisticas_" : "consolidacion_") + DateTime.Now.ToString("yyyyMMdd") + (excel ? ".xlsx" : ".csv")
                };
                if (dialog.ShowDialog() != true) return;
                string[] encabezados = stats ? Exportador.CabecerasEstadisticas : Exportador.CabecerasDetalle;
                IEnumerable<string[]> filas = stats ? estadisticas.Select(Exportador.Estadistica) : filtrados.Select(Exportador.Detalle);
                if (excel) Exportador.Xlsx(dialog.FileName, encabezados, filas); else Exportador.Csv(dialog.FileName, encabezados, filas);
                estadoTexto.Text = "Exportación completada: " + dialog.FileName;
            }
            catch (Exception ex) { MessageBox.Show("Error al exportar: " + ex.Message); }
        }
    }
}
