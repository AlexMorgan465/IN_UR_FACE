using System;

namespace Cofidis_Espana_Manager
{
    public sealed class Tratamiento
    {
        public Tratamiento()
        {
            Id = ""; Usuario = ""; Referencia = ""; Taf = ""; Decision = ""; Comentario = ""; Estado = "";
        }
        public string Id { get; set; }
        public string Usuario { get; set; }
        public string Referencia { get; set; }
        public string Taf { get; set; }
        public string Decision { get; set; }
        public string Comentario { get; set; }
        public DateTime FechaInicio { get; set; }
        public DateTime? FechaFin { get; set; }
        public string Estado { get; set; }

        public double? DmtSegundos
        {
            get
            {
                if (!FechaFin.HasValue) return null;
                return Math.Max(0, (FechaFin.Value - FechaInicio).TotalSeconds);
            }
        }
        public string Dmt
        {
            get
            {
                double? s = DmtSegundos;
                if (!s.HasValue) return "-";
                return TimeSpan.FromSeconds(s.Value).ToString(@"hh\:mm\:ss");
            }
        }
        public string Fecha { get { return FechaInicio.ToString("dd/MM/yyyy"); } }
    }

    public sealed class EstadisticaDia
    {
        public EstadisticaDia() { Fecha = ""; }
        public string Fecha { get; set; }
        public int Tratados { get; set; }
        public int SinInformacion { get; set; }
        public int RExBU { get; set; }
        public int RExB1 { get; set; }
        public int RExIG { get; set; }
        public int RExRECIENTE { get; set; }
        public int RExNT { get; set; }
        public int RExPR { get; set; }
        public int RExVEDACON { get; set; }
        public int RExFICHEROSNEG { get; set; }
        public int RExTIPOCTTO { get; set; }
        public int RExSCORE { get; set; }
        public int RExRIESGO { get; set; }
        public int RExLI { get; set; }
        public int RExAN { get; set; }
        public int RExBQ { get; set; }
        public int OkParaEstudio { get; set; }
        public double PorcentajeRechazo { get; set; }
        public string Rechazo { get { return PorcentajeRechazo.ToString("P1"); } }
    }

    public sealed class Barra
    {
        public Barra() { Nombre = ""; Valor = ""; }
        public string Nombre { get; set; }
        public string Valor { get; set; }
        public double Anchura { get; set; }
    }
}
