using System;
using System.Security.Cryptography;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;


namespace Cofidis_Espana_Manager
{
    // Ventana de ajustes creada en codigo (sin XAML compilado).
    // Paso 1: contrasena. Paso 2: ruta de guardado.
    public sealed class AjustesVentana : Window
    {
        // Solo se guarda el hash SHA-256 de la contrasena, no la contrase\u00f1a en claro.
        private const string HashClave = "ba8d450d8b775ce1a475715e2951bdc087dd5a1e62230bafd9a179dbce926f86";
        private int intentos;
        private readonly StackPanel panelClave = new StackPanel();
        private readonly StackPanel panelRuta = new StackPanel();
        private readonly PasswordBox claveCaja = new PasswordBox();
        private readonly TextBlock errorTexto = new TextBlock();
        private readonly TextBox rutaCaja = new TextBox();

        public AjustesVentana(string rutaActual)
        {
            Title = "Ajustes \u00b7 Ruta de datos";
            Width = 520;
            SizeToContent = SizeToContent.Height;
            ResizeMode = ResizeMode.NoResize;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            Background = Pincel("#F4F6FA");
            FontFamily = new FontFamily("Segoe UI");
            ShowInTaskbar = false;

            var raiz = new StackPanel { Margin = new Thickness(22) };
            raiz.Children.Add(panelClave);
            raiz.Children.Add(panelRuta);
            Content = raiz;

            // --- Paso 1
            panelClave.Children.Add(Titulo("Acceso protegido"));
            panelClave.Children.Add(Subtitulo("Introduzca la contrase\u00f1a para modificar la ruta de datos."));
            claveCaja.Height = 38; claveCaja.Padding = new Thickness(9, 7, 9, 7); claveCaja.FontSize = 13;
            claveCaja.BorderBrush = Pincel("#D8DFE9");
            claveCaja.KeyDown += delegate(object s, KeyEventArgs e) { if (e.Key == Key.Enter) Desbloquear(); };
            panelClave.Children.Add(claveCaja);
            errorTexto.Foreground = Pincel("#CC092F"); errorTexto.FontSize = 12;
            errorTexto.Margin = new Thickness(0, 8, 0, 0); errorTexto.Visibility = Visibility.Collapsed;
            panelClave.Children.Add(errorTexto);
            Button cancelar1 = Boton("Cancelar", false); cancelar1.IsCancel = true;
            Button desbloquear = Boton("Desbloquear", true);
            desbloquear.Click += delegate { Desbloquear(); };
            panelClave.Children.Add(Fila(cancelar1, desbloquear));

            // --- Paso 2
            panelRuta.Visibility = Visibility.Collapsed;
            panelRuta.Children.Add(Titulo("Ruta de datos"));
            panelRuta.Children.Add(Subtitulo("Carpeta ra\u00edz de los archivos JSON de los agentes (la misma que usan ellos)."));
            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            rutaCaja.Text = rutaActual ?? string.Empty;
            rutaCaja.Height = 38; rutaCaja.Padding = new Thickness(9, 7, 9, 7); rutaCaja.FontSize = 13;
            rutaCaja.BorderBrush = Pincel("#D8DFE9"); rutaCaja.VerticalContentAlignment = VerticalAlignment.Center;
            grid.Children.Add(rutaCaja);
            Button examinar = Boton("Examinar\u2026", false);
            examinar.Margin = new Thickness(8, 0, 0, 0);
            examinar.Click += delegate { Examinar(); };
            Grid.SetColumn(examinar, 1);
            grid.Children.Add(examinar);
            panelRuta.Children.Add(grid);
            var nota = Subtitulo("El panel solo lee: no modifica los archivos de los agentes.");
            nota.FontSize = 11; nota.Margin = new Thickness(0, 8, 0, 0);
            panelRuta.Children.Add(nota);
            Button cancelar2 = Boton("Cancelar", false); cancelar2.IsCancel = true;
            Button guardar = Boton("Guardar", true);
            guardar.Click += delegate { Guardar(); };
            panelRuta.Children.Add(Fila(cancelar2, guardar));

            Loaded += delegate { claveCaja.Focus(); };
        }

        private static SolidColorBrush Pincel(string hex)
        {
            return (SolidColorBrush)new BrushConverter().ConvertFromString(hex);
        }

        private static TextBlock Titulo(string texto)
        {
            return new TextBlock { Text = texto, FontSize = 18, FontWeight = FontWeights.Bold, Foreground = Pincel("#17243B") };
        }

        private static TextBlock Subtitulo(string texto)
        {
            return new TextBlock { Text = texto, Foreground = Pincel("#708097"), Margin = new Thickness(0, 4, 0, 16), TextWrapping = TextWrapping.Wrap };
        }

        private static Button Boton(string texto, bool principal)
        {
            return new Button
            {
                Content = texto,
                Padding = new Thickness(15, 10, 15, 10),
                Margin = new Thickness(0, 0, principal ? 0 : 8, 0),
                Background = Pincel(principal ? "#CC092F" : "#E8EDF5"),
                Foreground = principal ? Brushes.White : Pincel("#223047"),
                BorderThickness = new Thickness(0),
                FontWeight = FontWeights.SemiBold,
                Cursor = Cursors.Hand
            };
        }

        private static StackPanel Fila(Button izquierda, Button derecha)
        {
            var fila = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 18, 0, 0) };
            fila.Children.Add(izquierda);
            fila.Children.Add(derecha);
            return fila;
        }

        private static bool ClaveValida(string clave)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] hash = sha.ComputeHash(Encoding.UTF8.GetBytes(clave));
                string hex = BitConverter.ToString(hash).Replace("-", "");
                return string.Equals(hex, HashClave, StringComparison.OrdinalIgnoreCase);
            }
        }

        private void Desbloquear()
        {
            if (ClaveValida(claveCaja.Password))
            {
                panelClave.Visibility = Visibility.Collapsed;
                panelRuta.Visibility = Visibility.Visible;
                rutaCaja.Focus();
                rutaCaja.SelectAll();
                return;
            }
            intentos++;
            claveCaja.Clear();
            errorTexto.Text = "Contrase\u00f1a incorrecta.";
            errorTexto.Visibility = Visibility.Visible;
            if (intentos >= 3) DialogResult = false;
        }

        private void Examinar()
        {
            using (var dialogo = new System.Windows.Forms.FolderBrowserDialog())
            {
                dialogo.Description = "Seleccione la carpeta de datos";
                string actual = Environment.ExpandEnvironmentVariables(rutaCaja.Text ?? "");
                if (!string.IsNullOrWhiteSpace(actual) && System.IO.Directory.Exists(actual)) dialogo.SelectedPath = actual;
                if (dialogo.ShowDialog() == System.Windows.Forms.DialogResult.OK) rutaCaja.Text = dialogo.SelectedPath;
            }
        }

        private void Guardar()
        {
            try
            {
                Lector.GuardarRuta(rutaCaja.Text);
                DialogResult = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo usar esa ruta:\n" + ex.Message, "Ruta no v\u00e1lida", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
