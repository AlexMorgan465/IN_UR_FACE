@echo off
setlocal
powershell.exe -NoProfile -File "%~dp0Compiler.ps1" -Lancer
if errorlevel 1 pause
endlocal
