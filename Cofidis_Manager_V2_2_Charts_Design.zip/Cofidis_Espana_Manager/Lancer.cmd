@echo off
setlocal
if not exist "%~dp0bin\Cofidis_Espana_Manager.exe" (
  powershell.exe -NoProfile -File "%~dp0Compiler.ps1" -Lancer
  if errorlevel 1 pause
) else (
  start "Cofidis Espana Manager" "%~dp0bin\Cofidis_Espana_Manager.exe"
)
endlocal
