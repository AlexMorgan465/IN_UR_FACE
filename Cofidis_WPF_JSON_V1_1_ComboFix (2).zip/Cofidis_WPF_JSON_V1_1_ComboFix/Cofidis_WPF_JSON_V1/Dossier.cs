using System;
namespace MyFirst;
public sealed class Dossier
{
 public string Id {get;set;} = Guid.NewGuid().ToString("N");
 public string Collaborateur {get;set;} = "";
 public string Traitement {get;set;} = "";
 public string Canal {get;set;} = "";
 public string ReferenceDossier {get;set;} = "";
 public string TypeCredit {get;set;} = "";
 public string TypeProduit {get;set;} = "";
 public string Solvabilite {get;set;} = "";
 public string TypeSolva {get;set;} = "";
 public string DecisionSolva {get;set;} = "";
 public string TypeSignature {get;set;} = "";
 public string Decision {get;set;} = "";
 public string Commentaire {get;set;} = "";
 public DateTime DateDebut {get;set;}
 public DateTime? DateFin {get;set;}
 public DateTime? DateAnnulation {get;set;}
 public string Statut {get;set;} = "EnCours";
 public double? DmtSecondes => DateFin.HasValue ? Math.Max(0,(DateFin.Value-DateDebut).TotalSeconds) : null;
}
