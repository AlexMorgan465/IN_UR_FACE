using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace MyFirst;
public partial class MainWindow : Window
{
    private readonly DossierStorage storage = new();
    private List<Dossier> history = new();
    private Dossier? active;
    private bool loadFailed;
    public MainWindow()
    {
        InitializeComponent();
        AgentText.Text = "Bonjour " + Environment.UserName;
        Fill(TreatmentTypeCombo, "N1", "N2", "CHALLENGER", "ETUDEINC", "SOLVA");
        Fill(ProductTypeCombo, "AUG ACC", "OUV ACC", "AUG PART", "OUV PSM", "OUV PSM/PSM", "OUV PSM d'AUG");
        Fill(SignatureTypeCombo, "SE", "Papier");
        Fill(DecisionCombo, "OCA", "OCR", "OCI", "CPP", "TDT", "TRF FRD", "TRF BL", "DELEGATION", "ABA");
        Fill(DecisionSolvaCombo, "OK", "KO");
        Fill(TypeCombo, "GRILLE", "WEB", "SOL_SIT_FAM");
        try
        {
            storage.Reconcile();
            history = storage.LoadAgentHistory();
            active = history.FirstOrDefault(d => d.Statut == "EnCours");
            if (history.Count(d => d.Statut == "EnCours") > 1)
                throw new InvalidOperationException("Plusieurs traitements en cours détectés. Contactez le responsable.");
            if (active != null) RestoreActive();
            RefreshTable();
        }
        catch (Exception ex)
        {
            MessageBox.Show("Chargement impossible : " + ex.Message, "Erreur JSON", MessageBoxButton.OK, MessageBoxImage.Error);
            loadFailed = true;
            AddButton.IsEnabled = false;
            FinishButton.IsEnabled = false;
            SaveButton.IsEnabled = false;
        }
        UpdateState();
    }
    private static void Fill(ComboBox combo, params string[] values)
    {
        combo.Items.Clear();
        foreach (var value in values) combo.Items.Add(value);
    }
    private static string Value(ComboBox combo) => combo.SelectedItem?.ToString() ?? "";
    private void TreatmentChanged(object sender, SelectionChangedEventArgs e)
    {
        if (CreditTypeCombo == null) return;
        string type = Value(TreatmentTypeCombo);
        Fill(CreditTypeCombo, type == "ETUDEINC" ? new[] { "ETUDEINC", "CLOSUIVI", "INFOCLT", "APPELCLT" } :
            type == "SOLVA" ? Array.Empty<string>() : new[] { "AUG", "OUV" });
        bool solva = type == "SOLVA";
        foreach (UIElement element in new UIElement[] { TypeLabel, TypeCombo, SolvabiliteLabel, SolvabiliteTextBox, DecisionSolvaLabel, DecisionSolvaCombo })
            element.Visibility = solva ? Visibility.Visible : Visibility.Collapsed;
        foreach (UIElement element in new UIElement[] { CreditLabel, CreditTypeCombo, ProductLabel, ProductTypeCombo, SignatureLabel, SignatureTypeCombo, DecisionLabel, DecisionCombo })
            element.Visibility = solva ? Visibility.Collapsed : Visibility.Visible;
    }
    private void UpdateState()
    {
        bool inProgress = active != null;
        TreatmentTypeCombo.IsEnabled = !inProgress && !loadFailed;
        BackOfficeRadio.IsEnabled = !inProgress;
        FrontOfficeRadio.IsEnabled = !inProgress;
        TypeCombo.IsEnabled = inProgress && !loadFailed;
        CreditTypeCombo.IsEnabled = !inProgress && !loadFailed;
        ProductTypeCombo.IsEnabled = !inProgress && !loadFailed;
        SolvabiliteTextBox.IsReadOnly = inProgress;
        ReferenceTextBox.IsReadOnly = inProgress;
        AddButton.IsEnabled = !inProgress && !loadFailed;
        Step2Panel.IsEnabled = inProgress;
        FinishButton.IsEnabled = inProgress && !loadFailed;
        SaveButton.IsEnabled = inProgress && !loadFailed;
    }
    private void RestoreActive()
    {
        if (active == null) return;
        TreatmentTypeCombo.SelectedItem = active.Traitement;
        BackOfficeRadio.IsChecked = active.Canal == "Back-Office";
        FrontOfficeRadio.IsChecked = active.Canal == "Front-Office";
        CreditTypeCombo.SelectedItem = active.TypeCredit;
        ProductTypeCombo.SelectedItem = active.TypeProduit;
        TypeCombo.SelectedItem = active.TypeSolva;
        SolvabiliteTextBox.Text = active.Solvabilite;
        ReferenceTextBox.Text = active.ReferenceDossier;
        SignatureTypeCombo.SelectedItem = active.TypeSignature;
        DecisionCombo.SelectedItem = active.Decision;
        DecisionSolvaCombo.SelectedItem = active.DecisionSolva;
        CommentTextBox.Text = active.Commentaire;
    }
    private void RefreshTable()
    {
        var data = storage.LoadDay(DateTime.Today).OrderByDescending(d => d.DateDebut).ToList();
        MyTable.ItemsSource = data;
        CountText.Text = $"{data.Count} traitement(s)";
    }
    private void Add_Click(object sender, RoutedEventArgs e)
    {
        if (active != null) { MessageBox.Show("Terminez ou annulez le traitement en cours."); return; }
        string type = Value(TreatmentTypeCombo), reference = ReferenceTextBox.Text.Trim();
        string canal = BackOfficeRadio.IsChecked == true ? "Back-Office" : FrontOfficeRadio.IsChecked == true ? "Front-Office" : "";
        if (type == "" || reference == "" || canal == "" ||
            (type == "SOLVA" && string.IsNullOrWhiteSpace(SolvabiliteTextBox.Text)) ||
            (type != "SOLVA" && (Value(CreditTypeCombo) == "" || Value(ProductTypeCombo) == "")))
        { MessageBox.Show("Renseignez tous les champs obligatoires de l'étape 1."); return; }
        try
        {
            // Reload disk to avoid relying on a stale in-memory list.
            var today = storage.LoadDay(DateTime.Today);
            if (today.Any(d => d.Statut == "EnCours")) { MessageBox.Show("Un traitement est déjà en cours."); return; }
            if (today.Any(d => d.Traitement == type && string.Equals(d.ReferenceDossier, reference, StringComparison.OrdinalIgnoreCase)))
            { MessageBox.Show("Cette référence existe déjà aujourd'hui pour ce traitement."); return; }
            var dossier = new Dossier { Collaborateur = Environment.UserName, Traitement = type, Canal = canal,
                ReferenceDossier = reference, TypeCredit = Value(CreditTypeCombo), TypeProduit = Value(ProductTypeCombo),
                Solvabilite = SolvabiliteTextBox.Text.Trim(), DateDebut = DateTime.Now };
            today.Add(dossier);
            storage.SaveDay(dossier.DateDebut.Date, today);
            active = dossier;
            history.Add(dossier);
            UpdateState(); RefreshTable();
        }
        catch (Exception ex) { MessageBox.Show("Ajout non enregistré : " + ex.Message); }
    }
    private void Finish_Click(object sender, RoutedEventArgs e)
    {
        if (active == null) return;
        bool solva = active.Traitement == "SOLVA";
        if (solva ? (Value(TypeCombo) == "" || Value(DecisionSolvaCombo) == "") :
                    (Value(SignatureTypeCombo) == "" || Value(DecisionCombo) == ""))
        { MessageBox.Show("Complétez les champs obligatoires de l'étape 2."); return; }
        try
        {
            var day = storage.LoadDay(active.DateDebut.Date);
            var record = day.SingleOrDefault(d => d.Id == active.Id) ?? throw new InvalidOperationException("Traitement introuvable dans le JSON.");
            if (record.Statut != "EnCours") throw new InvalidOperationException("Traitement déjà clôturé.");
            record.TypeSolva = solva ? Value(TypeCombo) : "";
            record.DecisionSolva = solva ? Value(DecisionSolvaCombo) : "";
            record.TypeSignature = solva ? "" : Value(SignatureTypeCombo);
            record.Decision = solva ? "" : Value(DecisionCombo);
            record.Commentaire = CommentTextBox.Text;
            record.DateFin = DateTime.Now;
            record.Statut = "Termine";
            storage.SaveDay(record.DateDebut.Date, day);
            active = null;
            history = storage.LoadAgentHistory();
            ResetForm(); UpdateState(); RefreshTable();
        }
        catch (Exception ex) { MessageBox.Show("Fin non enregistrée : " + ex.Message); }
    }
    private void Cancel_Click(object sender, RoutedEventArgs e)
    {
        if (active == null) return;
        if (MessageBox.Show("Annuler uniquement le traitement en cours ?", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
        try
        {
            storage.Cancel(active);
            active = null;
            history = storage.LoadAgentHistory();
            ResetForm(); UpdateState(); RefreshTable();
        }
        catch (Exception ex) { MessageBox.Show("Annulation non finalisée : " + ex.Message + "\nRelancez l'application pour réconcilier les fichiers."); }
    }
    private void ResetForm()
    {
        TreatmentTypeCombo.SelectedIndex = -1;
        CreditTypeCombo.SelectedIndex = -1;
        ProductTypeCombo.SelectedIndex = -1;
        TypeCombo.SelectedIndex = -1;
        SignatureTypeCombo.SelectedIndex = -1;
        DecisionCombo.SelectedIndex = -1;
        DecisionSolvaCombo.SelectedIndex = -1;
        ReferenceTextBox.Clear(); SolvabiliteTextBox.Clear(); CommentTextBox.Clear();
    }
    private void ClearSearch_Click(object sender, RoutedEventArgs e)
    {
        TypologySearchTextBox.Clear(); ReferenceSearchTextBox.Clear(); CreditSearchTextBox.Clear(); SignatureSearchTextBox.Clear();
        RefreshTable();
    }
    private void Export_Click(object sender, RoutedEventArgs e)
    {
        try { MessageBox.Show("Export créé : " + storage.ExportCsv(storage.LoadAgentHistory())); }
        catch (Exception ex) { MessageBox.Show("Export impossible : " + ex.Message); }
    }
    private void ExportExcel_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var records = storage.LoadAgentHistory().OrderBy(d => d.DateDebut).ToList();
            if (records.Count == 0) { MessageBox.Show("Aucune donnée à exporter."); return; }
            var dialog = new Microsoft.Win32.SaveFileDialog { Title = "Exporter vers Excel", Filter = "Classeur Excel (*.xlsx)|*.xlsx", DefaultExt = ".xlsx", AddExtension = true, FileName = $"Cofidis_Historique_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx" };
            if (dialog.ShowDialog() != true) return;
            var details = new CofidisExport.ExcelExport.Sheet("Traitements", new[] { "Collaborateur", "Traitement", "Canal", "Référence", "Crédit", "Produit", "Solvabilité", "Type SOLVA", "Décision SOLVA", "Signature", "Décision", "Commentaire", "Début", "Fin", "DMT secondes", "Statut", "Date annulation", "ID" }, records.Select(d => new object?[] { d.Collaborateur, d.Traitement, d.Canal, d.ReferenceDossier, d.TypeCredit, d.TypeProduit, d.Solvabilite, d.TypeSolva, d.DecisionSolva, d.TypeSignature, d.Decision, d.Commentaire, d.DateDebut, d.DateFin, d.DmtSecondes, d.Statut, d.DateAnnulation, d.Id }).ToList());
            var summary = new CofidisExport.ExcelExport.Sheet("Synthèse collaborateurs", new[] { "Collaborateur", "Total", "Terminés", "En cours", "Annulés", "DMT moyen secondes" }, records.GroupBy(d => d.Collaborateur, StringComparer.OrdinalIgnoreCase).OrderBy(g => g.Key).Select(g => new object?[] { g.Key, g.Count(), g.Count(d => d.Statut == "Termine"), g.Count(d => d.Statut == "EnCours"), g.Count(d => d.Statut == "Annule"), g.Where(d => d.Statut == "Termine" && d.DmtSecondes.HasValue).Select(d => d.DmtSecondes).Average() }).ToList());
            CofidisExport.ExcelExport.Save(dialog.FileName, summary, details);
            MessageBox.Show($"{records.Count} traitement(s) exporté(s).\n{dialog.FileName}", "Export Excel terminé");
        }
        catch (Exception ex) { MessageBox.Show("Export Excel impossible : " + ex.Message, "Erreur", MessageBoxButton.OK, MessageBoxImage.Error); }
    }
}

