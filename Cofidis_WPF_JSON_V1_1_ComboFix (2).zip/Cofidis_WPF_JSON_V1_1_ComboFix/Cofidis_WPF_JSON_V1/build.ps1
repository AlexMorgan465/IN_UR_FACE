$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
dotnet build .\CofidisWpf.csproj -c Release
