COFIDIS WPF JSON - Prototype V1

Compiler sur Windows avec .NET SDK 8 : dotnet build -c Release
Lancer : dotnet run
Stockage local par défaut : %LOCALAPPDATA%\CofidisApp\Data\MM-yyyy\USERNAME-dd-MM-yyyy.json
Pour partager un dossier racine, définir COFIDIS_DATA_ROOT (ex: \\serveur\partage\COFIDIS_DATA) AVANT le lancement.
Export Excel compatible : CSV UTF-8 séparé par point-virgule sur le Bureau.

IMPORTANT : version mono-instance par agent. Ne pas ouvrir deux instances sur la même session : aucune exclusion interprocessus n'est encore implémentée.
Les filtres de recherche visuels ne sont pas encore connectés. L'export est CSV compatible Excel, pas XLSX natif.
Le filtrage par nom Windows n'est pas une barrière de sécurité : les permissions NTFS du partage doivent isoler les agents.
Les JSON corrompus provoquent une erreur (pas de remise à zéro silencieuse).
