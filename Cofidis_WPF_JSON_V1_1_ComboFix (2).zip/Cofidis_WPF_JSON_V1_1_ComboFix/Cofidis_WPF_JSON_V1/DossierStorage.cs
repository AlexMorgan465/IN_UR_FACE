using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;

namespace MyFirst;
public sealed class DossierStorage
{
    private readonly string root;
    private readonly string agent;
    private readonly JsonSerializerOptions options = new() { WriteIndented = true, PropertyNameCaseInsensitive = true };
    public DossierStorage()
    {
        agent = Environment.UserName;
        root = Environment.GetEnvironmentVariable("COFIDIS_DATA_ROOT") ??
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "CofidisApp", "Data");
        Directory.CreateDirectory(root);
    }
    private string MainPath(DateTime day) => Path.Combine(root, day.ToString("MM-yyyy"), $"{agent}-{day:dd-MM-yyyy}.json");
    private string CancelPath(DateTime day) => Path.Combine(root, day.ToString("MM-yyyy"), "Traitements_Annules", $"{agent}-{day:dd-MM-yyyy}.json");
    private static void WriteAtomic(string path, List<Dossier> data, JsonSerializerOptions options)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        string tmp = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try { File.WriteAllText(tmp, JsonSerializer.Serialize(data, options), new UTF8Encoding(false)); File.Move(tmp, path, true); }
        finally { if (File.Exists(tmp)) File.Delete(tmp); }
    }
    private List<Dossier> Read(string path)
    {
        if (!File.Exists(path)) return new();
        return JsonSerializer.Deserialize<List<Dossier>>(File.ReadAllText(path), options) ?? throw new InvalidDataException("JSON invalide : " + path);
    }
    public List<Dossier> LoadDay(DateTime day) => Read(MainPath(day));
    public List<Dossier> LoadAgentHistory()
    {
        var all = new List<Dossier>();
        foreach (string dir in Directory.GetDirectories(root))
        foreach (string path in Directory.GetFiles(dir, agent + "-*.json", SearchOption.TopDirectoryOnly))
            all.AddRange(Read(path));
        return all;
    }
    public void SaveDay(DateTime day, List<Dossier> data) => WriteAtomic(MainPath(day), data, options);
    // Cancellation is resumable: archive first, then remove main record.
    // A crash between these steps is reconciled on next startup.
    public void Cancel(Dossier active)
    {
        DateTime day = active.DateDebut.Date;
        var canceled = Read(CancelPath(day));
        if (!canceled.Any(d => d.Id == active.Id))
        {
            var copy = JsonSerializer.Deserialize<Dossier>(JsonSerializer.Serialize(active, options), options)!;
            copy.Statut = "Annule";
            copy.DateAnnulation = DateTime.Now;
            canceled.Add(copy);
            WriteAtomic(CancelPath(day), canceled, options);
        }
        var main = LoadDay(day);
        main.RemoveAll(d => d.Id == active.Id);
        SaveDay(day, main);
    }
    public void Reconcile()
    {
        foreach (string dir in Directory.GetDirectories(root))
        {
            string cancelDir = Path.Combine(dir, "Traitements_Annules");
            if (!Directory.Exists(cancelDir)) continue;
            foreach (string path in Directory.GetFiles(cancelDir, agent + "-*.json"))
            {
                var archived = Read(path);
                foreach (var group in archived.GroupBy(d => d.DateDebut.Date))
                {
                    var main = LoadDay(group.Key);
                    int removed = main.RemoveAll(d => group.Any(a => a.Id == d.Id));
                    if (removed > 0) SaveDay(group.Key, main);
                }
            }
        }
    }
    public string ExportCsv(List<Dossier> data)
    {
        string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), $"Cofidis_{agent}_{DateTime.Now:yyyyMMdd_HHmmss}.csv");
        static string Esc(object? o) => "\"" + Convert.ToString(o)?.Replace("\"", "\"\"") + "\"";
        using var writer = new StreamWriter(path, false, new UTF8Encoding(true));
        writer.WriteLine("Collaborateur;Traitement;Canal;Référence;Début;Fin;Crédit;Produit;Solvabilité;Type SOLVA;Décision SOLVA;Signature;Décision;Commentaire;DMT secondes;Statut");
        foreach (var d in data.OrderBy(d => d.DateDebut))
        {
            object?[] fields = { d.Collaborateur,d.Traitement,d.Canal,d.ReferenceDossier,d.DateDebut.ToString("yyyy-MM-dd HH:mm:ss"),d.DateFin?.ToString("yyyy-MM-dd HH:mm:ss"),d.TypeCredit,d.TypeProduit,d.Solvabilite,d.TypeSolva,d.DecisionSolva,d.TypeSignature,d.Decision,d.Commentaire,d.DmtSecondes?.ToString(System.Globalization.CultureInfo.InvariantCulture),d.Statut };
            writer.WriteLine(string.Join(";", fields.Select(Esc)));
        }
        return path;
    }
}
