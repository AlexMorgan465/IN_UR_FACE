using System.IO;
using System.Text.Json;
using Cofidis_Espana.Models;
namespace Cofidis_Espana.Services;
public sealed class AlmacenJson
{
    private readonly string raiz;
    private readonly string usuario = Environment.UserName;
    private static readonly JsonSerializerOptions Opciones = new() { WriteIndented = true, PropertyNameCaseInsensitive = true };
    public string RutaDatos => raiz;
    public AlmacenJson()
    {
        string configuracion = Path.Combine(AppContext.BaseDirectory, "config.json");
        if (!File.Exists(configuracion)) throw new FileNotFoundException("No se encuentra config.json", configuracion);
        using var documento = JsonDocument.Parse(File.ReadAllText(configuracion));
        string? valor = documento.RootElement.GetProperty("RutaDatos").GetString();
        if (string.IsNullOrWhiteSpace(valor)) throw new InvalidDataException("RutaDatos está vacía en config.json");
        raiz = Path.GetFullPath(Environment.ExpandEnvironmentVariables(valor));
        Directory.CreateDirectory(raiz);
    }
    public static string ArchivoConfiguracion => Path.Combine(AppContext.BaseDirectory, "config.json");

    // Valida la carpeta (se crea si no existe y se comprueba que se puede escribir) y la guarda en config.json.
    public static void GuardarRuta(string ruta)
    {
        if (string.IsNullOrWhiteSpace(ruta)) throw new ArgumentException("La ruta está vacía.");
        string completa = Path.GetFullPath(Environment.ExpandEnvironmentVariables(ruta.Trim()));
        Directory.CreateDirectory(completa);
        string prueba = Path.Combine(completa, $".escritura-{Guid.NewGuid():N}.tmp");
        File.WriteAllText(prueba, "ok");
        File.Delete(prueba);
        var contenido = JsonSerializer.Serialize(new Dictionary<string, string> { ["RutaDatos"] = ruta.Trim() }, Opciones);
        File.WriteAllText(ArchivoConfiguracion, contenido);
    }

    private string Archivo(DateTime fecha) => Path.Combine(raiz, fecha.ToString("MM-yyyy"), $"{usuario}-{fecha:MM-yyyy}.json");
    public List<Tratamiento> LeerArchivo(string ruta)
    {
        if (!File.Exists(ruta)) return new();
        return JsonSerializer.Deserialize<List<Tratamiento>>(File.ReadAllText(ruta), Opciones)
            ?? throw new InvalidDataException($"JSON vacío o inválido: {ruta}");
    }
    public List<Tratamiento> LeerMes(DateTime fecha) => LeerArchivo(Archivo(fecha));
    public List<Tratamiento> LeerTodos()
    {
        if (!Directory.Exists(raiz)) return new();
        var lista = new List<Tratamiento>();
        foreach (string ruta in Directory.EnumerateFiles(raiz, $"{usuario}-*.json", SearchOption.AllDirectories))
            lista.AddRange(LeerArchivo(ruta).Where(x => string.Equals(x.Usuario, usuario, StringComparison.OrdinalIgnoreCase)));
        return lista;
    }
    public void Guardar(Tratamiento registro)
    {
        string ruta = Archivo(registro.FechaInicio);
        Directory.CreateDirectory(Path.GetDirectoryName(ruta)!);
        var registros = LeerArchivo(ruta);
        int posicion = registros.FindIndex(x => x.Id == registro.Id);
        if (posicion >= 0) registros[posicion] = registro;
        else registros.Add(registro);
        string temporal = ruta + ".tmp";
        File.WriteAllText(temporal, JsonSerializer.Serialize(registros, Opciones));
        File.Move(temporal, ruta, true);
    }
}
