using System.Security.Cryptography;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Cofidis_Espana.Services;
namespace Cofidis_Espana;

public partial class AjustesVentana : Window
{
    // Solo se guarda el hash SHA-256 de la contraseña, no la contraseña en claro.
    private const string HashClave = "ba8d450d8b775ce1a475715e2951bdc087dd5a1e62230bafd9a179dbce926f86";
    private int intentos;

    public AjustesVentana(string rutaActual)
    {
        InitializeComponent();
        RutaCaja.Text = rutaActual;
        Loaded += (_, _) => ClaveCaja.Focus();
    }

    private static bool ClaveValida(string clave)
    {
        byte[] hash = SHA256.HashData(Encoding.UTF8.GetBytes(clave));
        return string.Equals(Convert.ToHexString(hash), HashClave, StringComparison.OrdinalIgnoreCase);
    }

    private void Clave_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter) Desbloquear_Click(sender, e);
    }

    private void Desbloquear_Click(object sender, RoutedEventArgs e)
    {
        if (ClaveValida(ClaveCaja.Password))
        {
            PanelClave.Visibility = Visibility.Collapsed;
            PanelRuta.Visibility = Visibility.Visible;
            RutaCaja.Focus();
            RutaCaja.SelectAll();
            return;
        }
        intentos++;
        ClaveCaja.Clear();
        ErrorTexto.Text = "Contraseña incorrecta.";
        ErrorTexto.Visibility = Visibility.Visible;
        if (intentos >= 3) { DialogResult = false; }
    }

    private void Examinar_Click(object sender, RoutedEventArgs e)
    {
        var dialogo = new Microsoft.Win32.OpenFolderDialog { Title = "Seleccione la carpeta de guardado" };
        if (!string.IsNullOrWhiteSpace(RutaCaja.Text)) dialogo.InitialDirectory = Environment.ExpandEnvironmentVariables(RutaCaja.Text);
        if (dialogo.ShowDialog(this) == true) RutaCaja.Text = dialogo.FolderName;
    }

    private void Guardar_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            AlmacenJson.GuardarRuta(RutaCaja.Text);
            DialogResult = true;
        }
        catch (Exception ex)
        {
            MessageBox.Show($"No se pudo usar esa ruta:\n{ex.Message}", "Ruta no válida", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}
