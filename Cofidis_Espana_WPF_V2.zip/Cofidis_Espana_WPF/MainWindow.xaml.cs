using System.Windows;
using System.Windows.Controls;
using Cofidis_Espana.Models;
using Cofidis_Espana.Services;
namespace Cofidis_Espana;
public partial class MainWindow : Window
{
    private AlmacenJson? almacen;
    private Tratamiento? activo;
    private List<Tratamiento> registros = new();
    private readonly string usuario = Environment.UserName;
    private static readonly string[] Taf = { "46580", "46603", "46578", "46650", "46628", "46575" };
    private static readonly string[] Decisiones = {
        "fecha", "Tratados", "sin información para pre-estudio", "RExBU", "RExB1", "RExIG",
        "RExRECIENTE", "RExNT", "RExPR", "RExVEDACON", "RExFICHEROS NEG",
        "RExTIPO CTTO", "RExSCORE", "RExRIESGO", "RExLI", "RExAN", "RExBQ"
    };
    public MainWindow()
    {
        InitializeComponent();
        TafCaja.ItemsSource = Taf;
        DecisionCaja.ItemsSource = Decisiones;
        UsuarioTexto.Text = $"Hola, {usuario}";
        try
        {
            almacen = new AlmacenJson();
            RutaTexto.Text = almacen.RutaDatos;
            Cargar();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"No se pueden cargar los datos.\n{ex.Message}", "Error de almacenamiento", MessageBoxButton.OK, MessageBoxImage.Error);
            AgregarBoton.IsEnabled = false;
            FinalizarBoton.IsEnabled = false;
        }
    }
    private void Cargar()
    {
        if (almacen is null) return;
        registros = almacen.LeerTodos();
        var abiertos = registros.Where(x => x.Estado == "En curso").OrderBy(x => x.FechaInicio).ToList();
        if (abiertos.Count > 1)
        {
            activo = abiertos[0];
            MessageBox.Show("Hay varios tratamientos abiertos. Se bloquea la creación de nuevos registros hasta resolver la incidencia.", "Revisión necesaria", MessageBoxButton.OK, MessageBoxImage.Warning);
            AgregarBoton.IsEnabled = false;
        }
        else activo = abiertos.SingleOrDefault();
        if (activo is not null)
        {
            ReferenciaCaja.Text = activo.Referencia;
            TafCaja.SelectedItem = activo.Taf;
            DecisionCaja.SelectedItem = string.IsNullOrEmpty(activo.Decision) ? null : activo.Decision;
            ComentarioCaja.Text = activo.Comentario;
        }
        ActualizarEstado();
        MostrarTabla();
    }
    private void ActualizarEstado()
    {
        bool enCurso = activo is not null;
        ReferenciaCaja.IsEnabled = !enCurso;
        TafCaja.IsEnabled = !enCurso;
        AgregarBoton.IsEnabled = !enCurso && almacen is not null;
        DecisionCaja.IsEnabled = enCurso;
        ComentarioCaja.IsEnabled = enCurso;
        FinalizarBoton.IsEnabled = enCurso && almacen is not null;
        EstadoTexto.Text = enCurso ? $"En curso · {activo!.Referencia} · TAF {activo.Taf}" : "Sin tratamiento activo";
        InicioTexto.Text = enCurso ? $"Inicio: {activo!.FechaInicio:dd/MM/yyyy HH:mm:ss}" : "Puede iniciar una nueva llamada";
    }
    private void MostrarTabla()
    {
        string filtro = BusquedaCaja.Text.Trim();
        var hoy = registros.Where(x => x.FechaInicio.Date == DateTime.Today &&
                (filtro.Length == 0 || x.Referencia.Contains(filtro, StringComparison.OrdinalIgnoreCase) ||
                 x.Taf.Contains(filtro, StringComparison.OrdinalIgnoreCase) ||
                 x.Decision.Contains(filtro, StringComparison.OrdinalIgnoreCase)))
            .OrderByDescending(x => x.FechaInicio).ToList();
        Tabla.ItemsSource = hoy;
        int terminados = registros.Count(x => x.FechaInicio.Date == DateTime.Today && x.Estado == "Finalizado");
        ResumenTexto.Text = $"{terminados} finalizados hoy  ·  {(activo is null ? "Sin llamada activa" : "1 llamada en curso")}";
    }
    private void Agregar_Click(object sender, RoutedEventArgs e)
    {
        if (almacen is null || activo is not null) return;
        string referencia = ReferenciaCaja.Text.Trim();
        string? taf = TafCaja.SelectedItem as string;
        if (string.IsNullOrWhiteSpace(referencia) || string.IsNullOrWhiteSpace(taf))
        {
            MessageBox.Show("Introduzca una referencia y seleccione un guichet TAF.", "Campos obligatorios", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        var nuevo = new Tratamiento { Usuario = usuario, Referencia = referencia, Taf = taf, FechaInicio = DateTime.Now };
        try
        {
            // Volver a leer antes de escribir para recuperar cualquier sesión anterior.
            var actual = almacen.LeerTodos();
            if (actual.Any(x => x.Estado == "En curso"))
            {
                MessageBox.Show("Ya existe un tratamiento en curso. Actualice la pantalla.", "Tratamiento pendiente", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            almacen.Guardar(nuevo);
            activo = nuevo;
            registros = almacen.LeerTodos();
            DecisionCaja.SelectedItem = null;
            ComentarioCaja.Clear();
            ActualizarEstado();
            MostrarTabla();
        }
        catch (Exception ex) { MessageBox.Show($"No se pudo guardar el inicio:\n{ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error); }
    }
    private void Finalizar_Click(object sender, RoutedEventArgs e)
    {
        if (almacen is null || activo is null) return;
        string? decision = DecisionCaja.SelectedItem as string;
        if (string.IsNullOrWhiteSpace(decision))
        {
            MessageBox.Show("Seleccione una decisión para finalizar.", "Campo obligatorio", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        var terminado = new Tratamiento
        {
            Id = activo.Id, Usuario = activo.Usuario, Referencia = activo.Referencia, Taf = activo.Taf,
            FechaInicio = activo.FechaInicio, FechaFin = DateTime.Now, Decision = decision,
            Comentario = ComentarioCaja.Text.Trim(), Estado = "Finalizado"
        };
        try
        {
            almacen.Guardar(terminado);
            activo = null;
            registros = almacen.LeerTodos();
            ReferenciaCaja.Clear();
            TafCaja.SelectedItem = null;
            DecisionCaja.SelectedItem = null;
            ComentarioCaja.Clear();
            ActualizarEstado();
            MostrarTabla();
        }
        catch (Exception ex) { MessageBox.Show($"No se pudo finalizar:\n{ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error); }
    }
    private void Actualizar_Click(object sender, RoutedEventArgs e)
    {
        try { Cargar(); }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Error al actualizar", MessageBoxButton.OK, MessageBoxImage.Error); }
    }
    private void Ajustes_Click(object sender, RoutedEventArgs e)
    {
        if (activo is not null)
        {
            MessageBox.Show("Finalice el tratamiento en curso antes de cambiar la ruta de guardado.", "Tratamiento en curso", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        var ventana = new AjustesVentana(almacen?.RutaDatos ?? string.Empty) { Owner = this };
        if (ventana.ShowDialog() != true) return;
        try
        {
            almacen = new AlmacenJson();
            RutaTexto.Text = almacen.RutaDatos;
            Cargar();
            MessageBox.Show($"Nueva ruta de guardado:\n{almacen.RutaDatos}", "Ruta actualizada", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"No se pudo aplicar la nueva ruta:\n{ex.Message}", "Error de almacenamiento", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
    private void Busqueda_TextChanged(object sender, TextChangedEventArgs e) { if (Tabla is not null) MostrarTabla(); }
}
