COFIDIS MANAGER V2 — STATISTIQUES REELLES

Projet natif WPF .NET 8, sans bibliotheque graphique externe.

Lancer: .\build.ps1 (SDK .NET 8 Windows requis).

Choisir dossier : selectionner la racine COFIDIS_DATA contenant les dossiers MM-yyyy.
Si les agents utilisent chacun AppData local, le manager ne peut pas lire les autres postes.
Configurer une racine partagee autorisee, accessible en lecture au manager.

Graphiques: volumes par traitement, type de credit, signature, decision, mois de debut;
DMT moyen en minutes par traitement. Les valeurs sont calculees depuis les dossiers
Termine uniquement. Les annulations et EnCours restent dans les KPI et la consolidation.

Les filtres de l'onglet Consolidation s'appliquent aussi aux KPI et graphiques.
Le bouton Actualiser recharge les JSON depuis le disque.
Le bouton Exporter CSV exporte la consolidation filtree (Excel peut l'ouvrir).

Aucune donnee fictive n'est integree. En absence de JSON, les graphiques sont vides.

Limitations: histogrammes WPF simples, non zoomables. Pas de XLSX natif.
La lecture est complete a chaque actualisation, pas encore incrementale.
Les JSON doivent correspondre au schema de l'application Agent.
Projet non compile dans cet environnement Linux (WPF necessite Windows).
