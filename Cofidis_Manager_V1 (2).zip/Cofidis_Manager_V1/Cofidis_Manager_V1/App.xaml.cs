using System.Windows;
namespace CofidisManager;
public partial class App : Application { }
