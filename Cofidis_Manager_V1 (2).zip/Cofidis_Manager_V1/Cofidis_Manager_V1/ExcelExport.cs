using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Xml.Linq;
namespace CofidisExport;
public static class ExcelExport
{
 public sealed record Sheet(string Name, string[] Headers, List<object?[]> Rows);
 static readonly XNamespace S="http://schemas.openxmlformats.org/spreadsheetml/2006/main";
 static readonly XNamespace R="http://schemas.openxmlformats.org/officeDocument/2006/relationships";
 static string Col(int index){string s="";for(index++;index>0;index=(index-1)/26)s=(char)('A'+(index-1)%26)+s;return s;}
 static string Clean(string text)=>new string(text.Where(c=>c=='\t'||c=='\n'||c=='\r'||c>=32 && c!='\uFFFE' && c!='\uFFFF').Take(32767).ToArray());
 static XElement Cell(object? value,string address,bool header=false){
  var c=new XElement(S+"c",new XAttribute("r",address));if(header)c.SetAttributeValue("s",1);
  if(value==null)return c;
  if(value is DateTime date){c.SetAttributeValue("s",2);c.Add(new XElement(S+"v",date.ToOADate().ToString(CultureInfo.InvariantCulture)));}
  else if(value is double or float or decimal or int or long){c.Add(new XElement(S+"v",Convert.ToString(value,CultureInfo.InvariantCulture)));}
  else{c.SetAttributeValue("t","inlineStr");c.Add(new XElement(S+"is",new XElement(S+"t",new XAttribute(XNamespace.Xml+"space","preserve"),Clean(value.ToString()??""))));}return c;
 }
 static void Write(ZipArchive zip,string name,XElement xml){using var stream=zip.CreateEntry(name).Open();new XDocument(new XDeclaration("1.0","utf-8","yes"),xml).Save(stream);}
 public static void Save(string path,params Sheet[] sheets){
  if(sheets.Length==0)throw new ArgumentException("Aucune feuille.");
  foreach(var sheet in sheets)if(sheet.Rows.Count>1048575||sheet.Headers.Length>16384)throw new InvalidOperationException("Trop de données pour une feuille Excel.");
  string tmp=path+"."+Guid.NewGuid().ToString("N")+".tmp";
  try{
   using(var zip=ZipFile.Open(tmp,ZipArchiveMode.Create)){
    XNamespace ct="http://schemas.openxmlformats.org/package/2006/content-types",rel="http://schemas.openxmlformats.org/package/2006/relationships";
    Write(zip,"[Content_Types].xml",new XElement(ct+"Types",new XElement(ct+"Default",new XAttribute("Extension","rels"),new XAttribute("ContentType","application/vnd.openxmlformats-package.relationships+xml")),new XElement(ct+"Default",new XAttribute("Extension","xml"),new XAttribute("ContentType","application/xml")),new XElement(ct+"Override",new XAttribute("PartName","/xl/workbook.xml"),new XAttribute("ContentType","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml")),new XElement(ct+"Override",new XAttribute("PartName","/xl/styles.xml"),new XAttribute("ContentType","application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml")),sheets.Select((s,i)=>new XElement(ct+"Override",new XAttribute("PartName",$"/xl/worksheets/sheet{i+1}.xml"),new XAttribute("ContentType","application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml")))));
    Write(zip,"_rels/.rels",new XElement(rel+"Relationships",new XElement(rel+"Relationship",new XAttribute("Id","rId1"),new XAttribute("Type",R.ToString()+"/officeDocument"),new XAttribute("Target","xl/workbook.xml"))));
    Write(zip,"xl/workbook.xml",new XElement(S+"workbook",new XAttribute(XNamespace.Xmlns+"r",R),new XElement(S+"sheets",sheets.Select((s,i)=>new XElement(S+"sheet",new XAttribute("name",s.Name),new XAttribute("sheetId",i+1),new XAttribute(R+"id",$"rId{i+1}"))))));
    Write(zip,"xl/_rels/workbook.xml.rels",new XElement(rel+"Relationships",sheets.Select((s,i)=>new XElement(rel+"Relationship",new XAttribute("Id",$"rId{i+1}"),new XAttribute("Type",R.ToString()+"/worksheet"),new XAttribute("Target",$"worksheets/sheet{i+1}.xml"))),new XElement(rel+"Relationship",new XAttribute("Id","styles"),new XAttribute("Type",R.ToString()+"/styles"),new XAttribute("Target","styles.xml"))));
    Write(zip,"xl/styles.xml",XElement.Parse("<styleSheet xmlns='"+S+"'><numFmts count='1'><numFmt numFmtId='164' formatCode='dd/mm/yyyy hh:mm:ss'/></numFmts><fonts count='2'><font><sz val='11'/><name val='Calibri'/></font><font><b/><sz val='11'/><color rgb='FFFFFFFF'/><name val='Calibri'/></font></fonts><fills count='3'><fill><patternFill patternType='none'/></fill><fill><patternFill patternType='gray125'/></fill><fill><patternFill patternType='solid'><fgColor rgb='FFCE0028'/><bgColor indexed='64'/></patternFill></fill></fills><borders count='1'><border/></borders><cellStyleXfs count='1'><xf numFmtId='0' fontId='0' fillId='0' borderId='0'/></cellStyleXfs><cellXfs count='3'><xf numFmtId='0' fontId='0' fillId='0' borderId='0' xfId='0'/><xf numFmtId='0' fontId='1' fillId='2' borderId='0' xfId='0' applyFont='1' applyFill='1'/><xf numFmtId='164' fontId='0' fillId='0' borderId='0' xfId='0' applyNumberFormat='1'/></cellXfs><cellStyles count='1'><cellStyle name='Normal' xfId='0' builtinId='0'/></cellStyles></styleSheet>"));
    for(int i=0;i<sheets.Length;i++){
     var sheet=sheets[i];string range=$"A1:{Col(sheet.Headers.Length-1)}{sheet.Rows.Count+1}";
     var data=new XElement(S+"sheetData",new XElement(S+"row",new XAttribute("r",1),new XAttribute("ht",24),new XAttribute("customHeight",1),sheet.Headers.Select((v,c)=>Cell(v,Col(c)+"1",true))),sheet.Rows.Select((row,n)=>new XElement(S+"row",new XAttribute("r",n+2),row.Select((v,c)=>Cell(v,Col(c)+(n+2))))));
     Write(zip,$"xl/worksheets/sheet{i+1}.xml",new XElement(S+"worksheet",new XElement(S+"dimension",new XAttribute("ref",range)),new XElement(S+"sheetViews",new XElement(S+"sheetView",new XAttribute("workbookViewId",0),new XElement(S+"pane",new XAttribute("ySplit",1),new XAttribute("topLeftCell","A2"),new XAttribute("activePane","bottomLeft"),new XAttribute("state","frozen")))),new XElement(S+"cols",sheet.Headers.Select((v,c)=>new XElement(S+"col",new XAttribute("min",c+1),new XAttribute("max",c+1),new XAttribute("width",v.Contains("Commentaire")?45:v.Contains("férence")||v.Contains("ID")?32:23),new XAttribute("customWidth",1)))),data,new XElement(S+"autoFilter",new XAttribute("ref",range))));
    }
   }
   File.Move(tmp,path,true);
  }finally{if(File.Exists(tmp))File.Delete(tmp);}
 }
}

