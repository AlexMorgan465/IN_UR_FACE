using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using System.Windows.Media;
using System.Globalization;

namespace CofidisManager;
public partial class MainWindow : Window
{
    private string root = Environment.GetEnvironmentVariable("COFIDIS_DATA_ROOT") ??
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "CofidisApp", "Data");
    private readonly JsonSerializerOptions options = new() { PropertyNameCaseInsensitive = true };
    private List<Dossier> all = new();
    private List<Dossier> filtered = new();
    private bool ready;

    public MainWindow()
    {
        InitializeComponent();
        TreatmentFilter.Items.Add("Tous les traitements");
        TreatmentFilter.SelectedIndex = 0;
        ready = true;
        RefreshData();
    }
    private void Refresh_Click(object sender, RoutedEventArgs e) => RefreshData();
    private void Browse_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFolderDialog { Title = "Sélectionner COFIDIS_DATA (dossier racine des JSON)" };
        if (dialog.ShowDialog() == true) { root = dialog.FolderName; RefreshData(); }
    }
    private static string FormatDmt(IEnumerable<Dossier> source)
    {
        var completed = source.Where(d => d.Statut == "Termine" && d.DmtSecondes.HasValue).ToList();
        return completed.Count == 0 ? "—" : TimeSpan.FromSeconds(completed.Average(d => d.DmtSecondes!.Value)).ToString(@"hh\:mm\:ss");
    }
    private static bool IsMonthDirectory(string path) => DateTime.TryParseExact(Path.GetFileName(path), "MM-yyyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _);
    private void RefreshData()
    {
        try
        {
            if (!Directory.Exists(root))
            {
                all = new();
                StatusText.Text = "Dossier inexistant : choisissez la racine des données";
            }
            else
            {
                var records = new List<Dossier>();
                int files = 0;
                foreach (var monthDir in Directory.EnumerateDirectories(root).Where(IsMonthDirectory))
                {
                    foreach (var file in Directory.EnumerateFiles(monthDir, "*.json", SearchOption.TopDirectoryOnly))
                    {
                        records.AddRange(Read(file)); files++;
                    }
                    var canceledDir = Path.Combine(monthDir, "Traitements_Annules");
                    if (Directory.Exists(canceledDir))
                    foreach (var file in Directory.EnumerateFiles(canceledDir, "*.json", SearchOption.TopDirectoryOnly))
                    {
                        records.AddRange(Read(file)); files++;
                    }
                }
                // If a cancellation transfer was interrupted, show only the archived version.
                all = records.GroupBy(d => d.Id).Select(g => g.OrderByDescending(d => d.Statut == "Annule").First()).ToList();
                StatusText.Text = $"{files} fichier(s) JSON chargé(s) · {DateTime.Now:HH:mm:ss}";
            }
            RootText.Text = "Données : " + root;
            var types = all.Select(d => d.Traitement).Where(s => !string.IsNullOrWhiteSpace(s)).Distinct().OrderBy(s => s).ToArray();
            string selected = TreatmentFilter.SelectedItem?.ToString() ?? "Tous les traitements";
            TreatmentFilter.Items.Clear(); TreatmentFilter.Items.Add("Tous les traitements");
            foreach (var type in types) TreatmentFilter.Items.Add(type);
            TreatmentFilter.SelectedItem = types.Contains(selected) ? selected : "Tous les traitements";
            ApplyFilters();
        }
        catch (Exception ex)
        {
            MessageBox.Show("Lecture impossible. Aucune donnée n'a été modifiée.\n\n" + ex.Message, "Erreur de consolidation", MessageBoxButton.OK, MessageBoxImage.Error);
            StatusText.Text = "Erreur de lecture — données précédentes conservées";
        }
    }
    private IEnumerable<Dossier> Read(string file)
    {
        var json = File.ReadAllText(file, Encoding.UTF8);
        var list = JsonSerializer.Deserialize<List<Dossier>>(json, options) ?? throw new InvalidDataException("JSON vide ou invalide : " + file);
        foreach (var d in list)
        {
            if (string.IsNullOrWhiteSpace(d.Id)) throw new InvalidDataException("ID manquant : " + file);
            if (string.IsNullOrWhiteSpace(d.Collaborateur)) throw new InvalidDataException("Collaborateur manquant : " + file);
        }
        return list;
    }
    private void UpdateDashboard()
    {
        var data = filtered;
        TotalKpi.Text = data.Count.ToString();
        DoneKpi.Text = data.Count(d => d.Statut == "Termine").ToString();
        OpenKpi.Text = data.Count(d => d.Statut == "EnCours").ToString();
        CancelKpi.Text = data.Count(d => d.Statut == "Annule").ToString();
        DmtKpi.Text = FormatDmt(data);
        AgentGrid.ItemsSource = data.GroupBy(d => d.Collaborateur, StringComparer.OrdinalIgnoreCase).OrderBy(g => g.Key)
            .Select(g => new { Agent = g.Key, Termines = g.Count(d => d.Statut == "Termine"), EnCours = g.Count(d => d.Statut == "EnCours"), Annules = g.Count(d => d.Statut == "Annule"), DmtMoyen = FormatDmt(g) }).ToList();
        TreatmentGrid.ItemsSource = data.GroupBy(d => d.Traitement, StringComparer.OrdinalIgnoreCase).OrderBy(g => g.Key)
            .Select(g => new { Traitement = g.Key, Termines = g.Count(d => d.Statut == "Termine"), EnCours = g.Count(d => d.Statut == "EnCours"), Annules = g.Count(d => d.Statut == "Annule"), DmtMoyen = FormatDmt(g) }).ToList();
        UpdateCharts(data);
    }
    private void UpdateCharts(IEnumerable<Dossier> records)
    {
        var done = records.Where(d => d.Statut == "Termine").ToList();
        static string Safe(string? s) => string.IsNullOrWhiteSpace(s) ? "Non renseigné" : s.Trim();
        TreatmentChart.SetValues(done.GroupBy(d => Safe(d.Traitement), StringComparer.OrdinalIgnoreCase).Select(g => (g.Key, (double)g.Count())));
        CreditChart.SetValues(done.Where(d => d.Traitement != "SOLVA").GroupBy(d => Safe(d.TypeCredit), StringComparer.OrdinalIgnoreCase).Select(g => (g.Key, (double)g.Count())));
        SignatureChart.SetValues(done.Where(d => d.Traitement != "SOLVA").GroupBy(d => Safe(d.TypeSignature), StringComparer.OrdinalIgnoreCase).Select(g => (g.Key, (double)g.Count())));
        DecisionChart.SetValues(done.Where(d => d.Traitement != "SOLVA").GroupBy(d => Safe(d.Decision), StringComparer.OrdinalIgnoreCase).Select(g => (g.Key, (double)g.Count())));
        MonthlyChart.SetValues(done.GroupBy(d => d.DateDebut.ToString("yyyy-MM")).OrderBy(g => g.Key).Select(g => (g.Key, (double)g.Count())));
        DmtChart.SetValues(done.Where(d => d.DmtSecondes.HasValue).GroupBy(d => Safe(d.Traitement), StringComparer.OrdinalIgnoreCase).Select(g => (g.Key, g.Average(d => d.DmtSecondes!.Value) / 60.0)));
    }
    private void Filter_Changed(object sender, EventArgs e) { if (ready) ApplyFilters(); }
    private void ClearDates_Click(object sender, RoutedEventArgs e) { FromDate.SelectedDate = null; ToDate.SelectedDate = null; ApplyFilters(); }
    private void ApplyFilters()
    {
        if (!ready) return;
        IEnumerable<Dossier> query = all;
        if (FromDate.SelectedDate is DateTime from) query = query.Where(d => d.DateDebut.Date >= from.Date);
        if (ToDate.SelectedDate is DateTime to) query = query.Where(d => d.DateDebut.Date <= to.Date);
        string text = SearchBox.Text.Trim();
        if (text.Length > 0) query = query.Where(d => (d.ReferenceDossier + " " + d.Collaborateur + " " + d.Commentaire).Contains(text, StringComparison.OrdinalIgnoreCase));
        string treatment = TreatmentFilter.SelectedItem?.ToString() ?? "Tous les traitements";
        if (treatment != "Tous les traitements") query = query.Where(d => d.Traitement == treatment);
        string status = (StatusFilter.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Tous les statuts";
        if (status != "Tous les statuts") query = query.Where(d => d.Statut == status);
        filtered = query.OrderByDescending(d => d.DateDebut).ToList();
        ConsolidationGrid.ItemsSource = filtered;
        CountText.Text = filtered.Count + " ligne(s)";
        UpdateDashboard();
    }
    private void Export_Click(object sender, RoutedEventArgs e)
    {
        if (filtered.Count == 0) { MessageBox.Show("Aucune ligne à exporter dans la consolidation filtrée."); return; }
        var dialog = new SaveFileDialog { Title = "Exporter la consolidation", Filter = "CSV Excel (*.csv)|*.csv", FileName = $"Cofidis_Consolidation_{DateTime.Now:yyyyMMdd_HHmmss}.csv" };
        if (dialog.ShowDialog() != true) return;
        try
        {
            static string Esc(object? value) => "\"" + Convert.ToString(value, System.Globalization.CultureInfo.InvariantCulture)?.Replace("\"", "\"\"") + "\"";
            using var writer = new StreamWriter(dialog.FileName, false, new UTF8Encoding(true));
            writer.WriteLine("Collaborateur;Jour;Traitement;Canal;Reference;Credit;Produit;Solvabilite;Type SOLVA;Decision SOLVA;Signature;Decision;Commentaire;Debut;Fin;DMT secondes;Statut;Date annulation;ID");
            foreach (var d in filtered)
            {
                object?[] cells = { d.Collaborateur, d.Jour, d.Traitement, d.Canal, d.ReferenceDossier, d.TypeCredit, d.TypeProduit, d.Solvabilite, d.TypeSolva, d.DecisionSolva, d.TypeSignature, d.Decision, d.Commentaire, d.DateDebut.ToString("yyyy-MM-dd HH:mm:ss"), d.DateFin?.ToString("yyyy-MM-dd HH:mm:ss"), d.DmtSecondes, d.Statut, d.DateAnnulation?.ToString("yyyy-MM-dd HH:mm:ss"), d.Id };
                writer.WriteLine(string.Join(";", cells.Select(Esc)));
            }
            MessageBox.Show($"{filtered.Count} ligne(s) exportée(s).\n{dialog.FileName}", "Export terminé");
        }
        catch (Exception ex) { MessageBox.Show("Export impossible : " + ex.Message, "Erreur", MessageBoxButton.OK, MessageBoxImage.Error); }
    }
    private void ExportExcel_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var records = filtered.ToList();
            if (records.Count == 0) { MessageBox.Show("Aucune donnée à exporter."); return; }
            var dialog = new Microsoft.Win32.SaveFileDialog { Title = "Exporter vers Excel", Filter = "Classeur Excel (*.xlsx)|*.xlsx", DefaultExt = ".xlsx", AddExtension = true, FileName = $"Cofidis_Manager_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx" };
            if (dialog.ShowDialog() != true) return;
            var details = new CofidisExport.ExcelExport.Sheet("Traitements", new[] { "Collaborateur", "Traitement", "Canal", "Référence", "Crédit", "Produit", "Solvabilité", "Type SOLVA", "Décision SOLVA", "Signature", "Décision", "Commentaire", "Début", "Fin", "DMT secondes", "Statut", "Date annulation", "ID" }, records.Select(d => new object?[] { d.Collaborateur, d.Traitement, d.Canal, d.ReferenceDossier, d.TypeCredit, d.TypeProduit, d.Solvabilite, d.TypeSolva, d.DecisionSolva, d.TypeSignature, d.Decision, d.Commentaire, d.DateDebut, d.DateFin, d.DmtSecondes, d.Statut, d.DateAnnulation, d.Id }).ToList());
            var summary = new CofidisExport.ExcelExport.Sheet("Synthèse collaborateurs", new[] { "Collaborateur", "Total", "Terminés", "En cours", "Annulés", "DMT moyen secondes" }, records.GroupBy(d => d.Collaborateur, StringComparer.OrdinalIgnoreCase).OrderBy(g => g.Key).Select(g => new object?[] { g.Key, g.Count(), g.Count(d => d.Statut == "Termine"), g.Count(d => d.Statut == "EnCours"), g.Count(d => d.Statut == "Annule"), g.Where(d => d.Statut == "Termine" && d.DmtSecondes.HasValue).Select(d => d.DmtSecondes).Average() }).ToList());
            CofidisExport.ExcelExport.Save(dialog.FileName, summary, details);
            MessageBox.Show($"{records.Count} traitement(s) exporté(s).\n{dialog.FileName}", "Export Excel terminé");
        }
        catch (Exception ex) { MessageBox.Show("Export Excel impossible : " + ex.Message, "Erreur", MessageBoxButton.OK, MessageBoxImage.Error); }
    }
}


