$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
dotnet build .\CofidisManager.csproj -c Release
if ($LASTEXITCODE -ne 0) { throw 'Compilation echouee' }
Write-Host 'EXE : bin\Release\net8.0-windows\CofidisManager.exe'
