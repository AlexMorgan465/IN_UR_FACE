using System;
using System.Linq;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Media;
namespace CofidisManager;
public sealed class DashboardChart : FrameworkElement
{
 public string Kind {get;set;} = "Donut";
 private List<(string Label,double Value)> values = new();
 private static Brush Color(int i) => (Brush)new BrushConverter().ConvertFromString(new[]{"#CE0028","#E49A28","#346C9D","#19947D","#8D65B8","#D66B54","#6382A3","#779A40"}[i%8])!;
 public void SetValues(IEnumerable<(string Label,double Value)> source){values=source.Where(v=>double.IsFinite(v.Value)&&v.Value>=0).ToList();InvalidateVisual();}
 private void Text(DrawingContext dc,string s,double x,double y,double size=12,bool center=false){var t=new FormattedText(s,CultureInfo.CurrentCulture,FlowDirection.LeftToRight,new Typeface("Segoe UI"),size,Brushes.DarkSlateGray,VisualTreeHelper.GetDpi(this).PixelsPerDip);dc.DrawText(t,new Point(center?x-t.Width/2:x,y));}
 protected override void OnRender(DrawingContext dc){
  base.OnRender(dc);double w=ActualWidth,h=ActualHeight;if(w<40||h<40)return;
  if(values.Count==0||values.All(v=>v.Value==0)){Text(dc,"Aucune donnée pour cette sélection",w/2,h/2,13,true);return;}
  if(Kind=="Donut"){
   var items=values.Where(v=>v.Value>0).OrderByDescending(v=>v.Value).ToList();
   if(items.Count>7)items=items.Take(7).Append(("Autres",items.Skip(7).Sum(v=>v.Value))).ToList();
   double total=items.Sum(v=>v.Value),r=Math.Min(h*.40,w*.20),angle=-Math.PI/2;var c=new Point(w*.24,h/2);
   for(int i=0;i<items.Count;i++){
    double sweep=items[i].Value/total*Math.PI*2;
    if(items.Count==1)dc.DrawEllipse(Color(i),null,c,r,r);
    else{var g=new StreamGeometry();using(var ctx=g.Open()){ctx.BeginFigure(c,true,true);ctx.LineTo(new Point(c.X+r*Math.Cos(angle),c.Y+r*Math.Sin(angle)),true,false);ctx.ArcTo(new Point(c.X+r*Math.Cos(angle+sweep),c.Y+r*Math.Sin(angle+sweep)),new Size(r,r),0,sweep>Math.PI,SweepDirection.Clockwise,true,false);}dc.DrawGeometry(Color(i),new Pen(Brushes.White,2),g);}angle+=sweep;
   }
   dc.DrawEllipse(Brushes.White,null,c,r*.66,r*.66);Text(dc,total.ToString("N0"),c.X,c.Y-22,27,true);Text(dc,"terminés",c.X,c.Y+13,11,true);
   double row=Math.Min(27,(h-10)/items.Count),top=(h-row*items.Count)/2;
   for(int i=0;i<items.Count;i++){double y=top+i*row;dc.DrawRoundedRectangle(Color(i),null,new Rect(w*.49,y+5,9,9),3,3);string label=items[i].Label.Length>18?items[i].Label[..16]+"…":items[i].Label;Text(dc,label,w*.49+17,y,11);Text(dc,$"{items[i].Value:N0} · {items[i].Value/total:P0}",w*.82,y,11);}
  }else{
   var items=Kind=="Line"?values:values.OrderByDescending(v=>v.Value).ToList();double left=46,right=w-18,top=24,bottom=h-38,max=items.Max(v=>v.Value),step=Math.Pow(10,Math.Floor(Math.Log10(max))),ceiling=Math.Ceiling(max/step)*step;
   for(int j=0;j<=4;j++){double y=bottom-(bottom-top)*j/4;dc.DrawLine(new Pen(Brushes.AliceBlue,1),new Point(left,y),new Point(right,y));Text(dc,(ceiling*j/4).ToString("0.##"),0,y-8,10);}
   double slot=(right-left)/items.Count;Point? previous=null;int stride=Math.Max(1,(int)Math.Ceiling(items.Count/Math.Max(1,(right-left)/80)));
   for(int i=0;i<items.Count;i++){double x=left+slot*(i+.5),y=bottom-(bottom-top)*items[i].Value/ceiling;
    if(Kind=="Line"){var p=new Point(x,y);if(previous.HasValue)dc.DrawLine(new Pen(Color(0),3),previous.Value,p);dc.DrawEllipse(Brushes.White,new Pen(Color(0),3),p,5,5);previous=p;}
    else dc.DrawRoundedRectangle(Color(i),null,new Rect(x-Math.Min(45,slot*.55)/2,y,Math.Min(45,slot*.55),Math.Max(0,bottom-y)),4,4);
    if(i%stride==0){Text(dc,items[i].Value.ToString(Kind=="Line"?"0":"0.0")+(Kind=="Line"?"":" min"),x,y-21,11,true);string label=items[i].Label.Length>12?items[i].Label[..10]+"…":items[i].Label;Text(dc,label,x,bottom+12,10,true);}
   }
  }
 }
}
