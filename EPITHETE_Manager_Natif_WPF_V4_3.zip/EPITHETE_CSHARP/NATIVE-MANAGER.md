# EPITHÈTE V4.3 — Manager natif WPF

- `Lancer-Manager.cmd` démarre `bin/Manager-Native/EPITHETE-Manager.exe`. Cette version utilise une interface WPF/XAML native et ne référence pas WebView2.
- `Lancer-Agent.cmd` démarre l’Agent WebView2 inchangé dans `bin/Agent-WebView2/`.
- Les deux exécutables partagent le même moteur métier C# (`InvoiceService`, `FileStore`, `ExcelFiles`) et les mêmes données.
- Le Manager natif comprend le tableau de bord, les filtres de période/texte/statut, l’affectation en masse, les vues affectés/terminés, l’export Excel, l’import Excel, l’historique d’import, le traitement des doublons et les paramètres de répertoires.
- Les calculs métier et le format de stockage ne sont pas modifiés.
- Les fonctions de présentation PDF/PPT et la saisie manuelle détaillée des KPI CDO de l’ancienne interface web ne sont pas encore portées dans cette première interface native. Elles ne sont pas supprimées des données ; elles restent à réimplémenter nativement si elles sont nécessaires.
- Compilation requise sur Windows x64 avec .NET Framework 4.8/4.8.1 et Excel de bureau pour les opérations Excel.

Pour le Manager seul : `Recompiler-Manager.cmd`, puis `Lancer-Manager.cmd`. Pour recompiler aussi l’Agent : `Recompiler.cmd`, puis `Lancer-Agent.cmd`.
