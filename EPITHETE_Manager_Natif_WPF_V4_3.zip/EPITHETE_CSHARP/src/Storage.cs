﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace EpitheteDesktop
{
    internal static class JsonData
    {
        public static JToken Parse(string text)
        {
            using (var reader = new JsonTextReader(new StringReader(text.TrimStart('\uFEFF'))))
            {
                reader.DateParseHandling = DateParseHandling.None;
                reader.FloatParseHandling = FloatParseHandling.Decimal;
                reader.MaxDepth = 128;
                JToken result = JToken.Load(reader, new JsonLoadSettings { DuplicatePropertyNameHandling = DuplicatePropertyNameHandling.Error });
                while (reader.Read()) if (reader.TokenType != JsonToken.Comment) throw new InvalidDataException("Contenu JSON supplementaire inattendu.");
                return result;
            }
        }
        public static string Text(JToken value) { return value == null || value.Type == JTokenType.Null ? "" : value.Type == JTokenType.String ? (string)value : value.ToString(Formatting.None); }
        public static string Field(JObject row, string key) { return Text(row[key]); }
        public static JObject Obj(params object[] pairs)
        {
            var result = new JObject();
            for (int i = 0; i < pairs.Length; i += 2)
            {
                object value = pairs[i + 1];
                result[(string)pairs[i]] = value == null ? JValue.CreateNull() : value is JToken ? ((JToken)value).DeepClone() : JToken.FromObject(value);
            }
            return result;
        }
        public static string Now() { return DateTimeOffset.Now.ToString("o", CultureInfo.InvariantCulture); }
        public static string Normalize(string value)
        {
            var builder = new StringBuilder();
            foreach (char c in (value ?? "").Normalize(NormalizationForm.FormD))
                if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark) builder.Append(c);
            return System.Text.RegularExpressions.Regex.Replace(builder.ToString().ToLowerInvariant(), @"\s+", " ").Trim();
        }
        public static JArray Array(JToken token)
        {
            if (token == null || token.Type == JTokenType.Null) return new JArray();
            return token is JArray ? (JArray)token : new JArray(token.DeepClone());
        }
    }

    internal static class AtomicFile
    {
        public static void Write(string path, byte[] bytes)
        {
            string temp = Path.Combine(Path.GetDirectoryName(path), ".epithete-" + Guid.NewGuid().ToString("N") + ".tmp");
            try
            {
                using (var file = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                { file.Write(bytes, 0, bytes.Length); file.Flush(true); }
                if (File.Exists(path)) File.Replace(temp, path, path + ".bak", true);
                else File.Move(temp, path);
            }
            finally { if (File.Exists(temp)) File.Delete(temp); }
        }
    }

    internal sealed class FileStore
    {
        public const string DefaultDataDirectory = @"\\uf11-A02\EIDS_EPITHETE_BO_CONSEILLERS\Epithéte\data";
        public const string DefaultSourceDirectory = @"\\uf11-A02\EIDS_EPITHETE_BO_MANAGERS\ETAFAC\Source";
        public readonly string DirectoryPath;
        public string DatabasePath { get { return Path.Combine(DirectoryPath, "epithete-traitements.json"); } }
        public string ConfigPath { get { return Path.Combine(DirectoryPath, "epithete-config.json"); } }
        public FileStore(string directory)
        {
            if (String.IsNullOrWhiteSpace(directory)) throw new ArgumentException("Dossier de donnees obligatoire.");
            DirectoryPath = Path.GetFullPath(directory);
        }
        public T Locked<T>(Func<T> action)
        {
            if (!Directory.Exists(DirectoryPath)) throw new DirectoryNotFoundException("Dossier de donnees inaccessible : " + DirectoryPath + ". Verifiez desktop-config.json et vos droits sur le DP.");
            FileStream handle = null;
            for (int i = 0; i < 80 && handle == null; i++)
            {
                try { handle = new FileStream(Path.Combine(DirectoryPath, "epithete.verrou"), FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None); }
                catch (IOException) { if (i == 79) throw new IOException("Donnees occupees. Reessayez dans quelques secondes."); Thread.Sleep(100); }
            }
            using (handle) return action();
        }
        private sealed class CacheEntry { public long Length; public DateTime Time; public JToken Value; }
        private readonly Dictionary<string,CacheEntry> cache=new Dictionary<string,CacheEntry>(StringComparer.OrdinalIgnoreCase);
        public long BytesRead { get; private set; }
        public int FilesRead { get; private set; }
        private JToken Cached(string path)
        {
            lock(cache) {
            var info=new FileInfo(path); if(!info.Exists) return null;
            CacheEntry entry;
            if(!cache.TryGetValue(path,out entry) || entry.Length!=info.Length || entry.Time!=info.LastWriteTimeUtc)
            {
                JToken value=Read(path); BytesRead+=info.Length; FilesRead++;
                entry=new CacheEntry {Length=info.Length,Time=info.LastWriteTimeUtc,Value=value};cache[path]=entry;
            }
            return entry.Value; }
        }
        private string AgentDirectory { get { return Path.Combine(DirectoryPath,"agents-v3"); } }
        private string DailyDirectory { get { return Path.Combine(DirectoryPath,"agents-daily"); } }
        private static string AgentName(string agent) { return System.Text.RegularExpressions.Regex.Replace(agent.ToUpperInvariant(), @"[^A-Z0-9_.-]", "_") + "-" + Hash(agent.ToUpperInvariant()).Substring(0,12); }
        private IEnumerable<string> DailyFiles(string agent)
        {
            string root=agent==null?DailyDirectory:Path.Combine(DailyDirectory,AgentName(agent));
            return Directory.Exists(root)?Directory.GetFiles(root,"*.json",SearchOption.AllDirectories).OrderBy(f=>Path.GetFileName(f),StringComparer.Ordinal):Enumerable.Empty<string>();
        }
        private JObject AgentMap(string agent)
        {
            var legacy=Cached(AgentPath(agent)) as JObject;
            var map=legacy==null?new JObject():(JObject)legacy.DeepClone();
            foreach(string file in DailyFiles(agent)) { var daily=Cached(file) as JObject; if(daily==null)throw new InvalidDataException("Journal agent invalide : "+file);foreach(var field in daily.Properties())map[field.Name]=field.Value.DeepClone(); }
            return map;
        }
        public void PublishSnapshot(List<JObject> rows)
        {
            Locked(delegate { string path=Path.Combine(DirectoryPath,"epithete-consolide.json");var snapshot=JsonData.Obj("schemaVersion",4,"generatedAt",JsonData.Now(),"traitements",new JArray(ReadRecords()));Put(path,snapshot);BackupDailySnapshot();return true; });
        }
        private void BackupDailySnapshot()
        {
            string destination=Path.Combine(DirectoryPath,"backups","daily",DateTime.Today.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture));
            string manifest=Path.Combine(destination,"complete.json");if(File.Exists(manifest))return;
            Directory.CreateDirectory(destination);
            var files=new List<string>();
            files.AddRange(Directory.GetFiles(DirectoryPath,"*.json"));
            foreach(string name in new[] {"agents-v3","agents-daily","affectations-v3","traitements-v2"})
            {string root=Path.Combine(DirectoryPath,name);if(Directory.Exists(root))files.AddRange(Directory.GetFiles(root,"*.json",SearchOption.AllDirectories));}
            var entries=new JArray();
            foreach(string file in files) {
                string relative=file.Substring(DirectoryPath.TrimEnd(Path.DirectorySeparatorChar).Length+1);
                string target=Path.Combine(destination,relative);Directory.CreateDirectory(Path.GetDirectoryName(target));
                using(var input=new FileStream(file,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete))
                using(var bytes=new MemoryStream()){input.CopyTo(bytes);AtomicFile.Write(target,bytes.ToArray());}entries.Add(relative);
            }
            string ready=Path.Combine(AgentDirectory,"ready.marker");
            if(File.Exists(ready)) {Directory.CreateDirectory(Path.Combine(destination,"agents-v3"));AtomicFile.Write(Path.Combine(destination,"agents-v3","ready.marker"),Encoding.UTF8.GetBytes("V3"));}
            Write(manifest,JsonData.Obj("createdAt",JsonData.Now(),"files",entries));
        }
        private string AssignmentDirectory { get { return Path.Combine(DirectoryPath,"affectations-v3"); } }
        private string AgentPath(string agent) { return Path.Combine(AgentDirectory,Hash(agent.ToUpperInvariant())+".json"); }
        private string AssignmentPath(string agent) { return Path.Combine(AssignmentDirectory,Hash(agent.ToUpperInvariant())+".json"); }
        private string Stamp() { var f=new FileInfo(DatabasePath); if(!f.Exists) throw new FileNotFoundException("Base introuvable.",DatabasePath);return f.LastWriteTimeUtc.Ticks+":"+f.Length; }
        private bool IsReady { get { return File.Exists(Path.Combine(AgentDirectory,"ready.marker")); } }
        private static readonly string[] TreatmentFields=new[] {"statut","datePriseEnCharge","dateFin","etatTraitement","dateModification","dmtSecondes","dateExport","journal","offlineCommitId"};
        private static JObject Patch(JObject row)
        {var patch=new JObject();foreach(string key in TreatmentFields)if(row[key]!=null)patch[key]=row[key].DeepClone();return patch;}
        private static string FileStamp(string path) {var f=new FileInfo(path);return f.Exists?f.LastWriteTimeUtc.Ticks+":"+f.Length:"missing";}
        public string Revision(string owner)
        {
            var parts=new List<string> {DateTime.Today.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture),Stamp(),FileStamp(ConfigPath),FileStamp(Path.Combine(AssignmentDirectory,"index.json")),IsReady?"ready":"legacy"};
            if(owner!=null) {parts.Add(FileStamp(AssignmentPath(owner)));parts.Add(FileStamp(AgentPath(owner)));foreach(string f in DailyFiles(owner))parts.Add(FileStamp(f));}
            else
            {
                parts.Add(DateTime.Today.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture));parts.Add(FileStamp(Path.Combine(DirectoryPath,"imports-v2.json")));foreach(string f in DailyFiles(null))parts.Add(f+":"+FileStamp(f));
                if(Directory.Exists(AgentDirectory))foreach(var f in new DirectoryInfo(AgentDirectory).GetFiles("*.json").OrderBy(f=>f.Name))parts.Add(f.Name+":"+f.LastWriteTimeUtc.Ticks+":"+f.Length);
            }
            return Hash(String.Join("|",parts));
        }
        public void EnsureReady()
        {
            var index=Cached(Path.Combine(AssignmentDirectory,"index.json")) as JObject;
            if(IsReady && index!=null && JsonData.Field(index,"stamp")==Stamp()) return;
            Locked(delegate
            {
                var rows=ReadRecords(false);
                if(!IsReady)
                {
                    // One-time V2 migration; existing V3 edits take precedence. Old files remain for rollback.
                    Directory.CreateDirectory(AgentDirectory);
                    foreach(var group in ReadRecords().Where(r=>!String.IsNullOrWhiteSpace(JsonData.Field(r,"agent"))).GroupBy(r=>JsonData.Field(r,"agent"),StringComparer.OrdinalIgnoreCase))
                        AgentLocked(group.Key,delegate
                        {
                            string path=AgentPath(group.Key);var map=Cached(path) as JObject;map=map==null?new JObject():(JObject)map.DeepClone();
                            foreach(var row in group)if(map[JsonData.Field(row,"id")]==null && (row["datePriseEnCharge"]!=null || row["dateFin"]!=null))map[JsonData.Field(row,"id")]=Patch(row);
                            Put(path,map);return true;
                        });
                    AtomicFile.Write(Path.Combine(AgentDirectory,"ready.marker"),Encoding.UTF8.GetBytes("V3"));
                }
                BuildAssignments(rows);return true;
            });
        }
        private void BuildAssignments(List<JObject> rows)
        {
            Directory.CreateDirectory(AssignmentDirectory);var agents=new JObject();
            foreach(var group in rows.Where(r=>!String.IsNullOrWhiteSpace(JsonData.Field(r,"agent"))).GroupBy(r=>JsonData.Field(r,"agent"),StringComparer.OrdinalIgnoreCase))
            {
                string path=AssignmentPath(group.Key);var array=new JArray(group);var existing=Cached(path);
                if(existing==null || !JToken.DeepEquals(existing,array))Put(path,array);
                agents[group.Key.ToUpperInvariant()]=Path.GetFileName(path);
            }
            // Publish only after all bundles. Interrupted rebuilds fall back to the central base.
            Put(Path.Combine(AssignmentDirectory,"index.json"),JsonData.Obj("stamp",Stamp(),"agents",agents));
        }
        public List<JObject> ReadRecords(bool overlays = true, string owner = null)
        {
            JToken token=null;
            if(owner!=null && IsReady)
            {
                var index=Cached(Path.Combine(AssignmentDirectory,"index.json")) as JObject;
                if(index!=null && JsonData.Field(index,"stamp")==Stamp())
                {
                    var agents=index["agents"] as JObject;
                    if(agents!=null && agents[owner.ToUpperInvariant()]!=null) token=Cached(AssignmentPath(owner));
                    else token=new JArray();
                }
            }
            if(token==null)token=Cached(DatabasePath);
            if(token==null)throw new FileNotFoundException("Base introuvable. Aucun JSON vide cree.",DatabasePath);
            var source=new List<JObject>();Flatten(token,source);
            var ids=new HashSet<string>(StringComparer.Ordinal);
            foreach(var row in source)if(String.IsNullOrEmpty(JsonData.Field(row,"id")) || !ids.Add(JsonData.Field(row,"id")))throw new InvalidDataException("Identifiant absent ou duplique.");
            var rows=source.Where(r=>owner==null || String.Equals(JsonData.Field(r,"agent"),owner,StringComparison.OrdinalIgnoreCase)).Select(r=>(JObject)r.DeepClone()).ToList();
            if(!overlays)return rows;
            var patches=new Dictionary<string,JObject>(StringComparer.OrdinalIgnoreCase);
            if(owner!=null) patches[owner]=AgentMap(owner);
            else foreach(string agent in rows.Select(r=>JsonData.Field(r,"agent")).Distinct(StringComparer.OrdinalIgnoreCase))patches[Hash(agent.ToUpperInvariant())]=AgentMap(agent);
            bool ready=IsReady;
            var legacy=new Dictionary<string,JObject>(StringComparer.OrdinalIgnoreCase);
            string oldDirectory=Path.Combine(DirectoryPath,"traitements-v2");
            if(!ready && Directory.Exists(oldDirectory))foreach(string file in Directory.GetFiles(oldDirectory,"*.json"))legacy[Path.GetFileNameWithoutExtension(file)]=Cached(file) as JObject;
            foreach(var row in rows)
            {
                string id=JsonData.Field(row,"id"),agent=JsonData.Field(row,"agent");
                if(!ready) {JObject old;legacy.TryGetValue(Hash(id),out old);if(old!=null)foreach(var field in old.Properties())row[field.Name]=field.Value.DeepClone();}
                JObject map=null;patches.TryGetValue(owner??Hash(agent.ToUpperInvariant()),out map);
                var patch=map==null?null:map[id] as JObject;
                if(patch!=null)foreach(var field in patch.Properties())row[field.Name]=field.Value.DeepClone();
            }
            return rows;
        }
        private static void Flatten(JToken token, List<JObject> rows)
        {
            var array = token as JArray;
            if (array != null) { foreach (JToken item in array) Flatten(item, rows); return; }
            var row = token as JObject;
            if (row == null) throw new InvalidDataException("La base doit contenir des objets JSON dans un tableau.");
            rows.Add(row);
        }
        private string RowPath(string id) { return Path.Combine(DirectoryPath, "traitements-v2", Hash(id) + ".json"); }
        public static string Hash(string value) { using (var h = System.Security.Cryptography.SHA256.Create()) return BitConverter.ToString(h.ComputeHash(Encoding.UTF8.GetBytes(value))).Replace("-", ""); }
        public T AgentLocked<T>(string agent, Func<T> action)
        {
            string dir = Path.Combine(DirectoryPath, "traitements-v2"); Directory.CreateDirectory(dir);
            FileStream handle = null;
            for (int i=0; i<150 && handle==null; i++)
            { try { handle = new FileStream(Path.Combine(dir, Hash(agent.ToUpperInvariant()) + ".lock"), FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None); }
              catch (IOException) { if(i==149) throw; Thread.Sleep(100); } }
            using(handle) return action();
        }
        public void SaveTreatment(JObject row)
        {
            Directory.CreateDirectory(AgentDirectory);
            string agent=JsonData.Field(row,"agent");
            string directory=Path.Combine(DailyDirectory,AgentName(agent));Directory.CreateDirectory(directory);
            string path=Path.Combine(directory,DateTime.Today.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture)+".json");
            var map=Cached(path) as JObject;map=map==null?new JObject():(JObject)map.DeepClone();
            map[JsonData.Field(row,"id")]=Patch(row);Put(path,map);
        }
        public string LedgerRevision { get { return FileStamp(Path.Combine(DirectoryPath,"imports-v2.json")); } }
        public JObject ReadLedger() { string path=Path.Combine(DirectoryPath,"imports-v2.json"); return File.Exists(path)?(JObject)Cached(path).DeepClone():JsonData.Obj("files",new JObject(),"history",new JArray(),"duplicates",new JArray()); }
        public void SaveLedger(JObject value) { Put(Path.Combine(DirectoryPath,"imports-v2.json"),value); }
        public JObject ReadConfig()
        {
            if (!File.Exists(ConfigPath)) return JsonData.Obj("sourceDirectory", DefaultSourceDirectory, "agents", new JArray());
            var config = Cached(ConfigPath).DeepClone() as JObject;
            if (config == null) throw new InvalidDataException("Configuration JSON invalide.");
            if (config["agents"] == null) config["agents"] = new JArray();
            return config;
        }
        public static JToken Read(string path)
        {
            string text;
            using(var stream=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete))
            using(var reader=new StreamReader(stream,new UTF8Encoding(false,true))) text=reader.ReadToEnd();
            if (String.IsNullOrWhiteSpace(text)) throw new InvalidDataException("Fichier JSON vide : " + Path.GetFileName(path) + ". Aucune modification effectuee.");
            return JsonData.Parse(text);
        }
        public void SaveRecords(List<JObject> rows) { Put(DatabasePath,new JArray(rows)); if(IsReady)BuildAssignments(rows); }
        public void SaveConfig(JObject config) { Put(ConfigPath, config); }
        private void Put(string path,JToken value)
        {
            if(File.Exists(path)) {
                string relative=path.Substring(DirectoryPath.TrimEnd(Path.DirectorySeparatorChar).Length+1);
                string backup=Path.Combine(DirectoryPath,"backups",DateTime.Today.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture),relative);
                Directory.CreateDirectory(Path.GetDirectoryName(backup));
                if(!File.Exists(backup))File.Copy(path,backup,false);
            }
            Write(path,value);lock(cache)cache.Remove(path);
        }
        private static void Write(string path, JToken value) { AtomicFile.Write(path, new UTF8Encoding(false).GetBytes(value.ToString(Formatting.None) + Environment.NewLine)); }
    }
}
