﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Newtonsoft.Json.Linq;
using D = EpitheteDesktop.JsonData;

namespace EpitheteDesktop
{
    internal sealed class ScanResult
    {
        public readonly List<JObject> Rows = new List<JObject>();
        public readonly List<string> Errors = new List<string>();
        public int Files;
        
        public int Skipped;
        public readonly JObject Fingerprints = new JObject();
    }
    internal sealed class ExportResult
    {
        public readonly List<JObject> Saved = new List<JObject>();
        public readonly List<string> Errors = new List<string>();
        public int Files;
    }
    internal interface IExcelFiles
    {
        ScanResult Scan(string directory, string user, JObject files);
        ExportResult Export(List<JObject> rows);
    }
    internal static class AgentRules
    {
        private static bool Has(JObject row,string field){return !String.IsNullOrEmpty(D.Field(row,field));}
        private static void Journal(JObject row,string user,string action,string detail){var history=new JArray(D.Array(row["journal"]).Select(t=>t.DeepClone()));history.Add(D.Obj("date",D.Now(),"auteur",user,"action",action,"detail",detail));row["journal"]=history;}
        public static JObject Apply(List<JObject> rows,string user,string command,JObject body)
        {
            if(!new[]{"start","finish","update"}.Contains(command))throw new InvalidOperationException("Action Agent non autorisee.");
            JObject row = rows.FirstOrDefault(r => D.Field(r, "id") == D.Field(body, "id"));
            if (row == null) throw new InvalidOperationException("Ligne introuvable.");
            if (!String.Equals(D.Field(row,"agent"),user,StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("Cette ligne est affectee a un autre agent.");
            string now = D.Now();
            if (command == "start")
            {
                if (Has(row, "datePriseEnCharge") || Has(row, "dateFin")) throw new InvalidOperationException("Cette ligne ne peut pas etre demarree.");
                if (rows.Any(r => String.Equals(D.Field(r,"agent"),user,StringComparison.OrdinalIgnoreCase) && Has(r, "datePriseEnCharge") && !Has(r, "dateFin"))) throw new InvalidOperationException("Vous avez deja un traitement en cours.");
                row["statut"] = "EN_COURS"; row["datePriseEnCharge"] = now;
                Journal(row, user, "Prise en charge", D.Field(row, "raisonSociale"));
            }
            else
            {
                bool update = command == "update";
                if (update && !Has(row, "dateFin")) throw new InvalidOperationException("Seul un traitement termine peut etre modifie.");
                if (!update && (!Has(row, "datePriseEnCharge") || Has(row, "dateFin"))) throw new InvalidOperationException("Traitement non demarre ou deja termine.");
                string state = D.Field(body, "etatTraitement").Trim();
                if (state.Length == 0) throw new InvalidOperationException("Etat du traitement est obligatoire.");
                if (state.Length > 500) throw new InvalidOperationException("Etat du traitement est trop long (500 caracteres maximum).");
                row["etatTraitement"] = state;
                if (update)
                {
                    row["dateModification"] = now; row["dateExport"] = JValue.CreateNull();
                    Journal(row, user, "Modification agent", D.Field(row, "raisonSociale"));
                }
                else
                {
                    DateTimeOffset started;
                    if (!DateTimeOffset.TryParse(D.Field(row, "datePriseEnCharge"), CultureInfo.InvariantCulture, DateTimeStyles.None, out started)) throw new InvalidOperationException("Date de prise en charge invalide.");
                    double seconds = Math.Max(0, Math.Floor((DateTimeOffset.Parse(now, CultureInfo.InvariantCulture) - started).TotalSeconds));
                    row["dmtSecondes"] = seconds; row["dateFin"] = now; row["statut"] = "TERMINE";
                    Journal(row, user, "Traitement terminé", "DMT " + seconds.ToString(CultureInfo.InvariantCulture) + " secondes");
                }
            }
            return row;
        }
    }
    internal sealed class InvoiceService
    {
        private readonly FileStore store;
        private readonly bool manager;
        private readonly string user;
        private readonly IExcelFiles excel;
        private readonly FileStore maintenanceStore;
        private readonly object maintenanceGate=new object();
        private bool maintenanceRunning, maintenanceRequested;
        private string maintenanceError="", maintenanceCompleted="";
        private JObject MaintenanceState() {lock(maintenanceGate)return D.Obj("busy",maintenanceRunning,"error",maintenanceError,"completedAt",maintenanceCompleted);}
        private void QueueMaintenance()
        {
            lock(maintenanceGate) { maintenanceRequested=true;if(maintenanceRunning)return;maintenanceRunning=true; }
            System.Threading.Tasks.Task.Run(delegate {
                while(true) {
                    lock(maintenanceGate)maintenanceRequested=false;
                    try { maintenanceStore.PublishSnapshot(null);lock(maintenanceGate){maintenanceError="";maintenanceCompleted=D.Now();} }
                    catch(Exception error) {lock(maintenanceGate)maintenanceError=error.Message;}
                    lock(maintenanceGate) {if(maintenanceRequested)continue;maintenanceRunning=false;return;}
                }
            });
        }
        public InvoiceService(FileStore store, bool manager, string user, IExcelFiles excel)
        { this.store = store; this.maintenanceStore=new FileStore(store.DirectoryPath); this.manager = manager; this.user = user; this.excel = excel; }
        public JObject Execute(string command, JObject body)
        {
            body = body ?? new JObject();
            if (command == "state") return State(body);
            if(manager && command=="maintenance") {QueueMaintenance();return MaintenanceState();}
            if(manager && command=="ledger")return store.Locked(delegate {return D.Obj("revision",store.LedgerRevision,"imports",store.ReadLedger());});
            if (manager && command == "import") return Import();
            if (manager && command == "export") return store.AgentLocked("$export-managers",delegate { return Export(body); });
            if (!manager) return store.AgentLocked(user, delegate { return Agent(command, body); });
            return store.Locked(delegate { return Manager(command, body); });
        }
        private JObject State(JObject body)
        {
            if(manager)store.EnsureReady();
            string revision=store.Revision(manager?null:user);
            if(D.Field(body,"revision")==revision)return D.Obj("unchanged",true,"revision",revision,"maintenance",MaintenanceState());
            List<JObject> rows = store.ReadRecords(true,manager?null:user);
            foreach(var row in rows)row.Remove("journal"); // Audit history remains on disk; neither UI renders it.
            if (!manager) {
                var result=D.Obj("application","EPITHETE AGENT","version","CSharp-4.2","collaborateur",user,"dataDirectory",store.DirectoryPath,"revision",revision,"actualiseLe",D.Now());
                result["traitements"]=new JArray(rows.Where(Own));return result;
            }
            QueueMaintenance();
            JObject cfg = store.ReadConfig(); cfg["dataDirectory"]=store.DirectoryPath; cfg["consolidatedPath"]=System.IO.Path.Combine(store.DirectoryPath,"epithete-consolide.json");
            var agents = D.Array(cfg["agents"]).Select(D.Text).Concat(rows.Select(r => D.Field(r, "agent")))
                .Where(n => !String.IsNullOrWhiteSpace(n)).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(n => n, StringComparer.OrdinalIgnoreCase);
            var response=D.Obj("application","EPITHETE MANAGER","version","CSharp-4.2","collaborateur",user,"config",cfg,"revision",revision,"importsRevision",store.LedgerRevision,"agents",new JArray(agents),"maintenance",MaintenanceState(),"actualiseLe",D.Now());
            response["traitements"]=new JArray(rows);return response;
        }

        private bool Own(JObject row) { return String.Equals(D.Field(row, "agent"), user, StringComparison.OrdinalIgnoreCase); }
        private static bool Has(JObject row, string field) { return !String.IsNullOrEmpty(D.Field(row, field)); }
        private static void Journal(JObject row, string user, string action, string detail)
        {
            var history = new JArray(D.Array(row["journal"]).Select(t => t.DeepClone()));
            history.Add(D.Obj("date", D.Now(), "auteur", user, "action", action, "detail", detail)); row["journal"] = history;
        }
        private JObject Agent(string command, JObject body)
        {
            if (!new[] { "start", "finish", "update" }.Contains(command)) throw new InvalidOperationException("Action non autorisee dans l'espace Agent.");
            var rows=store.ReadRecords(true,user);
            var row=AgentRules.Apply(rows,user,command,body);
            store.SaveTreatment(row); return D.Obj("ok", true);
        }
        private JObject Manager(string command, JObject body)
        {
            if (command == "duplicates")
            {
                var ledger=store.ReadLedger(); var ids=new HashSet<string>(D.Array(body["ids"]).Select(D.Text));
                var rows=store.ReadRecords(false); int count=0; string decision=D.Field(body,"decision");
                if (decision!="accept" && decision!="reject") throw new InvalidOperationException("Decision invalide.");
                foreach(var item in D.Array(ledger["duplicates"]).OfType<JObject>().Where(x=>ids.Contains(D.Field(x,"id")) && D.Field(x,"decision")=="pending"))
                {
                    var candidate=(JObject)item["row"]; string id=D.Field(candidate,"id");
                    if(decision=="accept" && !rows.Any(r=>D.Field(r,"id")==id)) { candidate["duplicateAccepted"]=true; rows.Add((JObject)candidate.DeepClone()); }
                    item["decision"]=decision; item["decidedBy"]=user; item["decidedAt"]=D.Now(); count++;
                }
                // Persist rows first; retry is idempotent if interrupted before ledger write.
                if(count>0) { store.SaveRecords(rows); store.SaveLedger(ledger); }
                return D.Obj("ok",true,"count",count);
            }
            if(command=="manualKpi")
            {
                string scope=D.Field(body,"scope"),period=D.Field(body,"period");
                if(scope.Length==0||scope.Length>3000||!System.Text.RegularExpressions.Regex.IsMatch(period,@"^(total|Sans date|\d{4}(-\d{2}(-\d{2})?|-S\d{2})?)$"))throw new InvalidOperationException("Perimetre ou periode KPI invalide.");
                var incoming=body["values"] as JObject;if(incoming==null)throw new InvalidOperationException("Valeurs KPI obligatoires.");
                var values=new JObject();foreach(var field in incoming.Properties()){
                    if(!new[]{"task","escalade","statu","agents"}.Contains(field.Name)||field.Value.Type!=Newtonsoft.Json.Linq.JTokenType.Integer)throw new InvalidOperationException("Saisir des nombres entiers positifs ou nuls.");
                    long number=(long)field.Value;if(number<0||number>100000000)throw new InvalidOperationException("Valeur KPI hors limites.");values[field.Name]=number;
                }
                var cfg=store.ReadConfig();var all=cfg["manualKpis"] as JObject??new JObject();var periods=all[scope] as JObject??new JObject();var previous=periods[period] as JObject;
                if(D.Field(body,"expectedVersion")!=(previous==null?"":D.Field(previous,"version")))throw new InvalidOperationException("Cette saisie a ete modifiee par un autre Manager. Actualisez avant de recommencer.");
                var entry=D.Obj("values",values,"version",Guid.NewGuid().ToString("N"),"updatedAt",D.Now(),"updatedBy",user);
                periods[period]=entry;all[scope]=periods;cfg["manualKpis"]=all;
                var history=D.Array(cfg["manualKpiHistory"]);history.Add(D.Obj("scope",scope,"period",period,"entry",entry));cfg["manualKpiHistory"]=history;store.SaveConfig(cfg);return D.Obj("ok",true);
            }
            if (command == "config")
            {
                string path = D.Field(body, "sourceDirectory").Trim();
                if (path.Length == 0) throw new InvalidOperationException("Chemin source obligatoire.");
                JObject cfg = store.ReadConfig(); cfg["sourceDirectory"] = path; store.SaveConfig(cfg); return D.Obj("ok", true);
            }
            if (command == "agents")
            {
                string name = D.Field(body, "name").Trim().ToUpperInvariant();
                if (name.Length == 0 || name.Length > 256) throw new InvalidOperationException("Nom de session agent invalide.");
                JObject cfg = store.ReadConfig(); cfg["agents"] = new JArray(D.Array(cfg["agents"]).Select(D.Text).Concat(new[] { name }).Where(n => n.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(n => n));
                store.SaveConfig(cfg); return D.Obj("ok", true, "name", name);
            }
            if (command == "assign")
            {
                string agent = D.Field(body, "agent").Trim();
                if (agent.Length == 0 || agent.Length > 256) throw new InvalidOperationException("Nom de l'agent obligatoire.");
                var ids = new HashSet<string>(D.Array(body["ids"]).Select(D.Text), StringComparer.Ordinal);
                List<JObject> rows = store.ReadRecords(false); int count = 0;
                foreach (JObject row in rows.Where(r => ids.Contains(D.Field(r, "id")) && !Has(r, "agent") && !Has(r, "dateFin")))
                {
                    row["agent"] = agent; row["statut"] = "Affecté"; row["dateAffectation"] = D.Now();
                    Journal(row, user, "Affectation", agent); count++;
                }
                if (count > 0) store.SaveRecords(rows);
                return D.Obj("ok", true, "affectees", count);
            }
            throw new InvalidOperationException("Action Manager inconnue.");
        }
        private JObject Import()
        {
            var elapsed=System.Diagnostics.Stopwatch.StartNew();
            // Serialize managers across Excel scan and commit; agents use independent locks.
            return store.Locked(delegate
            {
                var ledger=store.ReadLedger();
                var scan=excel.Scan(D.Field(store.ReadConfig(),"sourceDirectory"),user,(JObject)ledger["files"]);
                var rows=store.ReadRecords(false);
                var known=new Dictionary<string,JObject>(StringComparer.OrdinalIgnoreCase);
                foreach(var r in rows.Where(r=>Has(r,"numeroFacture"))) if(!known.ContainsKey(Key(r))) known[Key(r)]=r;
                var duplicates=D.Array(ledger["duplicates"]); int added=0, doubled=0;
                var occurrences=new HashSet<string>(rows.Select(Occurrence),StringComparer.OrdinalIgnoreCase);
                foreach(var d in duplicates.OfType<JObject>()) occurrences.Add(Occurrence((JObject)d["row"]));
                foreach(var candidate in scan.Rows)
                {
                    candidate.Remove("_hasSourceMotif");
                    if(!occurrences.Add(Occurrence(candidate))) continue;
                    JObject previous;
                    if(known.TryGetValue(Key(candidate),out previous))
                    {
                        duplicates.Add(D.Obj("id",Guid.NewGuid().ToString(),"row",candidate,"originalId",D.Field(previous,"id"),"originalFile",D.Field(previous,"sourceFile"),"decision","pending","date",D.Now())); doubled++;
                    }
                    else { rows.Add(candidate); known[Key(candidate)]=candidate; added++; }
                }
                ledger["duplicates"]=duplicates;
                foreach(var f in scan.Fingerprints.Properties()) ((JObject)ledger["files"])[f.Name]=f.Value.DeepClone();
                D.Array(ledger["history"]).Add(D.Obj("id",Guid.NewGuid().ToString(),"date",D.Now(),"user",user,"files",scan.Files,"skipped",scan.Skipped,"added",added,"duplicates",doubled,"sources",new JArray(scan.Fingerprints.Properties().Select(f=>f.Name)),"errors",new JArray(scan.Errors)));
                if(added>0) store.SaveRecords(rows); store.SaveLedger(ledger);
                return D.Obj("ok",true,"dureeSecondes",Math.Round(elapsed.Elapsed.TotalSeconds,1),"ajoutees",added,"fichiers",scan.Files,"ignores",scan.Skipped,"doublonsIgnores",doubled,"erreurs",new JArray(scan.Errors));
            });
        }
        private static string Key(JObject row) { return D.Normalize(D.Field(row,"numeroFacture")); }
        private static string Occurrence(JObject row) { return D.Field(row,"sourcePath").ToUpperInvariant()+"|"+D.Field(row,"sourceSheet").ToUpperInvariant()+"|"+D.Field(row,"sourceRow")+"|"+Key(row); }
        private JObject Export(JObject body)
        {
            var ids=new HashSet<string>(D.Array(body["ids"]).Select(D.Text));
            bool manual=ids.Count>0 || (bool?)body["selectedOnly"]==true;
            List<JObject> snapshot = store.ReadRecords().Where(r => Has(r,"dateFin") && Has(r,"numeroFacture") && Has(r,"sourcePath") && Has(r,"sourceSheet") && (manual ? ids.Contains(D.Field(r,"id")) : !Has(r,"dateExport"))).ToList();
            if (snapshot.Count == 0) throw new InvalidOperationException("Aucune facture terminee a exporter.");
            ExportResult result = excel.Export(snapshot);
            int marked=0;
            foreach(var saved in result.Saved)
                store.AgentLocked(D.Field(saved,"agent"),delegate
                {
                    var current=store.ReadRecords().FirstOrDefault(r=>D.Field(r,"id")==D.Field(saved,"id"));
                    if(current!=null && new[] {"etatTraitement","dateFin","dateModification","offlineCommitId"}.All(k=>D.Field(saved,k)==D.Field(current,k)))
                    { current["dateExport"]=D.Now(); store.SaveTreatment(current); marked++; }
                    else result.Errors.Add("Ligne modifiee pendant l'export : a reexporter.");
                    return true;
                });
            return D.Obj("ok",true,"exportees",marked,"fichiers",result.Files,"erreurs",new JArray(result.Errors));
        }
    }
}
