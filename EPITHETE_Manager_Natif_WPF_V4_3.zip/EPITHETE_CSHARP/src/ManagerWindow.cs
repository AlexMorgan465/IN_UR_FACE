using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using Microsoft.Win32;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using D = EpitheteDesktop.JsonData;

namespace EpitheteDesktop
{
    public sealed class ManagerRow
    {
        public string Id { get; set; } public string Numero { get; set; } public string Client { get; set; }
        public string Type { get; set; } public string Motif { get; set; } public string Source { get; set; }
        public string Agent { get; set; } public string Statut { get; set; } public string DateAffectation { get; set; }
        public string DateFin { get; set; } public string Etat { get; set; } public string Dmt { get; set; }
        public string Export { get; set; } public string Original { get; set; } public string Decision { get; set; }
        public string Date { get; set; } public string User { get; set; } public string Files { get; set; }
        public string Added { get; set; } public string Duplicates { get; set; } public string Skipped { get; set; }
    }

    internal sealed class ManagerWindow : Window
    {
        private readonly StaWorker worker = new StaWorker();
        private InvoiceService service;
        private FileStore store;
        private JObject state, ledger;
        private readonly ObservableCollection<ManagerRow> queueRows = new ObservableCollection<ManagerRow>();
        private readonly ObservableCollection<ManagerRow> assignedRows = new ObservableCollection<ManagerRow>();
        private readonly ObservableCollection<ManagerRow> doneRows = new ObservableCollection<ManagerRow>();
        private readonly ObservableCollection<ManagerRow> importRows = new ObservableCollection<ManagerRow>();
        private readonly ObservableCollection<ManagerRow> duplicateRows = new ObservableCollection<ManagerRow>();
        private UserControl root;
        private bool busy;

        public ManagerWindow()
        {
            Title = "ÉPITHÈTE · ETAFAC — Manager natif V4.3";
            Width = 1480; Height = 920; MinWidth = 1050; MinHeight = 680;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Epithete.ManagerWindow.xaml"))
            {
                if (stream == null) throw new InvalidOperationException("Ressource XAML du Manager introuvable.");
                root = XamlReader.Load(stream) as UserControl;
            }
            if (root == null) throw new InvalidDataException("La fenêtre XAML du Manager est invalide.");
            Content = root;
            BindGrids(); WireEvents();
            Loaded += async delegate { await Initialize(); };
            Closed += delegate { worker.Dispose(); };
        }

        private T Get<T>(string name) where T : class { T item = root.FindName(name) as T; if (item == null) throw new InvalidOperationException("Contrôle XAML introuvable : " + name); return item; }
        private static string DataDirectory()
        {
            string config = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "desktop-config.json");
            if (!File.Exists(config)) config = Path.Combine(Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar)), "desktop-config.json");
            if (!File.Exists(config)) return FileStore.DefaultDataDirectory;
            JObject value = FileStore.Read(config) as JObject; string directory = value == null ? "" : D.Field(value, "dataDirectory");
            if (String.IsNullOrWhiteSpace(directory)) throw new InvalidDataException("desktop-config.json : dataDirectory obligatoire.");
            return Path.IsPathRooted(directory) ? directory : Path.GetFullPath(Path.Combine(Path.GetDirectoryName(config), directory));
        }
        private void BindGrids()
        {
            Get<DataGrid>("QueueGrid").ItemsSource = queueRows; Get<DataGrid>("AssignedGrid").ItemsSource = assignedRows;
            Get<DataGrid>("DoneGrid").ItemsSource = doneRows; Get<DataGrid>("ImportGrid").ItemsSource = importRows;
            Get<DataGrid>("DuplicateGrid").ItemsSource = duplicateRows;
        }
        private void WireEvents()
        {
            Get<Button>("RefreshButton").Click += async delegate { await Refresh(); };
            Get<Button>("QuitButton").Click += delegate { Close(); };
            Get<Button>("ResetFilters").Click += delegate { Get<TextBox>("SearchBox").Clear(); Get<ComboBox>("YearFilter").SelectedIndex = 0; Get<ComboBox>("MonthFilter").SelectedIndex = 0; Get<ComboBox>("StatusFilter").SelectedIndex = 0; ApplyFilters(); };
            Get<TextBox>("SearchBox").TextChanged += delegate { ApplyFilters(); };
            Get<ComboBox>("YearFilter").SelectionChanged += delegate { ApplyFilters(); };
            Get<ComboBox>("MonthFilter").SelectionChanged += delegate { ApplyFilters(); };
            Get<ComboBox>("StatusFilter").SelectionChanged += delegate { ApplyFilters(); };
            Get<Button>("SelectAllQueue").Click += delegate { Get<DataGrid>("QueueGrid").SelectAll(); };
            Get<Button>("AssignButton").Click += async delegate { await AssignSelected(); };
            Get<Button>("AddAgentButton").Click += async delegate { await AddAgent(); };
            Get<Button>("ExportButton").Click += async delegate { await Export(); };
            Get<Button>("ImportButton").Click += async delegate { await Import(); };
            Get<Button>("AcceptDuplicates").Click += async delegate { await DecideDuplicates("accept"); };
            Get<Button>("RejectDuplicates").Click += async delegate { await DecideDuplicates("reject"); };
            Get<Button>("SaveSourceDirectory").Click += async delegate { await SaveSource(); };
            Get<Button>("SaveDataDirectory").Click += delegate { SaveDataPath(); };
            Get<Button>("MaintenanceButton").Click += async delegate { await Maintenance(); };
        }
        private void BindExcelProgress(ExcelFiles excel)
        {
            excel.Progress = delegate(JObject p) { Dispatcher.BeginInvoke(new Action(delegate { Get<TextBlock>("ImportStatus").Text = "Lecture : " + D.Field(p,"file") + " · " + D.Field(p,"sheet") + " · ligne " + D.Field(p,"row") + "/" + D.Field(p,"total"); })); };
        }
        private async Task Initialize()
        {
            try
            {
                store = new FileStore(DataDirectory()); var excel = new ExcelFiles(); BindExcelProgress(excel);
                service = new InvoiceService(store, true, Environment.UserName, excel);
                Get<TextBox>("DataDirectoryBox").Text = store.DirectoryPath;
                await Refresh();
            }
            catch (Exception ex) { SetStatus("Erreur au démarrage : " + ex.Message, true); }
        }
        private void SetStatus(string message, bool error)
        {
            Get<TextBlock>("FooterStatus").Text = message;
            Get<TextBlock>("ConnectionStatus").Text = error ? "Erreur" : "Manager natif connecté";
            Get<TextBlock>("ConnectionStatus").Foreground = error ? System.Windows.Media.Brushes.Firebrick : System.Windows.Media.Brushes.SeaGreen;
        }
        private async Task<JObject> Execute(string command, JObject body)
        {
            if (service == null) throw new InvalidOperationException("Le service Manager n'est pas initialisé.");
            return await worker.Run(delegate { return service.Execute(command, body); });
        }
        private async Task Refresh()
        {
            if (busy || service == null) return; busy = true;
            try
            {
                state = await Execute("state", null); ledger = await Execute("ledger", null);
                JObject cfg = state["config"] as JObject; if (cfg != null && !Get<TextBox>("SourceDirectoryBox").IsFocused) Get<TextBox>("SourceDirectoryBox").Text = D.Field(cfg,"sourceDirectory");
                PopulateFilters(); Render(); SetStatus("Données actualisées · " + D.Array(state["traitements"]).Count + " lignes", false);
            }
            catch (Exception ex) { SetStatus("Actualisation impossible : " + ex.Message, true); }
            finally { busy = false; }
        }
        private void PopulateFilters()
        {
            var years = new SortedSet<string>(); var months = new SortedSet<string>();
            foreach (JObject r in D.Array(state["traitements"]).OfType<JObject>())
            {
                DateTime dt; string date = First(r,"dateFin","dateAffectation","dateImport");
                if (DateTime.TryParse(date, CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal, out dt)) { years.Add(dt.Year.ToString()); months.Add(dt.Month.ToString("00")); }
            }
            ComboBox y = Get<ComboBox>("YearFilter"), m = Get<ComboBox>("MonthFilter"); string oldY = Selected(y), oldM = Selected(m);
            y.Items.Clear(); y.Items.Add("Toutes"); foreach (string v in years) y.Items.Add(v); y.SelectedItem = years.Contains(oldY) ? oldY : "Toutes";
            m.Items.Clear(); m.Items.Add("Tous"); foreach (string v in months) m.Items.Add(v); m.SelectedItem = months.Contains(oldM) ? oldM : "Tous";
        }
        private static string Selected(ComboBox combo) { if (combo.SelectedItem == null) return ""; ComboBoxItem item = combo.SelectedItem as ComboBoxItem; return item == null ? Convert.ToString(combo.SelectedItem) : Convert.ToString(item.Content); }
        private void ApplyFilters() { if (state != null) Render(); }
        private static string First(JObject r, params string[] keys) { foreach (string k in keys) if (!String.IsNullOrEmpty(D.Field(r,k))) return D.Field(r,k); return ""; }
        private static string FormatDate(string value) { DateTime dt; return DateTime.TryParse(value,CultureInfo.InvariantCulture,DateTimeStyles.AssumeLocal,out dt) ? dt.ToLocalTime().ToString("dd/MM/yyyy HH:mm") : value; }
        private static string Duration(JObject r) { double sec; return Double.TryParse(D.Field(r,"dmtSecondes"),NumberStyles.Any,CultureInfo.InvariantCulture,out sec) ? TimeSpan.FromSeconds(Math.Max(0,sec)).ToString(@"hh\:mm\:ss") : "—"; }
        private static string SourceMotif(JObject r)
        {
            foreach (JObject cell in D.Array(r["sourceValues"]).OfType<JObject>())
            { string label = D.Normalize(D.Field(cell,"label")); if ((label=="code motif" || label=="motif") && !String.IsNullOrWhiteSpace(D.Field(cell,"text"))) return D.Field(cell,"text"); }
            return First(r,"motif","etatTraitement");
        }
        private ManagerRow MapRow(JObject r)
        {
            return new ManagerRow { Id=D.Field(r,"id"), Numero=First(r,"numeroFacture"), Client=First(r,"raisonSociale"), Type=First(r,"typeFacture"), Motif=SourceMotif(r), Source=First(r,"sourceFile"), Agent=First(r,"agent"), Statut=First(r,"statut","etatTraitement"), DateAffectation=FormatDate(D.Field(r,"dateAffectation")), DateFin=FormatDate(D.Field(r,"dateFin")), Etat=First(r,"etatTraitement"), Dmt=Duration(r), Export=String.IsNullOrEmpty(D.Field(r,"dateExport")) ? "En attente" : "Exporté" };
        }
        private bool InFilter(JObject r)
        {
            string search = Get<TextBox>("SearchBox").Text.Trim(); string year = Selected(Get<ComboBox>("YearFilter")); string month = Selected(Get<ComboBox>("MonthFilter")); string status = Selected(Get<ComboBox>("StatusFilter"));
            string hay = String.Join(" ", new[]{D.Field(r,"numeroFacture"),D.Field(r,"raisonSociale"),D.Field(r,"sourceFile"),D.Field(r,"agent"),SourceMotif(r),D.Field(r,"etatTraitement")}).ToLowerInvariant();
            if (search.Length>0 && hay.IndexOf(search,StringComparison.OrdinalIgnoreCase)<0) return false;
            DateTime dt; string date=First(r,"dateFin","dateAffectation","dateImport");
            if ((year!="Toutes" || month!="Tous") && (!DateTime.TryParse(date,CultureInfo.InvariantCulture,DateTimeStyles.AssumeLocal,out dt) || (year!="Toutes" && dt.Year.ToString()!=year) || (month!="Tous" && dt.Month.ToString("00")!=month))) return false;
            bool noAgent=String.IsNullOrEmpty(D.Field(r,"agent")), done=!String.IsNullOrEmpty(D.Field(r,"dateFin"));
            if (status=="À affecter" && (!noAgent || done)) return false;
            if (status=="Affecté" && (noAgent || done || !String.IsNullOrEmpty(D.Field(r,"datePriseEnCharge")))) return false;
            if (status=="En cours" && (noAgent || done)) return false;
            if (status=="Terminé" && !done) return false;
            return true;
        }
        private List<JObject> Filtered()
        { return D.Array(state==null?null:state["traitements"]).OfType<JObject>().Where(InFilter).ToList(); }
        private void Render()
        {
            List<JObject> rows=Filtered(); queueRows.Clear(); assignedRows.Clear(); doneRows.Clear();
            foreach(JObject r in rows)
            {
                bool unassigned=String.IsNullOrEmpty(D.Field(r,"agent")) && String.IsNullOrEmpty(D.Field(r,"dateFin"));
                bool done=!String.IsNullOrEmpty(D.Field(r,"dateFin"));
                if(unassigned) queueRows.Add(MapRow(r)); else if(done) doneRows.Add(MapRow(r)); else assignedRows.Add(MapRow(r));
            }
            Get<TextBlock>("QueueCount").Text=queueRows.Count+" ligne(s)"; Get<TextBlock>("DoneCount").Text=doneRows.Count+" ligne(s)";
            int total=rows.Count, active=assignedRows.Count, doneCount=doneRows.Count;
            Get<TextBlock>("KpiTotal").Text=total.ToString("N0"); Get<TextBlock>("KpiQueue").Text=queueRows.Count.ToString("N0"); Get<TextBlock>("KpiActive").Text=active.ToString("N0"); Get<TextBlock>("KpiDone").Text=doneCount.ToString("N0");
            double[] durations=rows.Where(r=>!String.IsNullOrEmpty(D.Field(r,"dateFin"))).Select(r=>{double v;return Double.TryParse(D.Field(r,"dmtSecondes"),NumberStyles.Any,CultureInfo.InvariantCulture,out v)?v:-1;}).Where(v=>v>=0).ToArray();
            Get<TextBlock>("KpiDmt").Text=durations.Length==0?"—":TimeSpan.FromSeconds(durations.Average()).ToString(@"hh\:mm\:ss");
            DrawBars(Get<StackPanel>("AgentChart"),rows.Where(r=>!String.IsNullOrEmpty(D.Field(r,"dateFin"))).GroupBy(r=>D.Field(r,"agent")).Select(g=>new KeyValuePair<string,int>(String.IsNullOrEmpty(g.Key)?"Non affecté":g.Key,g.Count())).OrderByDescending(x=>x.Value).Take(10).ToList(),"#C8102E");
            var statusGroups=new List<KeyValuePair<string,int>> { new KeyValuePair<string,int>("À affecter",queueRows.Count),new KeyValuePair<string,int>("En cours / affectées",assignedRows.Count),new KeyValuePair<string,int>("Terminées",doneRows.Count) };
            DrawBars(Get<StackPanel>("StatusChart"),statusGroups,"#287C8E");
            Get<TextBlock>("DashboardSummary").Text="Périmètre filtré : "+total.ToString("N0")+" lignes. "+queueRows.Count+" à affecter, "+active+" affectées ou en cours et "+doneCount+" terminées. DMT calculée sur "+durations.Length+" durée(s) renseignée(s).";
            PopulateAgents(); RenderLedger();
        }
        private void DrawBars(Panel host,List<KeyValuePair<string,int>> values,string color)
        {
            host.Children.Clear(); int max=values.Count==0?1:Math.Max(1,values.Max(v=>v.Value));
            foreach(var item in values)
            {
                var row=new Grid { Margin=new Thickness(0,4,0,4) }; row.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(145)}); row.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(1,GridUnitType.Star)}); row.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(38)});
                var name=new TextBlock{Text=item.Key,VerticalAlignment=VerticalAlignment.Center,TextTrimming=TextTrimming.CharacterEllipsis,Foreground=System.Windows.Media.Brushes.SlateGray}; Grid.SetColumn(name,0);row.Children.Add(name);
                var track=new Border{Height=12,Background=(System.Windows.Media.Brush)new System.Windows.Media.BrushConverter().ConvertFromString("#EEF1F6"),CornerRadius=new CornerRadius(6),VerticalAlignment=VerticalAlignment.Center};
                var fill=new Border{Height=12,Width=Math.Max(2,220.0*item.Value/max),Background=(System.Windows.Media.Brush)new System.Windows.Media.BrushConverter().ConvertFromString(color),CornerRadius=new CornerRadius(6),HorizontalAlignment=HorizontalAlignment.Left}; track.Child=fill;Grid.SetColumn(track,1);row.Children.Add(track);
                var number=new TextBlock{Text=item.Value.ToString("N0"),TextAlignment=TextAlignment.Right,VerticalAlignment=VerticalAlignment.Center,FontWeight=FontWeights.SemiBold};Grid.SetColumn(number,2);row.Children.Add(number);host.Children.Add(row);
            }
            if(values.Count==0)host.Children.Add(new TextBlock{Text="Aucune donnée sur cette période.",Foreground=System.Windows.Media.Brushes.Gray,Margin=new Thickness(4,10,4,10)});
        }
        private void PopulateAgents()
        {
            JObject cfg=state["config"] as JObject; var names=D.Array(cfg==null?null:cfg["agents"]).Select(D.Text).Concat(D.Array(state["traitements"]).OfType<JObject>().Select(r=>D.Field(r,"agent"))).Where(x=>x.Length>0).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x=>x).ToList();
            ComboBox combo=Get<ComboBox>("AgentPicker"); string old=Selected(combo);combo.Items.Clear();foreach(string n in names)combo.Items.Add(n);if(names.Contains(old))combo.SelectedItem=old;else if(combo.Items.Count>0)combo.SelectedIndex=0;
        }
        private void RenderLedger()
        {
            importRows.Clear();duplicateRows.Clear(); if(ledger==null)return; JObject imports=ledger["imports"] as JObject;
            foreach(JObject r in D.Array(imports==null?null:imports["history"]).OfType<JObject>().OrderByDescending(r=>D.Field(r,"date")))
                importRows.Add(new ManagerRow{Date=FormatDate(D.Field(r,"date")),User=D.Field(r,"user"),Files=D.Field(r,"files"),Added=D.Field(r,"added"),Duplicates=D.Field(r,"duplicates"),Skipped=D.Field(r,"skipped")});
            foreach(JObject r in D.Array(imports==null?null:imports["duplicates"]).OfType<JObject>().Where(r=>D.Field(r,"decision")=="pending"))
            { JObject candidate=r["row"] as JObject; duplicateRows.Add(new ManagerRow{Id=D.Field(r,"id"),Numero=candidate==null?"":D.Field(candidate,"numeroFacture"),Source=candidate==null?"":D.Field(candidate,"sourceFile"),Original=D.Field(r,"originalId"),Decision=D.Field(r,"decision"),Date=FormatDate(D.Field(r,"date"))}); }
            Get<TextBlock>("ImportStatus").Text=importRows.Count+" import(s) historisés · "+duplicateRows.Count+" doublon(s) en attente";
        }
        private async Task AssignSelected()
        {
            var selected=Get<DataGrid>("QueueGrid").SelectedItems.Cast<ManagerRow>().ToList(); string agent=Selected(Get<ComboBox>("AgentPicker"));
            if(selected.Count==0){SetStatus("Sélectionnez au moins une facture.",true);return;} if(agent.Length==0){SetStatus("Choisissez un agent.",true);return;}
            try{JObject result=await Execute("assign",D.Obj("ids",new JArray(selected.Select(r=>r.Id)),"agent",agent));SetStatus(D.Field(result,"affectees")+" facture(s) affectée(s) à "+agent+".",false);await Refresh();}catch(Exception ex){SetStatus(ex.Message,true);}
        }
        private async Task AddAgent()
        {
            string name = Get<TextBox>("NewAgentBox").Text.Trim();
            if (name.Length == 0) { SetStatus("Saisissez le nom de session Windows du nouvel agent.", true); return; }
            try { await Execute("agents", D.Obj("name", name)); Get<TextBox>("NewAgentBox").Clear(); await Refresh(); SetStatus("Agent ajouté : " + name.ToUpperInvariant(), false); }
            catch (Exception ex) { SetStatus(ex.Message, true); }
        }
        private async Task Export()
        {
            try{JObject result=await Execute("export",null);SetStatus(D.Field(result,"exportees")+" facture(s) exportée(s). "+D.Array(result["erreurs"]).Count+" erreur(s).",D.Array(result["erreurs"]).Count>0);await Refresh();}catch(Exception ex){SetStatus(ex.Message,true);}
        }
        private async Task Import()
        {
            try{Get<Button>("ImportButton").IsEnabled=false;Get<TextBlock>("ImportStatus").Text="Import Excel en cours…";JObject result=await Execute("import",null);Get<TextBlock>("ImportStatus").Text="Import terminé · "+D.Field(result,"ajoutees")+" ajoutée(s) · "+D.Field(result,"doublonsIgnores")+" doublon(s) · "+D.Field(result,"dureeSecondes")+" s";await Refresh();}catch(Exception ex){SetStatus("Import impossible : "+ex.Message,true);}finally{Get<Button>("ImportButton").IsEnabled=true;}
        }
        private async Task DecideDuplicates(string decision)
        {
            var selected=Get<DataGrid>("DuplicateGrid").SelectedItems.Cast<ManagerRow>().ToList();if(selected.Count==0){SetStatus("Sélectionnez les doublons à traiter.",true);return;}
            try{JObject result=await Execute("duplicates",D.Obj("ids",new JArray(selected.Select(r=>r.Id)),"decision",decision));SetStatus(D.Field(result,"count")+" doublon(s) traité(s).",false);await Refresh();}catch(Exception ex){SetStatus(ex.Message,true);}
        }
        private async Task SaveSource()
        {
            try{await Execute("config",D.Obj("sourceDirectory",Get<TextBox>("SourceDirectoryBox").Text.Trim()));Get<TextBlock>("SettingsStatus").Text="Répertoire source enregistré.";await Refresh();}catch(Exception ex){Get<TextBlock>("SettingsStatus").Text=ex.Message;}
        }
        private void SaveDataPath()
        {
            try
            {
                string target=Get<TextBox>("DataDirectoryBox").Text.Trim();if(!Path.IsPathRooted(target)||!Directory.Exists(target)||!File.Exists(Path.Combine(target,"epithete-traitements.json")))throw new InvalidDataException("Choisissez un dossier existant contenant epithete-traitements.json.");
                var check=new FileStore(target);worker.Run(delegate{check.ReadRecords();return true;}).GetAwaiter().GetResult();
                string config=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"desktop-config.json");AtomicFile.Write(config,Encoding.UTF8.GetBytes(D.Obj("dataDirectory",Path.GetFullPath(target)).ToString(Formatting.Indented)));
                Get<TextBlock>("SettingsStatus").Text="Chemin enregistré. Fermez puis relancez le Manager pour appliquer la nouvelle base.";
            }
            catch(Exception ex){Get<TextBlock>("SettingsStatus").Text=ex.Message;}
        }
        private async Task Maintenance()
        { try{JObject result=await Execute("maintenance",null);Get<TextBlock>("SettingsStatus").Text="Reconstruction demandée. État : "+D.Field(result,"busy");}catch(Exception ex){Get<TextBlock>("SettingsStatus").Text=ex.Message;} }
    }
}
