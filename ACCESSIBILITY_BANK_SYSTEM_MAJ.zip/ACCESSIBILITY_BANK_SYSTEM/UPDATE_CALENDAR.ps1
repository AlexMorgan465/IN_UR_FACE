﻿$ErrorActionPreference='Stop'
Write-Host 'Fermez les serveurs Agent et Manager avant la mise a jour. DATA et CONFIG ne sont pas remplaces.'
$target=Read-Host 'Chemin du dossier ACCESSIBILITY_BANK_SYSTEM existant'
$target=$target.Trim().Trim('"')
if(!(Test-Path -LiteralPath (Join-Path $target 'common.ps1'))){throw 'Dossier application invalide'}
$target=(Resolve-Path -LiteralPath $target).Path
if($target.TrimEnd('\')-eq$PSScriptRoot.TrimEnd('\')){throw 'Extrayez le ZIP dans un nouveau dossier avant de lancer la mise a jour'}
$stamp=Get-Date -Format 'yyyyMMdd_HHmmss_fff'
$backup=Join-Path (Join-Path $target 'SAUVEGARDES_MAJ') $stamp
$files=@('MANAGER\index.html','MANAGER\server.ps1','AGENT\index.html','AGENT\server.ps1','CALENDRIER_V5_6.txt','CORRECTION_CALENDRIER_V5_6_1.txt','RESERVATIONS_VOLUMES_V5_7.txt','CALENDAR_TEST.ps1','TEST_CALENDRIER.bat','AGENTS_BACKGROUND_V5_8.txt','AGENT\START_AGENT.bat','AGENT\START_HIDDEN.vbs','AGENT\START_DEBUG.bat','MANAGER\START_MANAGER.bat','MANAGER\START_HIDDEN.vbs','MANAGER\START_DEBUG.bat','DESKTOP\windows.ps1')
$files+=@(Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'CALENDAR') -File|ForEach-Object{'CALENDAR\'+$_.Name})
$previous=@{};$changed=@()
function CalendarServerPatch($content,$role){
 $needle=". (Join-Path (Split-Path `$PSScriptRoot -Parent) 'common.ps1')"
 if(!$content.Contains($needle)){throw 'Serveur existant non reconnu. Aucune configuration n est remplacee.'}
 if(!$content.Contains("'DESKTOP\windows.ps1'")){$content=$content.Replace($needle,$needle+"`r`n. (Join-Path (Split-Path `$PSScriptRoot -Parent) 'DESKTOP\windows.ps1')")}
 if($content.Contains("'CALENDAR\calendar.ps1'")){return $content}
 $content=$content.Replace($needle,$needle+"`r`n. (Join-Path (Split-Path `$PSScriptRoot -Parent) 'CALENDAR\calendar.ps1')")
 $source=Get-Content -LiteralPath (Join-Path (Join-Path $PSScriptRoot $role) 'server.ps1') -Raw -Encoding UTF8
 $start=$source.IndexOf(" if(`$p-eq'/api/calendar'")
 $end=$source.IndexOf(" if(`$p-eq'/api/ping')",$start)
 $routes=$source.Substring($start,$end-$start)
 $insertion=$content.IndexOf(" if(`$p-eq'/api/ping')")
 if($insertion-lt0){throw 'Routes du serveur existant non reconnues'}
 return $content.Insert($insertion,$routes)
}
try{
 # Validate both server patches before the first change.
 $patched=@{}
 foreach($role in @('MANAGER','AGENT')){$file=$role+'\server.ps1';$old=Get-Content -LiteralPath (Join-Path $target $file) -Raw -Encoding UTF8;$patched[$file]=CalendarServerPatch $old $role}
 foreach($file in $files){$to=Join-Path $target $file;$exists=Test-Path -LiteralPath $to;$previous[$file]=$exists;if($exists){$save=Join-Path $backup $file;[IO.Directory]::CreateDirectory((Split-Path $save -Parent))|Out-Null;Copy-Item -LiteralPath $to -Destination $save -Force};$changed+=$file;[IO.Directory]::CreateDirectory((Split-Path $to -Parent))|Out-Null;if($patched.ContainsKey($file)){[IO.File]::WriteAllText($to,$patched[$file],(New-Object Text.UTF8Encoding($true)))}else{Copy-Item -LiteralPath (Join-Path $PSScriptRoot $file) -Destination $to -Force}}
 Write-Host 'Calendrier installe. Relancez Agent et Manager, puis Ctrl+F5 dans les deux interfaces.' -ForegroundColor Green
 Write-Host ('Sauvegarde : '+$backup)
}catch{
 $failure=$_.Exception.Message
 foreach($file in $changed){$to=Join-Path $target $file;if($previous[$file]){Copy-Item -LiteralPath (Join-Path $backup $file) -Destination $to -Force}else{if(Test-Path -LiteralPath $to){Remove-Item -LiteralPath $to -Force}}}
 throw ('Mise a jour interrompue, fichiers precedents restaures : '+$failure)
}
