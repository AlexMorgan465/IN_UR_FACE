﻿$ErrorActionPreference='Stop'
$testRoot=Join-Path ([IO.Path]::GetTempPath()) ('Calendar-Test-'+[guid]::NewGuid().ToString('N'))
$RootPath=Join-Path $testRoot 'DP'
$DataPath=Join-Path $testRoot 'DATA'
$Role='MANAGER'
function AssertCalendar($condition,$message){if(!$condition){throw $message}}
try{
 [IO.Directory]::CreateDirectory($RootPath)|Out-Null
 . (Join-Path $PSScriptRoot 'common.ps1')
 . (Join-Path $PSScriptRoot 'CALENDAR\calendar.ps1')
 $initial=GetCalendar
 AssertCalendar ($initial.revision-eq0-and$null-eq$initial.published) 'Calendrier initial invalide'
 $null=WithStore {param($db);$db.documents=@([pscustomobject]@{id='d1';name='Test.pdf';entity='ACM';branch='ASS-BIENS';status='A TRAITER';present=$true;deposit='2026-10-01';priority=$true;complex=$false;unitPrice=9});return @{ok=$true}} $true
 $cfg=[pscustomobject]@{rulesVersion=4;groupRates=@();friday=[pscustomobject]@{startTime='08:00';endTime='17:00';breaks=@([pscustomobject]@{start='10:15';end='10:35'},[pscustomobject]@{start='12:30';end='13:30'},[pscustomobject]@{start='15:30';end='15:50'})};start='2026-10-12';end='2026-10-16';startTime='08:00';endTime='18:00';workdays=@(1,2,3,4,5);breaks=@([pscustomobject]@{start='10:15';end='10:30'},[pscustomobject]@{start='12:30';end='13:30'},[pscustomobject]@{start='15:30';end='16:00'});agents=@([pscustomobject]@{id='a1';name='Agent test';session=(Agent)});rates=[pscustomobject]@{ACM=[pscustomobject]@{price=9;complexFactor=1;due=''}};exceptions=@();overrides=@()}
 $slots=@(CalendarSlots $cfg 'a1' '2026-10-12');$capacity=($slots|ForEach-Object{$_.end-$_.start}|Measure-Object -Sum).Sum
 AssertCalendar ($capacity-eq495) 'Capacite differente de 8 h 15'
 $friday=(@(CalendarSlots $cfg 'a1' '2026-10-16')|ForEach-Object{$_.end-$_.start}|Measure-Object -Sum).Sum
 AssertCalendar ($friday-eq440) 'Vendredi different de 7 h 20'
 AssertCalendar (@(CalendarSlots $cfg 'a1' '2026-10-17').Count-eq0) 'Weekend planifiable par defaut'
 $saved=UpdateCalendar ([pscustomobject]@{action='draft';revision=0;config=$cfg})
 AssertCalendar ($saved.revision-eq1-and$null-eq$saved.published) 'Brouillon publie par erreur'
 $state=GetCalendar
 $key=CalendarGroupKey 'ACM' 'ASS-BIENS'
 $plan=[pscustomobject]@{mode='agent-volumes';config=$cfg;groups=@([pscustomobject]@{key=$key;entity='ACM';branch='ASS-BIENS';count=1;planned=1;plannedComplex=0;unplanned=0;minutes=540;start='2026-10-12T08:00';end='2026-10-13T08:45';late=0});rows=@([pscustomobject]@{key=$key;entity='ACM';branch='ASS-BIENS';date='2026-10-12';active=1;started=1;completed=0;minutes=495},[pscustomobject]@{key=$key;entity='ACM';branch='ASS-BIENS';date='2026-10-13';active=1;started=0;completed=1;minutes=45})}
 $plan|Add-Member -NotePropertyName agentRows -NotePropertyValue @($plan.rows|ForEach-Object{[pscustomobject]@{agent='a1';date=$_.date;key=$_.key;entity=$_.entity;branch=$_.branch;active=$_.active;started=$_.started;completed=$_.completed;minutes=$_.minutes;complexActive=0;complexStarted=0;complexCompleted=0;shortOnly=$false}})
 $body=[pscustomobject]@{action='publish';revision=1;stockToken=$state.stockToken;plan=$plan}
 $ok=UpdateCalendar $body
 AssertCalendar ($ok.revision-eq2-and$ok.published.plannedCount-eq1-and$ok.published.mode-eq'agent-volumes') 'Publication invalide'
 $refused=$false;try{$null=UpdateCalendar $body}catch{$refused=$true};AssertCalendar $refused 'Revision obsolete acceptee'
 $unknown=PersonalCalendar $ok.published 'SESSION-INCONNUE';AssertCalendar ($null-eq$unknown) 'Planning expose a une session inconnue'
 $Role='AGENT';$view=GetCalendar;AssertCalendar ($null-ne$view.published-and!$view.ContainsKey('draft')) 'Brouillon visible aux agents';AssertCalendar ($view.published.config.agents.Count-eq1-and$view.published.personal) 'Filtrage personnel absent'
 $refused=$false;try{$null=UpdateCalendar ([pscustomobject]@{action='draft';revision=2;config=$cfg})}catch{$refused=$true};AssertCalendar $refused 'Agent autorise a publier'
 $Role='MANAGER';$body.revision=2;$body.plan.rows[0].minutes=600
 $refused=$false;try{$null=UpdateCalendar $body}catch{$refused=$true};AssertCalendar $refused 'Charge journaliere invalide acceptee'
 $body.plan.rows[0].minutes=495;$body.plan.rows=@($body.plan.rows[0],$body.plan.rows[0],$body.plan.rows[1]);$refused=$false;try{$null=UpdateCalendar $body}catch{$refused=$true};AssertCalendar $refused 'Double ligne journaliere acceptee'
 $body.plan.rows=@($body.plan.rows[0],$body.plan.rows[2]);$body.stockToken='obsolete';$refused=$false;try{$null=UpdateCalendar $body}catch{$refused=$true};AssertCalendar $refused 'Stock obsolete accepte'
 $pub=GetCalendar;AssertCalendar ($pub.published.PSObject.Properties.Name-notcontains'assignments') 'Affectations nominatives publiees'
 $catalog=Documents;AssertCalendar ($catalog.documents[0].status-eq'A TRAITER') 'Document deplace par le calendrier'
 AssertCalendar (@(Get-ChildItem -LiteralPath $RootPath -Recurse -Force).Count-eq0) 'Fichier ajoute au DP'
 Write-Host 'OK : capacite, pauses, vendredi, volumes sans noms de fichiers, brouillon prive, publication partagee, controles de role/revision/stock, doublons refuses, DP intact.' -ForegroundColor Green
}finally{if(Test-Path -LiteralPath $testRoot){Remove-Item -LiteralPath $testRoot -Recurse -Force}}
