﻿# Reservation metadata only: all writes are in DATA, never in the document DP.
$CalendarFile=Join-Path $DataPath 'calendar.json'
$CalendarBackup=Join-Path $DataPath 'calendar.backup.json'
$CalendarLock=Join-Path $DataPath 'calendar.lock'
function ReadCalendarFile($path){
 $value=Get-Content -LiteralPath $path -Raw -Encoding UTF8|ConvertFrom-Json -ErrorAction Stop
 if($null-eq$value -or $value.PSObject.Properties.Name-notcontains'revision' -or $value.PSObject.Properties.Name-notcontains'published'){throw 'Format de calendrier invalide'}
 return $value
}
function WithCalendar($action,[bool]$save=$false){
 $lock=$null;$limit=(Get-Date).AddSeconds(15)
 while(!$lock){try{$lock=[IO.File]::Open($CalendarLock,'OpenOrCreate','ReadWrite','None')}catch{if((Get-Date)-gt$limit){throw 'Calendrier occupe, reessayez'};Start-Sleep -Milliseconds 80}}
 try{
  $value=$null
  if([IO.File]::Exists($CalendarFile)){try{$value=ReadCalendarFile $CalendarFile}catch{if(![IO.File]::Exists($CalendarBackup)){throw 'Calendrier illisible, aucune reinitialisation effectuee'};$value=ReadCalendarFile $CalendarBackup}}
  elseif([IO.File]::Exists($CalendarBackup)){$value=ReadCalendarFile $CalendarBackup}
  if(!$value){$value=[pscustomobject]@{revision=0;draft=$null;published=$null}}
  $answer=& $action $value
  if($save){
   $tmp=Join-Path $DataPath ('calendar.'+[guid]::NewGuid().ToString('N')+'.tmp')
   try{
    [IO.File]::WriteAllText($tmp,($value|ConvertTo-Json -Depth 30 -Compress),(New-Object Text.UTF8Encoding($false)))
    if([IO.File]::Exists($CalendarFile)){
     # Never replace a good backup with a corrupt primary file.
     $validPrimary=$false;try{$null=ReadCalendarFile $CalendarFile;$validPrimary=$true}catch{}
     if($validPrimary){if([IO.File]::Exists($CalendarBackup)){[IO.File]::Delete($CalendarBackup)};[IO.File]::Move($CalendarFile,$CalendarBackup)}else{[IO.File]::Delete($CalendarFile)}
    }
    try{[IO.File]::Move($tmp,$CalendarFile)}catch{if(![IO.File]::Exists($CalendarFile)-and[IO.File]::Exists($CalendarBackup)){[IO.File]::Copy($CalendarBackup,$CalendarFile,$false)};throw}
   }finally{if([IO.File]::Exists($tmp)){[IO.File]::Delete($tmp)}}
  }
  return $answer
 }finally{$lock.Dispose()}
}
function CalendarSession($name){return ([string]$name).Trim().Split([char[]]@('\','/'))[-1].ToUpperInvariant()}
function CalendarMinute($v){
 if([string]$v-notmatch'^([0-9]{2}):([0-9]{2})$'){throw 'Horaire de calendrier invalide'}
 $h=[int]$Matches[1];$m=[int]$Matches[2];if($h-gt23-or$m-gt59){throw 'Horaire invalide'};return $h*60+$m
}
function CalendarDate($v){
 if([string]$v-notmatch'^\d{4}-\d{2}-\d{2}$'){throw 'Date de calendrier invalide'}
 return [datetime]::ParseExact([string]$v,'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture)
}
function CalendarNumber($v,$min,$max){
 $n=0.0;if($null-eq$v-or![double]::TryParse([string]$v,[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture,[ref]$n)-or[double]::IsNaN($n)-or[double]::IsInfinity($n)-or$n-lt$min-or$n-gt$max){throw 'Valeur numerique de calendrier invalide'};return $n
}
function CalendarDaySchedule($cfg,$date){if((CalendarDate $date).DayOfWeek-eq[DayOfWeek]::Friday-and$cfg.friday){return $cfg.friday};return $cfg}
function ValidateCalendarSchedule($schedule){
 $s=CalendarMinute $schedule.startTime;$e=CalendarMinute $schedule.endTime;if($e-le$s){throw 'Horaires invalides'}
 $previous=$s;foreach($b in @($schedule.breaks|Sort-Object start)){$bs=CalendarMinute $b.start;$be=CalendarMinute $b.end;if($bs-lt$previous-or$be-le$bs-or$be-gt$e){throw 'Pauses en dehors des horaires ou en chevauchement'};$previous=$be}
}
function ValidateCalendarConfig($cfg,[bool]$publishing=$false){
 if(!$cfg){throw 'Configuration du calendrier manquante'}
 if($cfg.rulesVersion-ne4-or!$cfg.friday){throw 'Recalculez avec la nouvelle regle prix unitaire = heures (Ctrl+F5)'}
 $start=CalendarDate $cfg.start;$end=CalendarDate $cfg.end
 if($end-lt$start-or($end-$start).TotalDays-gt365){throw 'Periode de calendrier invalide (366 jours maximum)'}
 $agents=@($cfg.agents);if($agents.Count-lt1-or$agents.Count-gt100){throw 'Effectif invalide (1 a 100 agents)'}
 $ids=@{};$sessions=@{}
 foreach($a in $agents){if(!$a.id-or$ids.ContainsKey([string]$a.id)-or![string]$a.name){throw 'Identifiant agent invalide'};$ids[[string]$a.id]=$true;$session=CalendarSession $a.session;if($publishing-and!$session){throw 'Renseignez la session Windows de chaque agent'};if($session){if($sessions.ContainsKey($session)){throw 'Session Windows en double'};$sessions[$session]=$true}}
 if(@($cfg.workdays).Count-lt1){throw 'Jours travailles manquants'};foreach($d in $cfg.workdays){$n=CalendarNumber $d 0 6;if($n-ne[Math]::Floor($n)){throw 'Jour travaille invalide'}}
 ValidateCalendarSchedule $cfg
 ValidateCalendarSchedule $cfg.friday
 if(!$cfg.rates){throw 'Durees et tarifs manquants'}
 foreach($prop in $cfg.rates.PSObject.Properties){$r=$prop.Value;$null=CalendarNumber $r.price 0.001 1000;$null=CalendarNumber $r.complexFactor 1 10;if($r.due){$null=CalendarDate $r.due}}
 foreach($x in @($cfg.exceptions)){$date=CalendarDate $x.date;if($date-lt$start-or$date-gt$end-or($x.agent-ne'*'-and!$ids.ContainsKey([string]$x.agent))-or(CalendarMinute $x.end)-le(CalendarMinute $x.start)){throw 'Exception de calendrier invalide'}}
 if(@($cfg.overrides).Count-gt0){throw 'Les exceptions par document ne sont plus utilisees. Rechargez le calendrier.'}
 $keys=@{};foreach($x in @($cfg.groupRates)){$key=CalendarGroupKey $x.entity $x.branch;if(!$x.entity-or$keys.ContainsKey($key)){throw 'Exception de categorie en double'};$keys[$key]=$true;if($null-ne$x.price-and[string]$x.price-ne''){$null=CalendarNumber $x.price 0.001 1000};if($null-ne$x.complexFactor-and[string]$x.complexFactor-ne''){$null=CalendarNumber $x.complexFactor 1 10};if($x.due){$null=CalendarDate $x.due}}

}
function CalendarSlots($cfg,$agent,$date){
 $d=CalendarDate $date;if(@($cfg.workdays)-notcontains[int]$d.DayOfWeek){return @()}
 $timetable=CalendarDaySchedule $cfg $date
 $slots=@([pscustomobject]@{start=(CalendarMinute $timetable.startTime);end=(CalendarMinute $timetable.endTime)})
 $blocks=@($timetable.breaks)+@($cfg.exceptions|Where-Object{$_.date-eq$date-and($_.agent-eq'*'-or$_.agent-eq$agent)})
 foreach($b in $blocks){$s=CalendarMinute $b.start;$e=CalendarMinute $b.end;$next=@();foreach($t in $slots){if($s-ge$t.end-or$e-le$t.start){$next+=$t}else{if($s-gt$t.start){$next+=[pscustomobject]@{start=$t.start;end=[Math]::Min($s,$t.end)}};if($e-lt$t.end){$next+=[pscustomobject]@{start=[Math]::Max($e,$t.start);end=$t.end}}}};$slots=$next}
 return $slots
}
function CalendarStock($db){return @($db.documents|Where-Object{$_.present-and$_.status-eq'A TRAITER'})}
function CalendarGroupKey($entity,$branch){return ([string]$entity).Length.ToString()+':'+[string]$entity+([string]$branch).Length.ToString()+':'+[string]$branch}
function CalendarGroups($docs,$cfg){
 $map=@{};foreach($d in $docs){$key=CalendarGroupKey $d.entity $d.branch;if(!$map.ContainsKey($key)){$r=$null;if($cfg){$r=$cfg.rates.PSObject.Properties[[string]$d.entity].Value};$price=if($r){[double]$r.price}else{9};$factor=if($r){[double]$r.complexFactor}else{1};$due=if($r){[string]$r.due}else{''};$x=@($cfg.groupRates|Where-Object{$_.entity-eq$d.entity-and[string]$_.branch-eq[string]$d.branch})|Select-Object -First 1;if($x){if($null-ne$x.price-and[string]$x.price-ne''){$price=[double]$x.price};if($null-ne$x.complexFactor-and[string]$x.complexFactor-ne''){$factor=[double]$x.complexFactor};if($x.due){$due=[string]$x.due}};$map[$key]=[pscustomobject]@{key=$key;entity=$d.entity;branch=[string]$d.branch;count=0;complexCount=0;priority=$false;price=$price;complexFactor=$factor;due=$due}}
 $map[$key].count++;if($d.complex){$map[$key].complexCount++};if($d.priority){$map[$key].priority=$true}}
 return @($map.Values|Sort-Object key)
}
function CalendarToken($docs){
 $rows=@(CalendarGroups $docs $null|ForEach-Object{[ordered]@{entity=$_.entity;branch=$_.branch;count=$_.count;complex=$_.complexCount;priority=$_.priority}})
 $sha=[Security.Cryptography.SHA256]::Create();try{return [BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $rows -Depth 8 -Compress)))).Replace('-','')}finally{$sha.Dispose()}
}
function GetCalendar(){
 WithStore {param($db)
  WithCalendar {param($calendar)
   $published=$calendar.published
   if($published-and$published.mode-ne'agent-volumes'){$published=$null}
   if($published-and$Role-eq'AGENT'){$published=PersonalCalendar $published (Agent)}
   $result=@{revision=$calendar.revision;published=$published;agent=(Agent)}
   if($Role-eq'MANAGER'){$result.draft=$calendar.draft;$stock=@(CalendarStock $db);$result.documents=@(CalendarGroups $stock $null|ForEach-Object{@{entity=$_.entity;branch=$_.branch;count=$_.count;complexCount=$_.complexCount;priority=$_.priority;present=$true;status='A TRAITER'}});$result.stockToken=CalendarToken $stock;$result.knownAgents=@($db.history|ForEach-Object{$_.agent}|Where-Object{$_}|Sort-Object -Unique)}
   return $result
  } $false
 } $false
}
function ValidateCalendarPlan($plan,$docs){
 $cfg=$plan.config;ValidateCalendarConfig $cfg $true
 if($plan.mode-ne'agent-volumes'){throw 'Recalculez les reservations par volumes'}
 $expected=@{};foreach($g in @(CalendarGroups $docs $cfg)){$expected[$g.key]=$g}
 $seen=@{};$booked=@{};$groups=@();$rows=@();$planned=0;$unplanned=0;$total=0
 foreach($g in @($plan.groups)){
  $key=CalendarGroupKey $g.entity $g.branch;if(!$expected.ContainsKey($key)-or$seen.ContainsKey($key)){throw 'Categorie inconnue ou en double'};$seen[$key]=$true;$e=$expected[$key]
  $pc=CalendarNumber $g.planned 0 $e.count;$uc=CalendarNumber $g.unplanned 0 $e.count;$cc=CalendarNumber $g.plannedComplex 0 $e.complexCount
  if($pc-ne[Math]::Floor($pc)-or$uc-ne[Math]::Floor($uc)-or$cc-ne[Math]::Floor($cc)-or$pc+$uc-ne$e.count-or$cc-gt$pc-or$pc-$cc-gt$e.count-$e.complexCount){throw 'Volume planifie incoherent'}
  $duration=[Math]::Ceiling($e.price*60)*($pc-$cc)+[Math]::Ceiling($e.price*60*$e.complexFactor)*$cc
  $rs=@($plan.rows|Where-Object{$_.key-eq$key}|Sort-Object date);$starts=0;$ends=0;$mins=0;$carry=0;$dates=@{}
  foreach($r in $rs){$d=CalendarDate $r.date;if($d-lt(CalendarDate $cfg.start)-or$d-gt(CalendarDate $cfg.end)-or$dates.ContainsKey([string]$r.date)){throw 'Date journaliere invalide'};$dates[[string]$r.date]=$true
   $active=CalendarNumber $r.active 0 $pc;$st=CalendarNumber $r.started 0 $pc;$fin=CalendarNumber $r.completed 0 $pc;$m=CalendarNumber $r.minutes 1 100000000
   foreach($n in @($active,$st,$fin,$m)){if($n-ne[Math]::Floor($n)){throw 'Nombre journalier non entier'}}
   if($active-ne$carry+$st-or$fin-gt$active){throw 'Reprises et volumes journaliers incoherents'};$carry=$active-$fin
   $starts+=$st;$ends+=$fin;$mins+=$m;if(!$booked.ContainsKey([string]$r.date)){$booked[[string]$r.date]=0};$booked[[string]$r.date]+=$m
   $rows+=[pscustomobject]@{date=$r.date;key=$key;entity=$e.entity;branch=$e.branch;active=[int]$active;started=[int]$st;completed=[int]$fin;minutes=[int]$m}
  }
  if($starts-ne$pc-or$ends-ne$pc-or$carry-ne0-or$mins-ne$duration){throw 'Total des volumes ou heures incoherent'}
  $groups+=[pscustomobject]@{key=$key;entity=$e.entity;branch=$e.branch;count=$e.count;complexCount=$e.complexCount;priority=$e.priority;price=$e.price;complexFactor=$e.complexFactor;due=$e.due;planned=[int]$pc;plannedComplex=[int]$cc;unplanned=[int]$uc;minutes=[int]$duration;start=$g.start;end=$g.end;late=$g.late}
  $planned+=$pc;$unplanned+=$uc;$total+=$duration
 }
 if($seen.Count-ne$expected.Count-or$rows.Count-ne@($plan.rows).Count){throw 'Stock incomplet ou ligne journaliere inconnue'}
 foreach($date in $booked.Keys){$capacity=0;foreach($a in $cfg.agents){foreach($slot in @(CalendarSlots $cfg $a.id $date)){$capacity+=$slot.end-$slot.start}};if($booked[$date]-gt$capacity){throw 'Capacite journaliere depassee'}}
 $personal=@(ValidatePersonalCalendar $plan $groups)
 return [pscustomobject]@{mode='agent-volumes';agentRows=$personal;config=$cfg;groups=@($groups);rows=@($rows|Sort-Object date,key);sourceCount=$docs.Count;plannedCount=[int]$planned;unplannedCount=[int]$unplanned;plannedMinutes=[int]$total;generated=(Get-Date).ToString('o')}
}
function ValidatePersonalCalendar($plan,$groups){
 $agents=@{};foreach($a in $plan.config.agents){$agents[[string]$a.id]=$a}
 $categories=@{};foreach($g in $groups){$categories[$g.key]=$g}
 $seen=@{};$daily=@{};$totals=@{};$workerGroups=@{};$safe=@()
 foreach($r in @($plan.agentRows|Sort-Object agent,key,date)){
  $key=[string]$r.key;$id=[string]$r.agent;$date=[string]$r.date;$pk=$id+'|'+$date+'|'+$key
  if(!$agents.ContainsKey($id)-or!$categories.ContainsKey($key)-or$seen.ContainsKey($pk)){throw 'Ligne agent inconnue ou dupliquee'};$seen[$pk]=$true;$g=$categories[$key]
  $dt=CalendarDate $date;if($dt-lt(CalendarDate $plan.config.start)-or$dt-gt(CalendarDate $plan.config.end)){throw 'Date agent hors periode'}
  $numbers=@{};foreach($field in @('active','started','completed','minutes','complexActive','complexStarted','complexCompleted')){$n=CalendarNumber $r.$field 0 100000000;if($n-ne[Math]::Floor($n)){throw 'Volume agent non entier'};$numbers[$field]=[int]$n}
  if($numbers.minutes-lt1-or$numbers.active-lt1-or$numbers.complexActive-gt$numbers.active-or$numbers.complexStarted-gt$numbers.started-or$numbers.complexCompleted-gt$numbers.completed){throw 'Volume agent invalide'}
  $wg=$id+'|'+$key;if(!$workerGroups.ContainsKey($wg)){$workerGroups[$wg]=@{carry=0;complexCarry=0;starts=0;ends=0;complexStarts=0;complexEnds=0;minutes=0;category=$g}}
  $w=$workerGroups[$wg];if($numbers.active-ne$w.carry+$numbers.started-or$numbers.completed-gt$numbers.active-or$numbers.complexActive-ne$w.complexCarry+$numbers.complexStarted-or$numbers.complexCompleted-gt$numbers.complexActive){throw 'Reprise agent incoherente'}
  $w.carry=$numbers.active-$numbers.completed;$w.complexCarry=$numbers.complexActive-$numbers.complexCompleted;$w.starts+=$numbers.started;$w.ends+=$numbers.completed;$w.complexStarts+=$numbers.complexStarted;$w.complexEnds+=$numbers.complexCompleted;$w.minutes+=$numbers.minutes
  $dk=$id+'|'+$date;if(!$daily.ContainsKey($dk)){$daily[$dk]=@{agent=$id;date=$date;minutes=0;active=0;completed=0;entities=@{};allShort=$true}}
  $d=$daily[$dk];$d.minutes+=$numbers.minutes;$d.active+=$numbers.active;$d.completed+=$numbers.completed;$d.entities[[string]$g.entity]=$true
  $short=([Math]::Ceiling($g.price*60)-le240-and($numbers.complexActive-eq0-or[Math]::Ceiling($g.price*60*$g.complexFactor)-le240));if(!$short){$d.allShort=$false}
  $tk=$date+'|'+$key;if(!$totals.ContainsKey($tk)){$totals[$tk]=@{active=0;started=0;completed=0;minutes=0}}
  foreach($field in @('active','started','completed','minutes')){$totals[$tk][$field]+=$numbers[$field]}
  $safe+=[pscustomobject]@{agent=$id;date=$date;key=$key;entity=$g.entity;branch=$g.branch;active=$numbers.active;started=$numbers.started;completed=$numbers.completed;minutes=$numbers.minutes;complexActive=$numbers.complexActive;complexStarted=$numbers.complexStarted;complexCompleted=$numbers.complexCompleted;shortOnly=$short}
 }
 foreach($w in $workerGroups.Values){$g=$w.category;$expected=[Math]::Ceiling($g.price*60)*($w.starts-$w.complexStarts)+[Math]::Ceiling($g.price*60*$g.complexFactor)*$w.complexStarts;if($w.carry-ne0-or$w.complexCarry-ne0-or$w.starts-ne$w.ends-or$w.complexStarts-ne$w.complexEnds-or$w.minutes-ne$expected){throw 'Charge personnelle incoherente'}}
 foreach($d in $daily.Values){$capacity=0;foreach($slot in @(CalendarSlots $plan.config $d.agent $d.date)){$capacity+=$slot.end-$slot.start};if($d.minutes-gt$capacity-or$d.entities.Count-gt2-or($d.entities.Count-eq2-and(!$d.allShort-or$d.active-ne2-or$d.completed-ne2))){throw 'Capacite agent ou regle une entite par jour non respectee'}}
 if($totals.Count-ne@($plan.rows).Count){throw 'Volumes personnels incomplets'}
 foreach($r in $plan.rows){$tk=[string]$r.date+'|'+[string]$r.key;if(!$totals.ContainsKey($tk)){throw 'Volume personnel manquant'};foreach($field in @('active','started','completed','minutes')){if($totals[$tk][$field]-ne$r.$field){throw 'Total agent different du total collectif'}}}
 foreach($g in $groups){$complex=0;foreach($r in $safe){if($r.key-eq$g.key){$complex+=$r.complexStarted}};if($complex-ne$g.plannedComplex){throw 'Nombre de complexes personnels incoherent'}}
 return $safe
}
function PersonalCalendar($plan,$session){
 $who=@($plan.config.agents|Where-Object{(CalendarSession $_.session)-eq(CalendarSession $session)})|Select-Object -First 1
 if(!$who){return $null}
 $cfg=$plan.config|ConvertTo-Json -Depth 30|ConvertFrom-Json;$cfg.agents=@($who);$cfg.exceptions=@($cfg.exceptions|Where-Object{$_.agent-eq'*'-or$_.agent-eq$who.id})
 $rows=@($plan.agentRows|Where-Object{$_.agent-eq$who.id});$groups=@();$minutes=0;$count=0
 foreach($g in $plan.groups){$rs=@($rows|Where-Object{$_.key-eq$g.key});if(!$rs.Count){continue};$n=0;$m=0;foreach($r in $rs){$n+=$r.started;$m+=$r.minutes};$count+=$n;$minutes+=$m;$groups+=[pscustomobject]@{key=$g.key;entity=$g.entity;branch=$g.branch;count=$n;planned=$n;unplanned=0;minutes=$m}}
 return [pscustomobject]@{mode='agent-volumes';personal=$true;config=$cfg;rows=$rows;agentRows=$rows;groups=$groups;plannedCount=$count;sourceCount=$count;unplannedCount=0;plannedMinutes=$minutes;publishedAt=$plan.publishedAt;publishedBy=$plan.publishedBy}
}
function UpdateCalendar($body){
 if($Role-ne'MANAGER'){throw 'Validation reservee au manager'}
 WithStore {param($db)
  WithCalendar {param($calendar)
   if($null-eq$body.revision-or[int]$body.revision-ne[int]$calendar.revision){throw 'Le calendrier a ete modifie par un autre manager. Rechargez le calendrier.'}
   if($body.action-eq'draft'){ValidateCalendarConfig $body.config;$calendar.draft=$body.config}
   elseif($body.action-eq'publish'){
    $stock=@(CalendarStock $db);if([string]$body.stockToken-cne(CalendarToken $stock)){throw 'Le stock A TRAITER a change. Actualisez le stock du calendrier et recalculez avant validation.'}
    $approved=ValidateCalendarPlan $body.plan $stock
    $approved|Add-Member -NotePropertyName publishedAt -NotePropertyValue (Get-Date).ToString('o') -Force
    $approved|Add-Member -NotePropertyName publishedBy -NotePropertyValue (Agent) -Force
    $calendar.published=$approved;$calendar.draft=$approved.config
   }else{throw 'Action calendrier inconnue'}
   $calendar.revision=[int]$calendar.revision+1
   return @{ok=$true;revision=$calendar.revision;published=$calendar.published}
  } $true
 } $false
}
