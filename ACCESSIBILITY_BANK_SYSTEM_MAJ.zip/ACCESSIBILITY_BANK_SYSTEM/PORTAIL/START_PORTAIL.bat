@echo off
cscript //nologo "%~dp0START_HIDDEN.vbs"
