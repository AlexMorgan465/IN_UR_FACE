﻿$ErrorActionPreference='Stop'
$testRoot=Join-Path ([IO.Path]::GetTempPath()) ('Portail-Test-'+[guid]::NewGuid().ToString('N'))
$RootPath=Join-Path $testRoot 'DP';$DataPath=Join-Path $testRoot 'DATA';$Role='PORTAIL'
try{
 [IO.Directory]::CreateDirectory($RootPath)|Out-Null
 . (Join-Path (Split-Path $PSScriptRoot -Parent) 'common.ps1')
 . (Join-Path $PSScriptRoot 'portal.ps1')
 $script:PortalIdentity='DOMAINE\HAMDANMO';$cfg=PortalSettings
 $cfg.sessions=@([pscustomobject]@{session='METIER01';role='coordination';entities=@()},[pscustomobject]@{session='DOMAINE\METIER01';role='metier';entities=@('ACM')},[pscustomobject]@{session='DOMAINE\COORD01';role='coordination';entities=@()})
 $cfg.entities[0].sectionCode='SECTION-ACM';$cfg.entities[0].unitPrice=12.5
 $null=PortalSaveSettings $cfg
 $script:PortalIdentity='DOMAINE\METIER01'
 if((PortalSnapshot).role-ne'metier'){throw 'Affectation explicite du domaine ignoree'}
 $refused=$false;try{$null=PortalSettings}catch{$refused=$true};if(!$refused){throw 'Parametres accessibles au metier'}
 $dir=BranchPath 'ACM' 'A TRAITER' 'ASS-BIENS';[IO.Directory]::CreateDirectory($dir)|Out-Null
 $content=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes('%PDF-1.7 Fichier de test uniquement'))
 $body=[pscustomobject]@{entity='ACM';branch='ASS-BIENS';name='Test portail.pdf';originalName='Test portail.pdf';content=$content;urgent=$true;urgentReason='Test';comment='Depot test';sourceDocumentId=''}
 $result=PortalDeposit $body;$snapshot=PortalSnapshot
 if($snapshot.documents.Count-ne 1 -or !$snapshot.documents[0].priority -or $snapshot.documents[0].unitPrice-ne 12.5){throw 'Depot, prix ou priorite non synchronise'}
 if($snapshot.documents[0].portal.depositor-ne'DOMAINE\METIER01'){throw 'Session de depot non journalisee'}
 $refused=$false;try{$null=PortalDeposit $body}catch{$refused=$true};if(!$refused){throw 'Ecrasement de fichier accepte'}
 $bad=[pscustomobject]@{entity='DIRCO';branch='CM';name='Refuse.pdf';originalName='Refuse.pdf';content=$content;urgent=$false};$refused=$false;try{$null=PortalDeposit $bad}catch{$refused=$true};if(!$refused){throw 'Depot dans entite interdite accepte'}
 # Simulate an agent's update under the same shared lock.
 $null=WithStore {param($db);$d=$db.documents[0];$d.status='NON CONFORME';$d.ncComment='Retour de test';$db.history=@($db.history)+@([pscustomobject]@{id=[guid]::NewGuid().ToString();documentId=$d.id;timestamp=(Get-Date).ToString('o');entity=$d.entity;branch=$d.branch;name=$d.name;from='EN COURS';to='NON CONFORME';agent='AGENT01';comment='Retour de test'})} $true
 $null=PortalMessage ([pscustomobject]@{id=$result.documentId;message='Correction preparee'})
 $body.name='Test portail corrige.pdf';$body.sourceDocumentId=$result.documentId;$body.urgent=$false
 $null=PortalDeposit $body
 $snapshot=PortalSnapshot;if($snapshot.documents.Count-ne 2 -or @($snapshot.documents|Where-Object{$_.status-eq'NON CONFORME'}).Count-ne 1){throw 'Dossier NC ou nouveau depot perdu'}
 if(@($snapshot.documents|Where-Object{$_.portal.sourceDocumentId-eq$result.documentId}).Count-ne 1){throw 'Lien de correction perdu'}
 $script:PortalIdentity='DOMAINE\COORD01';$snapshot=PortalSnapshot;if($snapshot.entities.Count-ne$Schema.Count){throw 'Coordination sans volume global'}
 $script:PortalIdentity='DOMAINE\INCONNU';$snapshot=PortalSnapshot;if($snapshot.documents.Count-ne 0 -or $snapshot.entities.Count-ne 0){throw 'Session inconnue exposee'}
 $script:PortalIdentity='DOMAINE\OUBRAHMO';if(!(PortalAdmin)){throw 'OUBRAHMO non administrateur'}
 if(@(Get-ChildItem -LiteralPath $RootPath -Recurse -File).Count-ne 2){throw 'Fichier de suivi cree dans DP test'}
 Write-Host 'OK : droits par session, parametres reserves, depot journalise, tarifs, urgence, absence d ecrasement, NC conserve, correction liee et coordination globale.' -ForegroundColor Green
}finally{if(Test-Path -LiteralPath $testRoot){Remove-Item -LiteralPath $testRoot -Recurse -Force}}
