@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0TEST_PORTAIL.ps1"
pause
