@echo off
powershell.exe -STA -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1"
pause
