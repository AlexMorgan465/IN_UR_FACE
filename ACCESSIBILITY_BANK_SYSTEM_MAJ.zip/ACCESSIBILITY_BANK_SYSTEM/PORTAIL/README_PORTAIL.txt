PORTAIL MÉTIERS & COORDINATION — VERSION 1

INSTALLATION : AUCUN REMPLACEMENT DE MANAGER / AGENT
1. Extraire le ZIP.
2. Copier uniquement le dossier PORTAIL dans l'installation existante
   ACCESSIBILITY_BANK_SYSTEM, à côté de common.ps1 et CONFIG.ps1.
3. Le portail utilise les mêmes RootPath et DataPath que l'application.
   DATA doit être le même dossier partagé pour tous les serveurs et doit
   rester hors du DP documentaire. Ne pas créer un catalogue séparé.
4. Sous HAMDANMO ou OUBRAHMO, lancer PORTAIL\START_PORTAIL.bat.
5. Le navigateur ouvre http://localhost:8793/ par défaut.
6. Dans Paramètres : saisir les codes section, les prix par défaut et
   l'unité de facturation, puis affecter les sessions Windows :
   - Métier : une ou plusieurs entités autorisées ;
   - Coordination : vue globale de toutes les entités ;
   - HAMDANMO et OUBRAHMO : administration automatique.
7. Sauvegarder. Une session non affectée ne reçoit aucun document.

PARAMÈTRES ET IDENTITÉ
Les deux noms administrateurs sont HAMDANMO et OUBRAHMO, sans distinction
majuscules/minuscules. Les paramètres sont masqués pour les autres profils
et les routes GET/POST sont également refusées côté serveur.
L'identité est celle de l'authentification Windows HTTP du navigateur,
pas un nom reçu dans le formulaire. Utiliser Edge/Chrome avec le compte
Windows professionnel. Si une fenêtre d'authentification apparaît, utiliser
ce compte Windows, sans créer de mot de passe propre au portail.
Pour les affectations, préférer DOMAINE\SESSION. Un nom court est également
accepté si votre environnement l'utilise sans ambiguïté.
La version utilise l'authentification intégrée Windows (NTLM/Negotiate).

MODE INTRANET : UN SERVEUR, PLUSIEURS MÉTIERS
Le serveur peut tourner en continu sur un poste de coordination ayant les
droits sur le DP et DATA. Dans le CONFIG.ps1 existant, ajouter :
  $PortalListenHost="PC-COORDINATION"
avec le vrai nom du poste, puis relancer START_PORTAIL.bat sur ce poste.
Les métiers ouvrent alors : http://PC-COORDINATION:8793/
Leur identité Windows est authentifiée par ce serveur et les accès sont
filtrés selon la session. Ils n'ont pas besoin d'un accès direct au JSON DATA
ni de lancer le serveur sur leur propre poste dans ce mode.
Le nom doit être accessible sur le réseau interne ; l'autorisation d'écoute
HTTP, le pare-feu du poste et les droits Windows doivent être préparés dans
votre environnement. Aucune de ces règles système n'est modifiée par le ZIP.
Le mode local reste le défaut si PortalListenHost n'est pas renseigné.
Les droits NTFS du partage restent déterminants et ne sont pas changés ici.
Le processus travaille avec les droits du compte qui lance le serveur.

FONCTIONNALITÉS MÉTIERS
- Espace limité aux entités affectées à la session Windows.
- Dépôt PDF/DOC/DOCX (un document par dépôt, 50 Mo maximum).
- Sous-entités reprises exactement depuis le schéma actuel de l'application.
- Écriture uniquement dans un dossier À traiter déjà existant.
- Nom unique obligatoire : pas d'écrasement d'un fichier ni d'un dossier.
- Date réelle de dépôt figée, session, commentaire, taille et empreinte SHA256.
- Urgence avec motif, partagée avec Manager et l'onglet Urgence des agents.
- Suivi des statuts À traiter / En cours / Non conforme / Traités.
- Lecture des retours NC et échange de commentaires.
- Redépôt d'une version corrigée À traiter, liée au document NC d'origine.
  Le dossier NC reste conservé et son statut physique n'est pas changé.
  Les versions corrigées et leurs statuts sont visibles dans le fil NC.
- Téléchargement des fichiers présents et des dossiers traités/NC en ZIP.
- Facture de l'entité : détail des documents conformes et code section.

FONCTIONNALITÉS COORDINATION
- Volumes du stock présent par entité, sous-entité et statut.
- Consultation des dépôts, retours NC, urgences et traitements.
- Facture par code section / entité / sous-entité, filtre de mois.
- Téléchargement PDF de facture et export CSV, journalisés par session.
- Journal commun : actions portail et mouvements des agents/managers.

RÈGLES DE FACTURATION
Un document traité conforme correspond à une ligne de facture.
La date est billingDate ou folderCreated, comme la facture actuelle.
Les prix des documents existants, y compris les exceptions du manager,
restent prioritaires. Le prix dans Paramètres est le prix par défaut des
nouveaux dépôts ; il ne réécrit pas rétroactivement les anciens tarifs.
Le code section est capturé au dépôt ; s'il est vide, la configuration
actuelle de l'entité sert de référence pour la facture.
Les fiches historiques hors stock et les dates de dossier inconnues sont
signalées mais exclues du montant, sans inventer une date de facturation.
L'unité de facturation par défaut est « unites » : renseigner votre devise
ou unité réelle, sans conversion monétaire automatique.

ÉCHANGES JSON ET INTÉGRATION EXISTANTE
Tout est écrit dans DATA\catalogue.json sous le verrou catalogue.lock :
- documents : dépôt/statut/prix/priority et metadata documents[].portal ;
- history : dépôts et notes portail, lisibles par la consolidation Manager ;
- portal.config : tarifs, codes section et affectations de sessions ;
- portal.journal : opérations avec identité Windows, horodatage et détails.
Les notes « PRIORITE » et « REPONSE NC » ne comptent pas comme des traitements.
La copie et l'écriture catalogue partagent la transaction du stockage actuel.
En cas d'échec de sauvegarde, seul le fichier nouvellement déposé est retiré.
Le portail ne déplace pas les documents dans En cours/Traités/NC : les agents
continuent leur fonctionnement actuel. Aucun choix de portefeuille n'est modifié.
Une fin de traitement apparaît au prochain rafraîchissement (environ 5 s),
ou immédiatement avec Actualiser. Les champs en cours de saisie, la fenêtre
de dépôt et les paramètres ne sont pas remplacés par le rafraîchissement.
Les dépôts manuels hors portail n'ont pas de session de déposant inventée.
Aucun fichier de suivi JSON/lock n'est créé dans le DP par ce portail.

VALIDATION ET DIAGNOSTIC
- Exécuter TEST_PORTAIL.bat sur Windows : les tests utilisent seulement un
  dossier temporaire local, jamais votre DP ou votre DATA réel.
- START_DEBUG.bat affiche les erreurs de connexion/lancement.
- Le serveur se lance en arrière-plan avec START_PORTAIL.bat.
- Fermer le serveur arrête seulement ce portail, depuis la session qui l'a lancé.
- Le ZIP ne contient aucun catalogue ni fichier de données à remplacer.
- Le portail requiert les fonctions du système actuel : WithStore, Register,
  FindDoc, BranchPath, Body et Q, présentes dans ACCESSIBILITY_BANK_SYSTEM V5.
- Les tests JS, le modèle de facture et l'export PDF multipage ont été exécutés.
  PowerShell Windows, authentification réelle et accès au partage n'ont pas
  pu être exécutés dans l'environnement de développement Linux.
- Le PDF utilise des polices standards locales ; les caractères hors du jeu
  latin pris en charge sont normalisés, sans téléchargement de police.
- Aucun service extérieur, API cloud, email ou modèle IA n'est appelé.

MISE A JOUR DE VERIFICATION
- Une affectation DOMAINE\SESSION explicite prime sur une affectation SESSION seule.
- Les valeurs de depot sont figees avant lecture du fichier.
- Les cellules CSV susceptibles de devenir des formules sont neutralisees.
- Les fichiers lies sont refuses au telechargement, comme les dossiers lies.
