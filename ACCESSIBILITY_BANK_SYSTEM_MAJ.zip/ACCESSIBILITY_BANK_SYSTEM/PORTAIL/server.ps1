﻿param([int]$Port=8793,[string]$ListenHost='localhost',[string]$RootPath='\\UF11-a03\eids-eaa-pdf-statiques\ACCESSIBILITE',[string]$DataPath=(Join-Path (Split-Path $PSScriptRoot -Parent) 'DATA'))
$ErrorActionPreference='Stop'
$base=Split-Path $PSScriptRoot -Parent;$config=Join-Path $base 'CONFIG.ps1';if(Test-Path -LiteralPath $config){. $config}
if($PortalListenHost){$ListenHost=[string]$PortalListenHost};if($ListenHost-notmatch '^[A-Za-z0-9_.-]+$'){throw 'Nom de poste d ecoute invalide'};$portalOrigin=([Uri]("http://${ListenHost}:$Port")).GetLeftPart([UriPartial]::Authority);
$Role='PORTAIL';. (Join-Path $base 'common.ps1');. (Join-Path $PSScriptRoot 'portal.ps1')
function PortalSend($c,$code,$o){$bytes=[Text.Encoding]::UTF8.GetBytes(($o|ConvertTo-Json -Depth 30 -Compress));$c.Response.StatusCode=$code;$c.Response.ContentType='application/json; charset=utf-8';$c.Response.Headers['Cache-Control']='no-store';$c.Response.ContentLength64=$bytes.Length;$c.Response.OutputStream.Write($bytes,0,$bytes.Length);$c.Response.Close()}
$tokens=@{};$listener=New-Object Net.HttpListener;$listener.AuthenticationSchemes=[Net.AuthenticationSchemes]::IntegratedWindowsAuthentication;$listener.Prefixes.Add($portalOrigin+'/');$listener.Start();Start-Process ($portalOrigin+'/')
$assets=@{'/'='index.html';'/app.js'='app.js';'/model.js'='model.js';'/style.css'='style.css';'/vendor/pdf-lib.min.js'='vendor\pdf-lib.min.js'}
try{$run=$true;while($run){$c=$listener.GetContext();$temp=$null;try{
 $r=$c.Request;if(!$c.User -or !$c.User.Identity.IsAuthenticated){PortalSend $c 401 @{error='Authentification Windows requise'};continue}
 $script:PortalIdentity=$c.User.Identity.Name;$user=PortalUser;$path=$r.Url.AbsolutePath
 if($r.HttpMethod-eq'GET' -and $assets.ContainsKey($path)){$file=Join-Path $PSScriptRoot $assets[$path];$bytes=[IO.File]::ReadAllBytes($file);$c.Response.ContentType=$(if($path.EndsWith('.js')){'application/javascript; charset=utf-8'}elseif($path.EndsWith('.css')){'text/css; charset=utf-8'}else{'text/html; charset=utf-8'});$c.Response.Headers['Cache-Control']='no-store';$c.Response.ContentLength64=$bytes.Length;$c.Response.OutputStream.Write($bytes,0,$bytes.Length);$c.Response.Close();continue}
 if($path-eq'/api/bootstrap' -and $r.HttpMethod-eq'GET'){
  if(!$tokens.ContainsKey($user)){$tokens[$user]=[guid]::NewGuid().ToString('N')+[guid]::NewGuid().ToString('N')}
  $result=PortalSnapshot;$result.token=$tokens[$user];PortalSend $c 200 $result;continue
 }
 if($path-eq'/api/settings' -and $r.HttpMethod-eq'GET'){PortalSend $c 200 (PortalSettings);continue}
 if($path-eq'/api/download' -and $r.HttpMethod-eq'GET'){
  $q=Q $r;$info=PortalDownloadPath ([string]$q.id);$file=[string]$info.path;$name=[string]$info.name
  if(((Get-Item -LiteralPath $file).Attributes-band[IO.FileAttributes]::ReparsePoint)-ne 0){throw 'Document lie non telechargeable'}
  if([IO.Directory]::Exists($file)){
   if(((Get-Item -LiteralPath $file).Attributes-band[IO.FileAttributes]::ReparsePoint)-ne 0){throw 'Dossier lie non telechargeable'};$children=@(Get-ChildItem -LiteralPath $file -Recurse -Force);if(@($children|Where-Object{($_.Attributes-band[IO.FileAttributes]::ReparsePoint)-ne 0}).Count){throw 'Le dossier contient un lien de fichiers non telechargeable'}
   $files=@($children|Where-Object{!$_.PSIsContainer});$size=($files|Measure-Object Length -Sum).Sum;if($size-gt 50MB -or $files.Count-gt 1000){throw 'Dossier trop volumineux pour le telechargement (50 Mo, 1000 fichiers)'}
   Add-Type -AssemblyName System.IO.Compression.FileSystem;$temp=Join-Path ([IO.Path]::GetTempPath()) ('Portail-'+[guid]::NewGuid().ToString('N')+'.zip');[IO.Compression.ZipFile]::CreateFromDirectory($file,$temp);$file=$temp;$name+='.zip'
  }elseif((Get-Item -LiteralPath $file).Length-gt 50MB){throw 'Document superieur a 50 Mo'}
  $bytes=[IO.File]::ReadAllBytes($file);$c.Response.ContentType='application/octet-stream';$c.Response.Headers['Content-Disposition']="attachment; filename*=UTF-8''$([Uri]::EscapeDataString($name))";$c.Response.Headers['Cache-Control']='no-store';$c.Response.ContentLength64=$bytes.Length;$c.Response.OutputStream.Write($bytes,0,$bytes.Length);$c.Response.Close();continue
 }
 if($r.HttpMethod-ne'POST'){PortalSend $c 404 @{error='Route inconnue'};continue}
 if(!$tokens.ContainsKey($user) -or $r.Headers['X-Portal-Token']-cne$tokens[$user]){PortalSend $c 403 @{error='Jeton de session invalide. Actualisez.'};continue}
 if($r.Headers['Origin'] -and $r.Headers['Origin'].ToLowerInvariant()-ne$portalOrigin.ToLowerInvariant()){PortalSend $c 403 @{error='Origine de requete refusee'};continue}
 if(!$r.ContentType -or !$r.ContentType.StartsWith('application/json') -or $r.ContentLength64-lt 0 -or $r.ContentLength64-gt 72MB){PortalSend $c 400 @{error='Requete JSON invalide ou trop volumineuse'};continue}
 $body=Body $r
 switch($path){
  '/api/settings' {PortalSend $c 200 (PortalSaveSettings $body)}
  '/api/deposit' {PortalSend $c 200 (PortalDeposit $body)}
  '/api/urgent' {PortalSend $c 200 (PortalUrgent $body)}
  '/api/nc-message' {PortalSend $c 200 (PortalMessage $body)}
  '/api/export-log' {PortalSend $c 200 (PortalExportLog $body)}
  '/api/leave' {if((PortalShortUser)-ne([Environment]::UserName).ToUpperInvariant()){throw 'Fermeture reservee a la session qui a lance ce serveur'};PortalSend $c 200 @{ok=$true};$run=$false}
  default {PortalSend $c 404 @{error='Route inconnue'}}
 }
 }catch{try{$code=400;if($_.Exception.Message-match 'Acces refuse|reserves|reservee|Session Windows'){$code=403};PortalSend $c $code @{error=$_.Exception.Message}}catch{}}finally{if($temp -and [IO.File]::Exists($temp)){[IO.File]::Delete($temp)}}
 }}finally{$listener.Stop();$listener.Close()}
