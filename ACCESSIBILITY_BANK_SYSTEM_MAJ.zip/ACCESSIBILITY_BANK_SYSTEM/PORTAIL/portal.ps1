﻿# Uses the same catalogue lock and atomic save functions as Manager/Agent.
$PortalAdmins=@('HAMDANMO','OUBRAHMO')
function PortalUser(){if(!$script:PortalIdentity){throw 'Session Windows authentifiee requise'};return [string]$script:PortalIdentity}
function PortalShortUser(){((PortalUser)-split '\\')[-1].ToUpperInvariant()}
function PortalAdmin(){return $PortalAdmins -contains (PortalShortUser)}
function PortalEnsure($db){
 if($db.PSObject.Properties.Name -notcontains 'portal'){
  $entities=@();foreach($e in $Schema.Keys){$price=9;if(@('DIRCO','CMMABN','CIC CIB ASSET SERVICING')-contains$e){$price=4.5};$entities+=@([pscustomobject]@{entity=$e;sectionCode='';unitPrice=$price})}
  $db|Add-Member -NotePropertyName portal -NotePropertyValue ([pscustomobject]@{version=1;config=[pscustomobject]@{revision=0;unit='unites';entities=$entities;sessions=@()};journal=@()})
 }
}
function PortalSessionRule($db){
 # Une affectation DOMAINE\SESSION explicite prime sur SESSION seule.
 $full=(PortalUser).ToUpperInvariant();$short=PortalShortUser
 $exact=@($db.portal.config.sessions|Where-Object{$_.session.ToUpperInvariant()-eq$full})|Select-Object -First 1
 if($exact){return $exact}
 return @($db.portal.config.sessions|Where-Object{$_.session-notmatch '\\' -and $_.session.ToUpperInvariant()-eq$short})|Select-Object -First 1
}
function PortalRole($db){
 if(PortalAdmin){return 'administration'}
 $rule=PortalSessionRule $db
 if(!$rule){return 'non-affecte'};return [string]$rule.role
}
function PortalEntities($db){
 $role=PortalRole $db;if(@('administration','coordination')-contains$role){return @($Schema.Keys)}
 $rule=PortalSessionRule $db
 if($role-eq'metier' -and $rule){return @($rule.entities)};return @()
}
function PortalAllow($db,$entity){if(@(PortalEntities $db)-notcontains [string]$entity){throw 'Acces refuse a cette entite'}}
function PortalJournal($db,$action,$entity,$documentId,$detail){
 $db.portal.journal=@($db.portal.journal)+@([pscustomobject]@{id=[guid]::NewGuid().ToString();at=(Get-Date).ToString('o');session=(PortalUser);action=$action;entity=$entity;documentId=$documentId;detail=$detail})
}
function PortalHistoryNote($db,$d,$type,$text){
 $db.history=@($db.history)+@([pscustomobject]@{id=[guid]::NewGuid().ToString();documentId=$d.id;timestamp=(Get-Date).ToString('o');agent=(PortalUser);entity=$d.entity;branch=$d.branch;from='PORTAIL';to=$type;name=$d.name;started=$null;dmt_minutes=$null;status_minutes=$null;comment=$text;complex=$d.complex;complexComment=$d.complexComment;source='PORTAIL';eventType='NOTE'})
}
function PortalDoc($db,$id){$d=@($db.documents|Where-Object{$_.id-eq$id})|Select-Object -First 1;if(!$d){throw 'Document introuvable'};PortalAllow $db $d.entity;return $d}
function PortalSnapshot(){WithStore {param($db)
 PortalEnsure $db;$allowed=@(PortalEntities $db);$entities=@();foreach($e in $allowed){$entities+=@([pscustomobject]@{entity=$e;branches=@($Schema[$e].Branches);tariff=(@($db.portal.config.entities|Where-Object{$_.entity-eq$e})|Select-Object -First 1)})}
 $docs=@();foreach($d in @($db.documents|Where-Object{$allowed-contains$_.entity})){
  $meta=$null;if($d.PSObject.Properties.Name-contains'portal'){$meta=$d.portal}
  $docs+=@([pscustomobject]@{id=$d.id;entity=$d.entity;branch=$d.branch;name=$d.name;kind=$d.kind;status=$d.status;present=$d.present;deposit=$d.deposit;completed=$d.completed;billingDate=$d.billingDate;folderCreated=$d.folderCreated;priority=$d.priority;unitPrice=$d.unitPrice;complex=$d.complex;complexComment=$d.complexComment;ncComment=$d.ncComment;portal=$meta})
 }
 $journal=@($db.portal.journal|Where-Object{$allowed-contains$_.entity -or (PortalAdmin) -or (!$_.entity -and $_.session-eq(PortalUser))})
 $history=@($db.history|Where-Object{$allowed-contains$_.entity}|ForEach-Object{[pscustomobject]@{id=$_.id;documentId=$_.documentId;timestamp=$_.timestamp;entity=$_.entity;branch=$_.branch;name=$_.name;from=$_.from;to=$_.to;agent=$_.agent;comment=$_.comment;source=$_.source}})
 return @{session=(PortalUser);role=(PortalRole $db);isAdmin=(PortalAdmin);entities=$entities;documents=$docs;journal=$journal;history=$history;unit=$db.portal.config.unit;at=(Get-Date).ToString('o')}
 } $false}
function PortalSettings(){if(!(PortalAdmin)){throw 'Parametres reserves a HAMDANMO et OUBRAHMO'};WithStore {param($db);PortalEnsure $db;return $db.portal.config} $false}
function PortalSaveSettings($body){if(!(PortalAdmin)){throw 'Parametres reserves a HAMDANMO et OUBRAHMO'};WithStore {param($db)
 PortalEnsure $db;if([int]$body.revision-ne[int]$db.portal.config.revision){throw 'Parametres modifies entre-temps. Actualisez avant de sauvegarder.'}
 $list=@($body.entities);if($list.Count-ne$Schema.Count){throw 'Toutes les entites sont requises'};$seen=@{};$entities=@()
 foreach($e in $list){if(!$Schema.Contains([string]$e.entity) -or $seen.ContainsKey([string]$e.entity)){throw 'Entite de parametres invalide'};$seen[[string]$e.entity]=$true;$canonical=@($Schema.Keys|Where-Object{$_-eq[string]$e.entity})[0]
  if($null-eq$e.unitPrice -or $e.unitPrice-is[bool]){throw 'Prix unitaire invalide'};try{$price=[Convert]::ToDouble($e.unitPrice,[Globalization.CultureInfo]::InvariantCulture)}catch{throw 'Prix unitaire invalide'};if($price-lt 0 -or [double]::IsNaN($price) -or [double]::IsInfinity($price)){throw 'Prix unitaire invalide'}
  $code=([string]$e.sectionCode).Trim();if($code.Length-gt 80){throw 'Code section trop long'}
  $entities+=@([pscustomobject]@{entity=[string]$canonical;sectionCode=$code;unitPrice=[Math]::Round($price,2)})
 }
 $sessions=@();$seen=@{};foreach($s in @($body.sessions)){
  $login=([string]$s.session).Trim().ToUpperInvariant();if($login-notmatch '^(?:[A-Z0-9_.-]+\\)?[A-Z0-9_.-]+$' -or $seen.ContainsKey($login)){throw 'Session Windows invalide ou dupliquee'};$seen[$login]=$true
  if(@('metier','coordination')-notcontains[string]$s.role){throw 'Role invalide'};$scope=@($s.entities|Select-Object -Unique)
  $scope=@(foreach($e in $scope){if(!$Schema.Contains([string]$e)){throw 'Entite de session invalide'};@($Schema.Keys|Where-Object{$_-eq[string]$e})[0]})
  if($s.role-eq'metier' -and !$scope.Count){throw 'Une session metier doit avoir au moins une entite'}
  $sessions+=@([pscustomobject]@{session=$login;role=([string]$s.role).ToLowerInvariant();entities=$scope})
 }
 $unit=([string]$body.unit).Trim();if(!$unit -or $unit.Length-gt 30){throw 'Unite de facturation requise (30 caracteres maximum)'}
 $db.portal.config=[pscustomobject]@{revision=([int]$db.portal.config.revision+1);unit=$unit;entities=$entities;sessions=$sessions}
 PortalJournal $db 'PARAMETRES' '' '' @{revision=$db.portal.config.revision;entities=$entities;sessions=$sessions;unit=$unit}
 return @{ok=$true;revision=$db.portal.config.revision}
 } $true}
function PortalFilename($name){
 if(!$name -or $name.Length-gt 180 -or [IO.Path]::GetFileName($name)-cne$name -or $name.IndexOfAny([IO.Path]::GetInvalidFileNameChars())-ge 0 -or $name.EndsWith('.') -or $name.EndsWith(' ') -or $name-match '^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)'){throw 'Nom de fichier invalide'}
 if(@('.pdf','.doc','.docx')-notcontains[IO.Path]::GetExtension($name).ToLowerInvariant()){throw 'Formats acceptes : PDF, DOC, DOCX'}
}
function PortalDeposit($body){WithStore {param($db)
 PortalEnsure $db;$e=[string]$body.entity;$b=[string]$body.branch;PortalAllow $db $e;$e=[string](@($Schema.Keys|Where-Object{$_-eq$e})[0]);$branches=@($Schema[$e].Branches|Where-Object{$_-eq$b});if(!$branches.Count){throw 'Sous-entite invalide'};$b=[string]$branches[0];$name=[string]$body.name;PortalFilename $name;PortalFilename ([string]$body.originalName);if([IO.Path]::GetExtension($name).ToLowerInvariant()-ne[IO.Path]::GetExtension([string]$body.originalName).ToLowerInvariant()){throw 'Conservez l extension du fichier original'}
 $source=$null;if($body.sourceDocumentId){$source=PortalDoc $db ([string]$body.sourceDocumentId);if($source.entity-ne$e -or $source.status-ne'NON CONFORME'){throw 'Le document corrige doit etre non conforme et appartenir a la meme entite'}}
 $urgent=($body.urgent-eq$true);$reason=([string]$body.urgentReason).Trim();$comment=([string]$body.comment).Trim();if($comment.Length-gt 4000 -or $reason.Length-gt 1000){throw 'Commentaire trop long'};if($urgent -and !$reason){throw 'Renseignez le motif de l urgence'}
 $bytes=[Convert]::FromBase64String([string]$body.content);if(!$bytes.Length -or $bytes.Length-gt 50MB){throw 'Document vide ou superieur a 50 Mo'};
 $extension=[IO.Path]::GetExtension($name).ToLowerInvariant();if($extension-eq'.pdf' -and [Text.Encoding]::ASCII.GetString($bytes,0,[Math]::Min(1024,$bytes.Length)).IndexOf('%PDF-')-lt 0){throw 'Signature PDF absente'};if($extension-eq'.docx' -and ($bytes.Length-lt 4 -or $bytes[0]-ne 80 -or $bytes[1]-ne 75)){throw 'Signature DOCX absente'};if($extension-eq'.doc' -and ($bytes.Length-lt 8 -or [BitConverter]::ToString($bytes,0,8)-ne'D0-CF-11-E0-A1-B1-1A-E1')){throw 'Signature DOC absente'}
 $path=BranchPath $e 'A TRAITER' $b;if(![IO.Directory]::Exists($path)){throw 'Dossier A TRAITER inexistant : aucun dossier DP ne sera cree par le portail'}
 $dest=Join-Path $path $name
 if([IO.File]::Exists($dest) -or [IO.Directory]::Exists($dest) -or (FindDoc $db $e $b $name)){throw 'Ce nom existe deja. Utilisez un nom de nouvelle version pour conserver la trace.'}
 $stream=[IO.File]::Open($dest,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
 $script:Undo+=@([pscustomobject]@{kind='remove';path=$dest});try{$stream.Write($bytes,0,$bytes.Length);$stream.Flush()}finally{$stream.Dispose()}
 $now=(Get-Date).ToString('o');$d=Register $db $e $b 'A TRAITER' (Get-Item -LiteralPath $dest);$rate=@($db.portal.config.entities|Where-Object{$_.entity-eq$e})|Select-Object -First 1
 $d.deposit=$now;$d.statusSince=$now;$d.unitPrice=$rate.unitPrice;$d.priority=$urgent
 $sha=[Security.Cryptography.SHA256]::Create();try{$hash=([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}
 $meta=[pscustomobject]@{depositor=(PortalUser);depositedAt=$now;sectionCode=$rate.sectionCode;sourceDocumentId=[string]$body.sourceDocumentId;comment=$comment;urgentReason=$reason;sha256=$hash;size=$bytes.Length;messages=@()}
 $d|Add-Member -NotePropertyName portal -NotePropertyValue $meta
 PortalJournal $db $(if($source){'REDEPOT_CORRECTION'}else{'DEPOT'}) $e $d.id @{name=$name;originalName=[string]$body.originalName;branch=$b;size=$bytes.Length;sha256=$hash;urgent=$urgent;urgentReason=$reason;comment=$comment;sourceDocumentId=[string]$body.sourceDocumentId;sectionCode=$rate.sectionCode;unitPrice=$rate.unitPrice}
 $db.history=@($db.history)+@([pscustomobject]@{id=[guid]::NewGuid().ToString();documentId=$d.id;timestamp=$now;agent=(PortalUser);entity=$e;branch=$b;from='DEPOT METIER';to='A TRAITER';name=$name;started=$null;dmt_minutes=$null;status_minutes=$null;comment=$comment;complex=$false;complexComment='';source='PORTAIL'})
 return @{ok=$true;documentId=$d.id;deposit=$now}
 } $true}
function PortalUrgent($body){WithStore {param($db)
 PortalEnsure $db;$d=PortalDoc $db ([string]$body.id);if(@('A TRAITER','EN COURS')-notcontains$d.status){throw 'Urgence uniquement sur un document a traiter ou en cours'}
 $value=($body.urgent-eq$true);$reason=([string]$body.reason).Trim();if($reason.Length-gt 1000 -or ($value -and !$reason)){throw 'Motif d urgence requis (1000 caracteres maximum)'}
 $d.priority=$value;if($d.PSObject.Properties.Name-notcontains'portal'){$d|Add-Member -NotePropertyName portal -NotePropertyValue ([pscustomobject]@{messages=@()})};$urgency=[pscustomobject]@{urgent=$value;reason=$reason;session=(PortalUser);at=(Get-Date).ToString('o')};if($d.portal.PSObject.Properties.Name-contains'urgency'){$d.portal.urgency=$urgency}else{$d.portal|Add-Member -NotePropertyName urgency -NotePropertyValue $urgency};PortalJournal $db 'URGENCE' $d.entity $d.id @{urgent=$value;reason=$reason};PortalHistoryNote $db $d 'PRIORITE' $reason;return @{ok=$true}
 } $true}
function PortalMessage($body){WithStore {param($db)
 PortalEnsure $db;$d=PortalDoc $db ([string]$body.id);if($d.status-ne'NON CONFORME'){throw 'Le document n est plus non conforme'};$text=([string]$body.message).Trim();if(!$text -or $text.Length-gt 4000){throw 'Message requis (4000 caracteres maximum)'}
 if($d.PSObject.Properties.Name-notcontains'portal'){$d|Add-Member -NotePropertyName portal -NotePropertyValue ([pscustomobject]@{messages=@()})}
 if($d.portal.PSObject.Properties.Name-notcontains'messages'){$d.portal|Add-Member -NotePropertyName messages -NotePropertyValue @()}
 $d.portal.messages=@($d.portal.messages)+@([pscustomobject]@{at=(Get-Date).ToString('o');session=(PortalUser);text=$text})
 PortalJournal $db 'REPONSE_NC' $d.entity $d.id @{message=$text};PortalHistoryNote $db $d 'REPONSE NC' $text;return @{ok=$true}
 } $true}
function PortalExportLog($body){WithStore {param($db)
 PortalEnsure $db;$entity=[string]$body.entity;if($entity){PortalAllow $db $entity}else{if(!(PortalEntities $db).Count){throw 'Acces refuse sans entite affectee'}}
 if($body.month -and [string]$body.month-notmatch '^\d{4}-(0[1-9]|1[0-2])$'){throw 'Periode invalide'};if(@('pdf','csv')-notcontains[string]$body.format){throw 'Format invalide'};PortalJournal $db 'EXPORT_FACTURE' $entity '' @{period=[string]$body.month;format=[string]$body.format;scope=@(PortalEntities $db)};return @{ok=$true}
 } $true}
function PortalDownloadPath($id){WithStore {param($db);PortalEnsure $db;$d=PortalDoc $db $id;if(!$d.present){throw 'Document uniquement historique : presence DP non confirmee'};if([IO.Path]::GetFileName([string]$d.name)-cne$d.name -or @('.','..')-contains$d.name){throw 'Nom de document invalide'};$path=Join-Path (BranchPath $d.entity $d.status $d.branch) $d.name;if(![IO.File]::Exists($path) -and ![IO.Directory]::Exists($path)){throw 'Document absent de son emplacement actuel. Actualisez les donnees.'};PortalJournal $db 'DEMANDE_TELECHARGEMENT' $d.entity $d.id @{status=$d.status;name=$d.name};return @{path=$path;name=$d.name;kind=$d.kind}} $true}
