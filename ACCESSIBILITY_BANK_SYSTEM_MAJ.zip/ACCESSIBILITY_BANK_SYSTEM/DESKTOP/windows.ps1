﻿# Native UI helpers only; document movements and folder validation stay in common.ps1.
if(!('AccessibilityDesktop.Native' -as [type])){
 Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
namespace AccessibilityDesktop {
 public static class Native {
  [DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow();
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
 }
}
'@
}
if($env:ACCESSIBILITY_DEBUG_CONSOLE-ne'1'){
 $console=[AccessibilityDesktop.Native]::GetConsoleWindow()
 if($console-ne[IntPtr]::Zero){$null=[AccessibilityDesktop.Native]::ShowWindow($console,0)}
}
function ChooseFolder(){
 if($Role-ne'AGENT'){throw 'Choix de dossier reserve au poste agent'}
 Add-Type -AssemblyName System.Windows.Forms
 $dialog=New-Object System.Windows.Forms.FolderBrowserDialog
 $owner=New-Object System.Windows.Forms.Form
 $owner.Text='Selection du dossier traite';$owner.StartPosition='CenterScreen'
 $owner.Width=1;$owner.Height=1;$owner.Opacity=0;$owner.ShowInTaskbar=$false;$owner.TopMost=$true
 $dialog.Description='Choisissez sur votre Bureau le dossier contenant les fichiers traites.'
 $dialog.SelectedPath=DesktopPath;$dialog.ShowNewFolderButton=$false
 try{
  $owner.Show();$owner.BringToFront();$owner.Activate()
  $null=[AccessibilityDesktop.Native]::SetForegroundWindow($owner.Handle)
  if($dialog.ShowDialog($owner)-eq[Windows.Forms.DialogResult]::OK){return @{path=$dialog.SelectedPath;cancelled=$false}}
  return @{cancelled=$true}
 }finally{$dialog.Dispose();$owner.Close();$owner.Dispose()}
}
