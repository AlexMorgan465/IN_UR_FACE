(()=>{
let session='';
const mine=d=>d.present&&d.status==='EN COURS'&&!!session&&String(d.agent).toLowerCase()===session.toLowerCase();
const style=document.createElement('style');style.textContent='.my-document,.my-document:hover{background:#e7f5ed!important}.my-document td:first-child{border-left:5px solid #187347}.owner-label{display:block;color:#165a39;font-weight:700;margin-top:6px}.mine-summary{border-left:5px solid #187347;margin:16px 0}.ops{flex-wrap:wrap}';document.head.append(style);
const panel=document.createElement('section');panel.className='panel mine-summary';panel.innerHTML='<h2>Mes documents en cours <span id="mine-count">0</span></h2><p>Documents pris en charge avec ma session Windows, toutes entités confondues.</p><div style="overflow:auto"><table><thead><tr><th>Document</th><th>Entité / sous-entité</th><th>Depuis</th><th>Actions</th></tr></thead><tbody id="mine-rows"></tbody></table></div><p id="copy-feedback" role="status" aria-live="polite"></p>';
document.querySelector('.panel.work').before(panel);
async function copy(id,button){button.disabled=true;try{const r=await post('/api/copy-desktop',{id});$('#copy-feedback').textContent='Copie disponible sur le Bureau : '+r.path;alert('Document recopié sur votre Bureau.')}catch(e){$('#copy-feedback').textContent=e.message;alert(e.message)}finally{button.disabled=false}}
function decorate(){
 for(const row of document.querySelectorAll('#rows tr,#urows tr')){const b=row.querySelector('[data-complex]');const d=allDocs.find(x=>x.id===b?.dataset.complex)||S.items.find(x=>x.id===b?.dataset.complex);if(!d)continue;row.classList.toggle('my-document',mine(d));row.querySelectorAll('.owner-label,[data-copy]').forEach(x=>x.remove());if(d.status==='EN COURS'){row.cells[0].insertAdjacentHTML('beforeend','<span class="owner-label">'+(mine(d)?'● Mon document en cours':'Pris en charge par '+esc(d.agent||'session non renseignée'))+'</span>');if(mine(d))row.cells[row.cells.length-1].insertAdjacentHTML('beforeend','<button class="btn" data-copy="'+esc(d.id)+'">Recopier sur le Bureau</button>')}}
 const docs=allDocs.filter(mine);$('#mine-count').textContent='('+docs.length+')';$('#mine-rows').innerHTML=docs.map(d=>'<tr class="my-document"><td><b>'+esc(d.name)+'</b><span class="owner-label">● Mon document en cours</span></td><td>'+esc(d.entity)+'<br>'+esc(d.branch||'Racine')+'</td><td>'+dateFmt(d.started||d.statusSince)+'</td><td><button class="btn" data-locate="'+esc(d.id)+'">Afficher</button> <button class="btn" data-copy="'+esc(d.id)+'">Recopier sur le Bureau</button></td></tr>').join('')||'<tr><td colspan="4">Aucun document en cours pour '+esc(session||'la session courante')+'.</td></tr>';
 panel.querySelectorAll('[data-locate]').forEach(b=>b.onclick=async()=>{let d=allDocs.find(x=>x.id===b.dataset.locate);$('#entity').value=d.entity;branches();$('#branch').value=d.branch;$('#status').value='EN COURS';path();await load()});
 document.querySelectorAll('[data-copy]').forEach(b=>b.onclick=()=>copy(b.dataset.copy,b));
}
const oldApi=api;api=async function(u,o){const r=await oldApi(u,o);if(r.agent)session=r.agent;return r};
const oldRender=render;render=function(){oldRender();decorate()};
const oldUrgencies=urgencies;urgencies=async function(){await oldUrgencies();decorate()};
api('/api/ping').then(()=>urgencies()).catch(()=>{});
})();
