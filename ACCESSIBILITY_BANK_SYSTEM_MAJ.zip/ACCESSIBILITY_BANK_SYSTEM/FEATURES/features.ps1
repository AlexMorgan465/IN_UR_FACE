function CopyMyDocument($body){
 if($Role-ne'AGENT'){throw 'Action reservee au poste agent'}
 WithStore {param($db)
  $d=@($db.documents|Where-Object{$_.id-eq$body.id})|Select-Object -First 1
  if(!$d -or !$d.present -or $d.status-ne'EN COURS' -or $d.agent-ne(Agent)){throw 'Ce document ne fait pas partie de vos documents en cours'}
  $n=Safe ([string]$d.name)
  $src=Join-Path (BranchPath $d.entity 'EN COURS' $d.branch) $n
  if(!(Test-Path -LiteralPath $src)){throw 'Document deplace ou absent du DP'}
  $desktop=DesktopPath
  if(!$desktop -or !(Test-Path -LiteralPath $desktop)){throw 'Bureau Windows inaccessible'}
  $dst=Join-Path $desktop $n
  if(Test-Path -LiteralPath $dst){throw 'Un element du meme nom existe sur votre Bureau. Renommez-le ou deplacez-le avant de recopier. Aucun fichier ecrase.'}
  $script:Undo+=@{kind='delete';path=$dst}
  Copy-Item -LiteralPath $src -Destination $dst -Recurse -ErrorAction Stop
  @{ok=$true;path=$dst}
 } $false
}
function PublicationCounts(){
 if($Role-ne'MANAGER'){throw 'Action reservee au manager'}
 $rows=@()
 foreach($b in $Schema['ACM'].Branches){
  $p=Join-Path (Join-Path (Join-Path $RootPath 'ACM') 'A PUBLIER') $b
  try{
   $count=$null;$state='absent'
   if(Test-Path -LiteralPath $p -ErrorAction Stop){$count=@(Get-ChildItem -LiteralPath $p -ErrorAction Stop).Count;$state='ok'}
   $rows+=@{entity='ACM';branch=$b;count=$count;state=$state}
  }catch{$rows+=@{entity='ACM';branch=$b;count=$null;state='error'}}
 }
 @{rows=$rows;at=(Get-Date).ToString('o')}
}
