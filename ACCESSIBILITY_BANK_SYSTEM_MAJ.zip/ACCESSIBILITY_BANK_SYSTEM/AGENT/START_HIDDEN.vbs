Option Explicit
Dim shell, fs, folder, exe, command, processEnv
Set shell = CreateObject("WScript.Shell")
Set fs = CreateObject("Scripting.FileSystemObject")
folder = fs.GetParentFolderName(WScript.ScriptFullName)
exe = shell.ExpandEnvironmentStrings("%SystemRoot%") & "\System32\WindowsPowerShell\v1.0\powershell.exe"
command = Chr(34) & exe & Chr(34) & " -STA -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File " & Chr(34) & folder & "\server.ps1" & Chr(34)
Set processEnv = shell.Environment("PROCESS")
processEnv("ACCESSIBILITY_DEBUG_CONSOLE") = "0"
shell.CurrentDirectory = folder
shell.Run command, 0, False
