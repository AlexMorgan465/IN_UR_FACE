@echo off
set ACCESSIBILITY_DEBUG_CONSOLE=1
cd /d "%~dp0"
powershell.exe -STA -NoProfile -ExecutionPolicy Bypass -NoExit -File "%~dp0server.ps1"
