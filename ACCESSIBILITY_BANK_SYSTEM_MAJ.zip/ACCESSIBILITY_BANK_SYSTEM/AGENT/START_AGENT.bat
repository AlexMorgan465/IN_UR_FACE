@echo off
start "" wscript.exe "%~dp0START_HIDDEN.vbs"
exit /b
