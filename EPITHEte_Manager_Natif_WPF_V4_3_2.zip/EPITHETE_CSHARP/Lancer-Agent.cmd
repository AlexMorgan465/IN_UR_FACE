@echo off
setlocal
if not exist "%~dp0bin\Agent-WebView2\EPITHETE-Agent.exe" (echo EXE absent. Lancez Recompiler.cmd. & pause & exit /b 1)
start "EPITHETE Agent" "%~dp0bin\Agent-WebView2\EPITHETE-Agent.exe"
endlocal
