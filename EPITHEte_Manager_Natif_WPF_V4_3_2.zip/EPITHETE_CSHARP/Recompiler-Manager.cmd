@echo off
setlocal
powershell.exe -NoProfile -File "%~dp0Compiler-Manager.ps1"
if errorlevel 1 pause
endlocal
