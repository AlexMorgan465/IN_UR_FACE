﻿VERSION COURANTE V4.2 — ETAFAC : consulter V4.2-NOTES.md pour la saisie manuelle des KPI et le mode Agent hors ligne.

VERSION COURANTE V4.1 : consulter V4.1-NOTES.md pour la nouvelle interface et le chargement en arrière-plan.

# EPITHETE V4 — storage and workstation update

Updated in place: C:\Users\minea\Desktop\EPITHETE_CSHARP_V3_PERFORMANCES_INTERFACE\EPITHETE_CSHARP

Both bin/EPITHETE-Agent.exe and bin/EPITHETE-Manager.exe have been rebuilt for Windows x64 / .NET Framework 4.8. Existing launchers continue to work.

## Data flow

- `epithete-traitements.json`: manager import catalogue and assignments. Agents never rewrite this catalogue.
- `affectations-v3/`: existing per-agent assignment bundles, retained for compatibility.
- `agents-v3/`: historical V3 treatment baseline, retained and read before daily updates.
- `agents-daily/SESSION-HASH/yyyy-MM-dd.json`: independent daily treatment files. Session names are normalized Windows usernames; a short hash avoids sanitized-name collisions. The first write of a new local calendar day creates a new file. Previous days remain immutable archives. Rows are replayed in date order over the existing baseline, so unfinished work carries forward.
- `epithete-consolide.json`: reporting snapshot with schemaVersion, generatedAt, and traitements. Published atomically when Manager refreshes changed data, including the first refresh of a new day. It is not a live database: it can lag while Manager is closed. Existing services continue to read catalogue plus agent overlays directly.

File locks serialize writes for the same session, while different sessions write independently. Manager mutations retain the central lock; manager exports retain per-agent locks. Atomic replacement and .bak files remain enabled. The shared in-process JSON cache is now synchronized for concurrent access.

## Daily backups

`backups/daily/yyyy-MM-dd/` contains a full logical snapshot on the first changed/new-day Manager refresh. `complete.json` is written last; a missing manifest indicates an unfinished snapshot that will be retried. The snapshot includes catalogue, configuration, import ledger, assignment files, V3 baseline, daily journals and the migration marker. Concurrent activity can mean files reflect slightly different instants; this is not a transactionally frozen snapshot across all agents.

`backups/yyyy-MM-dd/<relative file path>` keeps the first pre-change copy of each existing data file changed that day. Previous daily agent journals also remain in agents-daily. Backups and journals have no automatic deletion policy. Full daily snapshots require Manager to run; this application does not install a background scheduler.

For restore: close all Agents and Managers, preserve the current complete data folder, copy the contents of a completed daily snapshot to a separate data folder, and point all workstations to that folder. Start Manager and verify totals before restarting Agents. Keep the catalogue, overlays, assignments and ledger together; the consolidated JSON alone is not a restorable database.

## Paths and interface

Manager: **Paramètres & données** → **Dossier des données JSON**. Agent: **Connexion aux données · paramètres du poste**. Enter an existing local/UNC folder containing epithete-traitements.json, save, then restart. The setting is written to the local desktop-config.json; configure every installation to use the same shared folder. It does not copy or move business data. The source Excel path remains independently configurable in Manager.

Manager business filters now combine agent, source filename, motif, status and export state with existing calendar filters. These apply to work queues, assignments, completed rows, KPIs, charts and report exports. Pagination resets and the current assignment selection clears when business filters change. Agent/source/motif filters match text without case sensitivity. A business-filter reset button is provided.

Both interfaces have denser workstation layouts, compact controls, sticky table headers, alternating table rows, hover/focus states, and restrained dashboard headings.

## Rollout

1. Close all existing versions and preserve a complete production data-folder backup.
2. Deploy the rebuilt V4 applications to every workstation using this shared data folder. Keep the EXEs with their existing DLLs and configuration.
3. Start Manager first. V3 treatment data remains readable without an Excel reimport.
4. Start two Agents, verify different Windows sessions create separate daily journals, finish sample assignments, and check Manager consolidation and exports.
5. Do not run V3 alongside V4: V3 does not read V4 daily journals. Source rollback alone is not sufficient once V4 has written data; restore a coherent data backup as well.

No production/shared business data was opened or migrated during development. Validation used generated local fixtures.

## Verification

- Both Windows applications compiled successfully.
- Existing core suite passed: concurrent Agent writes, ownership, duplicate handling, idempotent imports, assignment preservation, incremental/manual export, concurrent edits during export.
- Daily suite passed: date rollover via a synthetic previous-day file, archive preservation, latest-patch replay, field carryover, pre-write backup, consolidated JSON publication, completed daily snapshot and restoration reads.
- Performance suite passed with 5,000 rows and 25 agents, including writes while the central manager lock was held, migration, assignment bundles, unchanged refresh caching and Excel range-reading simulations.
- Combined manager-filter checks passed; modified JavaScript passed syntax checks.
- Full browser/WPF visual validation could not be completed: the local headless Edge process failed to start under the sandbox. Real Excel COM and real SMB multi-workstation operation were not exercised. Verify these during the two-workstation rollout above.

The supplied original-source ZIP preserves the pre-change src and ui folders for reference. It contains no production database and no original executables.
