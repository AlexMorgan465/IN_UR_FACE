using System;using System.Threading;using EpitheteDesktop;
class TestImmediateExit {static void Main(){var started=new ManualResetEvent(false);new Thread(delegate(){started.Set();Thread.Sleep(Timeout.Infinite);}).Start();started.WaitOne();Console.WriteLine("Worker blocked; calling application exit");ImmediateExit.Run();throw new Exception("Exit returned");}}
