﻿[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
try {
    $project = $PSScriptRoot
    if (-not [Environment]::Is64BitOperatingSystem) { throw 'Cette version cible Windows x64.' }
    $release = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -ErrorAction Stop).Release
    if ($release -lt 528040) { throw '.NET Framework 4.8 ou 4.8.1 est requis.' }
    $framework = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
    $wpf = Join-Path $framework 'WPF'; $csc = Join-Path $framework 'csc.exe'
    $refs = @('System.dll','System.Core.dll','System.Numerics.dll','System.Xaml.dll','Microsoft.CSharp.dll') | ForEach-Object { Join-Path $framework $_ }
    $refs += @('WindowsBase.dll','PresentationCore.dll','PresentationFramework.dll') | ForEach-Object { Join-Path $wpf $_ }
    $refs += Join-Path $project 'lib\Newtonsoft.Json.dll'
    foreach ($r in $refs) { if (-not (Test-Path -LiteralPath $r)) { throw "Référence manquante : $r" } }
    $out = Join-Path $project 'bin\Manager-Native'; New-Item -ItemType Directory -Force -Path $out | Out-Null
    $exe = Join-Path $out 'EPITHETE-Manager.exe'
    $args = @('/nologo','/target:winexe','/platform:x64','/optimize+','/langversion:5','/codepage:65001',"/out:$exe", "/win32manifest:$(Join-Path $project 'src\app.manifest')")
    foreach ($r in $refs) { $args += "/reference:$r" }
    $args += "/resource:$(Join-Path $project 'ui\ManagerWindow.xaml'),Epithete.ManagerWindow.xaml"
    foreach ($s in Get-ChildItem -LiteralPath (Join-Path $project 'src') -Filter '*.cs' -File | Where-Object { $_.Name -ne 'Program.cs' }) { $args += $s.FullName }
    & $csc @args; if ($LASTEXITCODE -ne 0) { throw 'Compilation Manager natif échouée.' }
    Copy-Item (Join-Path $project 'src\app.config') ($exe + '.config') -Force
    Copy-Item (Join-Path $project 'lib\Newtonsoft.Json.dll') $out -Force
    $desktop = Join-Path $project 'desktop-config.json'; if (Test-Path $desktop) { Copy-Item $desktop $out -Force }
    Write-Host "Manager natif compilé : $exe" -ForegroundColor Green
    Write-Host 'Aucune référence ni DLL WebView2 dans le dossier Manager-Native.' -ForegroundColor Green
}
catch { Write-Host "ERREUR : $($_.Exception.Message)" -ForegroundColor Red; exit 1 }
