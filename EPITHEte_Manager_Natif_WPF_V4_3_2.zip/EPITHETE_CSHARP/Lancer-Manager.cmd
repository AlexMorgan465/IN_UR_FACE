@echo off
setlocal
if not exist "%~dp0bin\Manager-Native\EPITHETE-Manager.exe" (echo EXE absent. Lancez Recompiler.cmd. & pause & exit /b 1)
start "EPITHETE Manager natif" "%~dp0bin\Manager-Native\EPITHETE-Manager.exe"
endlocal
