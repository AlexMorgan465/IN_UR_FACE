﻿'use strict';
window.desktop=(()=>{
 const transport=window.chrome?.webview,pending=new Map();let seq=0;
 if(!transport)throw Error('Lancez cet espace avec son EXE ÉPITHÈTE.');
 transport.addEventListener('message',e=>{
  const m=e.data;if(m?.event){if(window.EpitheteProgress)window.EpitheteProgress(m.event,m.value);return;}if(!m||!pending.has(m.id))return;
  const item=pending.get(m.id);pending.delete(m.id);clearTimeout(item.timer);
  if(m.ok)item.resolve(m.result);else item.reject(Error(m.error||'Opération impossible.'));
 });
 function call(command,body={}){
  return new Promise((resolve,reject)=>{
   if(pending.size>=32){reject(Error('Trop d’opérations en attente.'));return;}
   const id=String(++seq),delay=['import','export'].includes(command)?1800000:120000;
   const timer=setTimeout(()=>{pending.delete(id);reject(Error('L’opération n’a pas répondu. Si une écriture est en cours, attendez sa fin avant de réessayer.'));},delay);
   pending.set(id,{resolve,reject,timer});
   try{transport.postMessage({id,command,body});}catch(e){clearTimeout(timer);pending.delete(id);reject(e);}
  });
 }
 async function saveBytes(bytes,name){
  const a=bytes instanceof Uint8Array?bytes:new Uint8Array(bytes);let binary='';
  for(let i=0;i<a.length;i+=32768)binary+=String.fromCharCode(...a.subarray(i,i+32768));
  return saveBase64(btoa(binary),name);
 }
 async function saveBase64(base64,name){
  const result=await call('saveDocument',{base64,name});
  if(result.cancelled){const e=Error('Enregistrement annulé.');e.cancelled=true;throw e;}return result;
 }
 window.addEventListener('DOMContentLoaded',()=>transport.postMessage({command:'ready'}));
 return {call,saveBytes,saveBase64};
})();
