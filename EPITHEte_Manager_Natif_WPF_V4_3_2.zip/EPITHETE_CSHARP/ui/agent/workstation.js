﻿/* Small shared shell: loading feedback, density preference, and keyboard search. */
'use strict';
(()=>{
 const strip=document.createElement('div');strip.className='loading-strip';strip.setAttribute('aria-hidden','true');document.body.prepend(strip);
 const status=$id=>document.getElementById($id);let pending=0;
 const original=window.desktop.call.bind(window.desktop);
 window.desktop.call=async(command,body={})=>{
  const show=!['shutdown','saveDraft','clearDraft'].includes(command);if(show){pending++;strip.classList.add('busy');document.body.setAttribute('aria-busy','true')}
  const started=performance.now();try{const value=await original(command,body);if(command==='state'){
   const el=status('syncStatus');if(el){el.textContent=value.offline?'Hors ligne · copie locale':value.pendingCount?value.pendingCount+' en attente':'À jour · '+new Date().toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'});el.classList.toggle('offline-indicator',!!value.offline);el.title='Lecture : '+Math.round(performance.now()-started)+' ms'}
  }return value}catch(error){if(command==='state'){const el=status('syncStatus');if(el)el.textContent='Connexion à vérifier'}throw error}
  finally{if(show&&--pending===0){strip.classList.remove('busy');document.body.setAttribute('aria-busy','false')}if(command==='state')requestAnimationFrame(()=>document.body.classList.remove('app-booting'))}
 };
 const role=document.body.classList.contains('manager-app')?'manager':'agent',density=status('densityMode');
 const applyDensity=compact=>{document.body.classList.toggle('density-compact',compact);if(density){density.setAttribute('aria-pressed',String(compact));density.textContent=compact?'Vue confortable':'Vue compacte'}};
 try{applyDensity(localStorage.getItem('epithete-density-'+role)==='compact')}catch{applyDensity(false)}
 if(density)density.onclick=()=>{const compact=!document.body.classList.contains('density-compact');applyDensity(compact);try{localStorage.setItem('epithete-density-'+role,compact?'compact':'comfortable')}catch{}};
 document.querySelectorAll('[data-view]').forEach(button=>{button.setAttribute('aria-current',button.classList.contains('active')?'page':'false');button.addEventListener('click',()=>{document.querySelectorAll('[data-view]').forEach(other=>other.setAttribute('aria-current',other===button?'page':'false'))})});
 document.addEventListener('keydown',event=>{if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='k'){const search=role==='agent'?(status('agentHistory').hidden?status('queueSearch'):status('historySearch')):!status('queue').hidden?status('queueSearch'):!status('done').hidden?status('search'):status('scopeAgent');if(search&&search.getClientRects().length){event.preventDefault();search.focus();search.select()}}});
 for(const el of document.querySelectorAll('#message,#syncStatus'))el.setAttribute('role','status');
})();
