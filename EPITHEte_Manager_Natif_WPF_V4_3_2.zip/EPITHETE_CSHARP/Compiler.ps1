﻿[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
try {
    $project = $PSScriptRoot
    if (-not [Environment]::Is64BitOperatingSystem) { throw 'Cette version cible Windows x64.' }
    $release = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -ErrorAction Stop).Release
    if ($release -lt 528040) { throw '.NET Framework 4.8 ou 4.8.1 est requis.' }
    $framework = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
    $csc = Join-Path $framework 'csc.exe'; $wpf = Join-Path $framework 'WPF'
    if (-not (Test-Path -LiteralPath $csc)) { throw 'Compilateur C# Windows introuvable.' }
    $bin = Join-Path $project 'bin'; $agentOut = Join-Path $bin 'Agent-WebView2'; $managerOut = Join-Path $bin 'Manager-Native'
    New-Item -ItemType Directory -Force -Path $agentOut,$managerOut | Out-Null
    $common = @('System.dll','System.Core.dll','System.Numerics.dll','System.Xaml.dll','Microsoft.CSharp.dll') | ForEach-Object { Join-Path $framework $_ }
    $common += @('WindowsBase.dll','PresentationCore.dll','PresentationFramework.dll') | ForEach-Object { Join-Path $wpf $_ }
    $json = Join-Path $project 'lib\Newtonsoft.Json.dll'
    $web = @((Join-Path $project 'lib\Microsoft.Web.WebView2.Core.dll'),(Join-Path $project 'lib\Microsoft.Web.WebView2.Wpf.dll'))
    foreach ($r in ($common + @($json) + $web)) { if (-not (Test-Path -LiteralPath $r)) { throw "Référence manquante : $r" } }
    # Agent: build and dependencies remain the original WebView2 implementation.
    $agentExe = Join-Path $agentOut 'EPITHETE-Agent.exe'
    $agentArgs = @('/nologo','/target:winexe','/platform:x64','/optimize+','/langversion:5','/codepage:65001',"/out:$agentExe", "/win32manifest:$(Join-Path $project 'src\app.manifest')")
    foreach ($r in ($common + @($json) + $web)) { $agentArgs += "/reference:$r" }
    foreach ($f in Get-ChildItem -LiteralPath (Join-Path $project 'ui\agent') -File) { if ($f.Extension -in @('.html','.css','.js')) { $agentArgs += "/resource:$($f.FullName),Epithete.UI.$($f.Name)" } }
    foreach ($s in Get-ChildItem -LiteralPath (Join-Path $project 'src') -Filter '*.cs' -File | Where-Object { $_.Name -ne 'Program.Manager.cs' -and $_.Name -ne 'ManagerWindow.cs' }) { $agentArgs += $s.FullName }
    & $csc @agentArgs; if ($LASTEXITCODE -ne 0) { throw 'Compilation Agent échouée.' }
    Copy-Item (Join-Path $project 'src\app.config') ($agentExe + '.config') -Force
    Copy-Item $json $agentOut -Force; foreach ($r in $web) { Copy-Item $r $agentOut -Force }
    $loader = Join-Path $project 'lib\WebView2Loader.dll'; if (Test-Path $loader) { Copy-Item $loader $agentOut -Force }
    # Manager: native WPF, deliberately no WebView2 assemblies, resources or references.
    $managerExe = Join-Path $managerOut 'EPITHETE-Manager.exe'
    $managerArgs = @('/nologo','/target:winexe','/platform:x64','/optimize+','/langversion:5','/codepage:65001',"/out:$managerExe", "/win32manifest:$(Join-Path $project 'src\app.manifest')")
    foreach ($r in ($common + @($json))) { $managerArgs += "/reference:$r" }
    $managerArgs += "/resource:$(Join-Path $project 'ui\ManagerWindow.xaml'),Epithete.ManagerWindow.xaml"
    foreach ($s in Get-ChildItem -LiteralPath (Join-Path $project 'src') -Filter '*.cs' -File | Where-Object { $_.Name -ne 'Program.cs' }) { $managerArgs += $s.FullName }
    & $csc @managerArgs; if ($LASTEXITCODE -ne 0) { throw 'Compilation Manager natif échouée.' }
    Copy-Item (Join-Path $project 'src\app.config') ($managerExe + '.config') -Force
    Copy-Item $json $managerOut -Force
    $desktop = Join-Path $project 'desktop-config.json'; if (Test-Path $desktop) { Copy-Item $desktop $managerOut -Force; Copy-Item $desktop $agentOut -Force }
    # Remove obsolete root-level executables/dependencies from previous WebView2 builds.
    foreach ($old in @('EPITHETE-Agent.exe','EPITHETE-Agent.exe.config','EPITHETE-Manager.exe','EPITHETE-Manager.exe.config','Microsoft.Web.WebView2.Core.dll','Microsoft.Web.WebView2.Wpf.dll','WebView2Loader.dll','Newtonsoft.Json.dll')) { $p=Join-Path $bin $old; if (Test-Path $p) { Remove-Item $p -Force -ErrorAction SilentlyContinue } }
    Write-Host 'Compilation terminée :' -ForegroundColor Green
    Write-Host "  Manager natif : $managerExe" -ForegroundColor Green
    Write-Host "  Agent WebView2 : $(Join-Path $agentOut 'EPITHETE-Agent.exe')" -ForegroundColor Green
}
catch { Write-Host "ERREUR : $($_.Exception.Message)" -ForegroundColor Red; exit 1 }
