using System;
using System.Windows;
using System.Windows.Threading;
namespace EpitheteDesktop
{
    internal static class Program
    {
        public static readonly bool Manager = true;
        [STAThread]
        private static void Main()
        {
            try
            {
                var app = new Application();
                app.DispatcherUnhandledException += delegate(object s, DispatcherUnhandledExceptionEventArgs e)
                { MessageBox.Show(e.Exception.Message, "ÉPITHÈTE", MessageBoxButton.OK, MessageBoxImage.Error); e.Handled = true; };
                app.Run(new ManagerWindow());
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "ÉPITHÈTE — démarrage impossible", MessageBoxButton.OK, MessageBoxImage.Error); }
        }
    }
}
