﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using D=EpitheteDesktop.JsonData;
namespace EpitheteDesktop
{
    // Local-first Agent transactions. The outbox and materialized rows share one atomic file.
    internal sealed class OfflineAgent
    {
        private readonly FileStore shared;
        private readonly string user, root, statePath, draftPath;
        private readonly bool automatic;
        private readonly object syncGate=new object();
        private bool running,requested,online;
        private string lastError="";
        private DateTime lastAttempt=DateTime.MinValue;
        public OfflineAgent(FileStore shared,string user,string localRoot=null,bool automatic=true)
        {
            this.shared=shared;this.user=user;this.automatic=automatic;
            root=localRoot??Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"EpitheteDesktop","Offline",FileStore.Hash(shared.DirectoryPath.TrimEnd('\\','/').ToUpperInvariant()+"|"+user.ToUpperInvariant()));
            Directory.CreateDirectory(root);statePath=Path.Combine(root,"state.json");draftPath=Path.Combine(root,"drafts.json");
        }
        private T Local<T>(Func<T> work)
        {
            FileStream handle=null;
            for(int i=0;i<100&&handle==null;i++)try{handle=new FileStream(Path.Combine(root,"local.lock"),FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);}catch(IOException){if(i==99)throw new IOException("Le cache local est occupe par une autre instance Agent.");Thread.Sleep(30);}
            using(handle)return work();
        }
        private JObject Load()
        {
            if(!File.Exists(statePath)) {
                if(File.Exists(statePath+".bak"))throw new InvalidDataException("Cache local principal absent. Une sauvegarde existe : "+root+". Ne pas effacer ce dossier.");
                return D.Obj("source",shared.DirectoryPath,"user",user,"initialized",false,"forcedOffline",false,"rows",new JArray(),"pending",new JObject(),"revision",Guid.NewGuid().ToString("N"));
            }
            var value=FileStore.Read(statePath) as JObject;
            if(value==null||!(value["rows"] is JArray)||!(value["pending"] is JObject)||!String.Equals(D.Field(value,"user"),user,StringComparison.OrdinalIgnoreCase)||!String.Equals(D.Field(value,"source"),shared.DirectoryPath,StringComparison.OrdinalIgnoreCase))throw new InvalidDataException("Cache local invalide. Copie conservee sans ecrasement : "+root);
            return value;
        }
        private void Save(JObject value,bool changed=true)
        {
            if(changed)value["revision"]=Guid.NewGuid().ToString("N");
            AtomicFile.Write(statePath,new UTF8Encoding(false).GetBytes(value.ToString(Formatting.None)));
        }
        private JObject Drafts(){if(!File.Exists(draftPath))return new JObject();var value=FileStore.Read(draftPath) as JObject;if(value==null)throw new InvalidDataException("Brouillons locaux invalides : "+draftPath);return value;}
        private void WriteDrafts(JObject value){AtomicFile.Write(draftPath,new UTF8Encoding(false).GetBytes(value.ToString(Formatting.None)));}
        private bool Forced(){return Local(delegate{return (bool?)Load()["forcedOffline"]==true;});}
        public static string Fingerprint(JObject row)
        {
            var fields=new JObject();foreach(string name in new[]{"statut","datePriseEnCharge","dateFin","etatTraitement","dateModification","dmtSecondes","journal"})fields[name]=row[name]==null?JValue.CreateNull():row[name].DeepClone();
            return FileStore.Hash(fields.ToString(Formatting.None));
        }
        public JObject Execute(string command,JObject body)
        {
            body=body??new JObject();
            if(command=="state") {Queue(false);return State(body);}
            if(command=="syncNow") {Queue(true);return State(new JObject());}
            if(command=="offlineMode") {
                Local(delegate{var value=Load();value["forcedOffline"]=(bool?)body["enabled"]==true;Save(value);return true;});
                if(!Forced())Queue(true);return State(new JObject());
            }
            if(command=="saveDraft"||command=="clearDraft")return Local(delegate {
                string id=D.Field(body,"id"),text=D.Field(body,"text");if(text.Length>500)throw new InvalidOperationException("Brouillon limite a 500 caracteres.");
                var value=Load();if(!D.Array(value["rows"]).OfType<JObject>().Any(r=>D.Field(r,"id")==id&&String.Equals(D.Field(r,"agent"),user,StringComparison.OrdinalIgnoreCase)))throw new InvalidOperationException("Dossier absent du cache Agent.");
                var drafts=Drafts();if(command=="clearDraft")drafts.Remove(id);else drafts[id]=D.Obj("text",text,"savedAt",D.Now());WriteDrafts(drafts);return D.Obj("ok",true,"local",true);
            });
            if(!new[]{"start","finish","update"}.Contains(command))throw new InvalidOperationException("Action non autorisee dans l'espace Agent.");
            Local(delegate {
                var value=Load();if((bool?)value["initialized"]!=true)throw new InvalidOperationException("Une premiere connexion est necessaire pour charger les affectations de ce poste.");
                var pending=(JObject)value["pending"];string id=D.Field(body,"id");var previous=pending[id] as JObject;
                var rows=D.Array(value["rows"]).OfType<JObject>().Select(r=>(JObject)r.DeepClone()).ToList();
                var original=rows.FirstOrDefault(r=>D.Field(r,"id")==id);if(original==null)throw new InvalidOperationException("Dossier absent du cache local.");
                string baseline=previous==null?Fingerprint(original):D.Field(previous,"base");
                var row=AgentRules.Apply(rows,user,command,body);string commit=Guid.NewGuid().ToString("N");row["offlineCommitId"]=commit;
                pending[id]=D.Obj("commit",commit,"base",baseline,"row",row,"queuedAt",D.Now());if(previous!=null&&previous["conflict"]!=null){pending[id]["conflict"]=previous["conflict"].DeepClone();if(previous["remote"]!=null)pending[id]["remote"]=previous["remote"].DeepClone();}value["rows"]=new JArray(rows);Save(value);
                return true;
            });
            // Acknowledgement means the row AND its outbox entry are already flushed locally.
            try{Local(delegate{var drafts=Drafts();if(drafts.Remove(D.Field(body,"id")))WriteDrafts(drafts);return true;});}catch(IOException){/* A stale draft is harmless; keep the committed operation. */}
            Queue(true);return D.Obj("ok",true,"local",true,"message","Traitement enregistre sur ce poste. Synchronisation en attente.");
        }
        private JObject State(JObject body)
        {
            return Local(delegate {
                var value=Load();var pending=(JObject)value["pending"];var conflicts=new JArray(pending.Properties().Where(p=>!String.IsNullOrEmpty(D.Field((JObject)p.Value,"conflict"))).Select(p=>D.Obj("id",p.Name,"numeroFacture",D.Field((JObject)p.Value["row"],"numeroFacture"),"reason",D.Field((JObject)p.Value,"conflict"))));
                bool isOnline,isRunning;string error;lock(syncGate){isOnline=online;isRunning=running;error=lastError;}
                bool forced=(bool?)value["forcedOffline"]==true;var info=new FileInfo(draftPath);
                string revision=FileStore.Hash(D.Field(value,"revision")+"|"+(info.Exists?info.LastWriteTimeUtc.Ticks.ToString():"none")+"|"+isOnline+"|"+forced+"|"+pending.Count+"|"+error);
                var response=D.Obj("application","EPITHETE AGENT","version","CSharp-4.2","collaborateur",user,"dataDirectory",shared.DirectoryPath,"localDirectory",root,"revision",revision,"offline",forced||!isOnline,"forcedOffline",forced,"syncing",isRunning,"pendingCount",pending.Count,"conflicts",conflicts,"lastError",error,"lastSync",value["lastSync"],"cacheAvailable",(bool?)value["initialized"]==true,"actualiseLe",D.Now());
                if(D.Field(body,"revision")==revision){response["unchanged"]=true;return response;}
                response["traitements"]=value["rows"].DeepClone();foreach(var row in ((JArray)response["traitements"]).OfType<JObject>())row.Remove("journal");response["drafts"]=Drafts();return response;
            });
        }
        private void Queue(bool immediate)
        {
            if(!automatic||Forced())return;
            lock(syncGate){if(running){if(immediate)requested=true;return;}if(!immediate&&DateTime.UtcNow-lastAttempt<TimeSpan.FromSeconds(5))return;running=true;requested=false;lastAttempt=DateTime.UtcNow;}
            System.Threading.Tasks.Task.Run(delegate {
                while(true){Synchronize();lock(syncGate){if(requested){requested=false;continue;}running=false;return;}}
            });
        }
        public void Synchronize()
        {
            try {
                if(Forced())return;
                var snapshot=Local(delegate{return (JObject)((JObject)Load()["pending"]).DeepClone();});
                List<JObject> remote=null;
                shared.AgentLocked(user,delegate {
                    // Directory failures and damaged remote JSON never change the durable local cache.
                    remote=shared.ReadRecords(true,user);
                    foreach(var item in snapshot.Properties()) {
                        if(Forced())return false;
                        var operation=(JObject)item.Value;var desired=(JObject)operation["row"];string id=item.Name,commit=D.Field(operation,"commit");
                        var current=remote.FirstOrDefault(r=>D.Field(r,"id")==id);string conflict="";
                        bool acknowledged=current!=null&&D.Field(current,"offlineCommitId")==commit&&Fingerprint(current)==Fingerprint(desired);
                        if(current==null||!String.Equals(D.Field(current,"agent"),user,StringComparison.OrdinalIgnoreCase))conflict="Dossier supprime ou reaffecte depuis la derniere connexion.";
                        else if(!acknowledged&&Fingerprint(current)!=D.Field(operation,"base"))conflict="Le traitement partage a ete modifie ailleurs. Les deux versions sont conservees.";
                        else if(!acknowledged&&!String.IsNullOrEmpty(D.Field(desired,"datePriseEnCharge"))&&String.IsNullOrEmpty(D.Field(desired,"dateFin"))&&remote.Any(r=>D.Field(r,"id")!=id&&!String.IsNullOrEmpty(D.Field(r,"datePriseEnCharge"))&&String.IsNullOrEmpty(D.Field(r,"dateFin"))))conflict="Un autre dossier est deja en cours sur le partage.";
                        if(conflict.Length>0) {
                            string reason=conflict;Local(delegate{var value=Load();var latest=((JObject)value["pending"])[id] as JObject;if(latest!=null){latest["conflict"]=reason;latest["remote"]=current==null?JValue.CreateNull():current.DeepClone();Save(value);}return true;});continue;
                        }
                        if(!acknowledged) {
                            foreach(string field in new[]{"statut","datePriseEnCharge","dateFin","etatTraitement","dateModification","dmtSecondes","dateExport","journal","offlineCommitId"}) {
                                if(desired[field]==null)current.Remove(field);else current[field]=desired[field].DeepClone();
                            }
                            shared.SaveTreatment(current);
                        }
                        string accepted=Fingerprint(current);
                        Local(delegate {
                            var value=Load();var pending=(JObject)value["pending"];var latest=pending[id] as JObject;
                            if(latest!=null) {if(D.Field(latest,"commit")==commit)pending.Remove(id);else {latest["base"]=accepted;latest.Remove("conflict");latest.Remove("remote");}Save(value);}
                            return true;
                        });
                    }
                    return true;
                });
                // Merge only after all reads/writes succeeded. Pending local rows always win in the local view.
                Local(delegate {
                    var value=Load();var pending=(JObject)value["pending"];var merged=(remote??new List<JObject>()).Select(r=>(JObject)r.DeepClone()).ToList();
                    foreach(var item in pending.Properties()){merged.RemoveAll(r=>D.Field(r,"id")==item.Name);merged.Add((JObject)item.Value["row"].DeepClone());}
                    var array=new JArray(merged);bool changed=!JToken.DeepEquals(value["rows"],array)||(bool?)value["initialized"]!=true;
                    value["rows"]=array;value["initialized"]=true;value["lastSync"]=D.Now();Save(value,changed);return true;
                });
                lock(syncGate){online=true;lastError="";}
            }
            catch(Exception error){lock(syncGate){online=false;lastError=error.Message;}}
        }
    }
}
