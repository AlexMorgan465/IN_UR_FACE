﻿using System;
namespace EpitheteDesktop
{
    internal static class ImmediateExit
    {
        public static void Run() { Environment.Exit(0); }
    }
}
