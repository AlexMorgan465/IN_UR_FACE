﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using Newtonsoft.Json.Linq;
using D = EpitheteDesktop.JsonData;

namespace EpitheteDesktop
{
    internal sealed class ExcelFiles : IExcelFiles
    {
        public Action<JObject> Progress;
        private void Report(string file,string sheet,int row,int total) { if(Progress!=null)Progress(D.Obj("file",file,"sheet",sheet,"row",row,"total",total)); }
        private static void Release(object value) { if (value != null && Marshal.IsComObject(value)) Marshal.FinalReleaseComObject(value); }
        private sealed class ExcelSession : IDisposable
        {
            public dynamic App;
            public dynamic Books;
            public ExcelSession()
            {
                Type type = Type.GetTypeFromProgID("Excel.Application");
                if (type == null) throw new InvalidOperationException("Excel de bureau doit etre installe pour l'import/export, comme dans la version PowerShell.");
                try
                {
                    App = Activator.CreateInstance(type); App.Visible = false; App.DisplayAlerts = false;
                    // Restriction des macros sur cette instance uniquement, jamais de modification globale.
                    App.AutomationSecurity = 3; App.AskToUpdateLinks = false; Books = App.Workbooks;
                }
                catch { Dispose(); throw; }
            }
            public dynamic Open(string path, bool readOnly) { return Books.Open(path, 0, readOnly); }
            public void Dispose()
            {
                try { if (App != null) App.Quit(); }
                finally { Release((object)Books); Release((object)App); Books = null; App = null; }
            }
        }
        private sealed class Sheet : IDisposable
        {
            public dynamic Native;
            private dynamic cells;
            private string name;
            private readonly Dictionary<int,string> formats=new Dictionary<int,string>();
            private Array values;
            private object single;
            private int firstRow,firstColumn,lastRow,lastColumn;
            private readonly Dictionary<string,JObject> display=new Dictionary<string,JObject>();
            public Sheet(object sheet)
            {
                Native=sheet; cells=Native.Cells; name=Convert.ToString(Native.Name,CultureInfo.InvariantCulture); dynamic used=null,rows=null,columns=null;
                try
                {
                    used=Native.UsedRange;rows=used.Rows;columns=used.Columns;
                    firstRow=(int)used.Row;firstColumn=(int)used.Column;
                    lastRow=firstRow+(int)rows.Count-1;lastColumn=firstColumn+(int)columns.Count-1;
                    if((long)(lastRow-firstRow+1)*(lastColumn-firstColumn+1)>2000000)throw new InvalidOperationException("Zone Excel trop grande. Nettoyez les lignes/colonnes inutilisees du classeur.");
                    object data=used.Value2;values=data as Array;single=values==null?data:null;
                }
                catch {Release((object)cells);Release((object)Native);throw;}
                finally {Release((object)columns);Release((object)rows);Release((object)used);}
            }
            private object Raw(int row,int col)
            {
                if(row<firstRow || col<firstColumn || row>lastRow || col>lastColumn)return null;
                return values==null?single:values.GetValue(row-firstRow+values.GetLowerBound(0),col-firstColumn+values.GetLowerBound(1));
            }
            public string Name { get { return name; } }
            public JObject ReadCell(int row, int col, string label)
            {
                object raw=Raw(row,col);string text=Convert.ToString(raw,CultureInfo.InvariantCulture).Trim(),format="General";
                // Text values are already available from the bulk snapshot. Numeric display is read
                // only when needed, preserving invoice zeroes, Excel dates and formatted amounts.
                if(raw!=null && !(raw is string) && !(raw is bool))
                {
                    if(!formats.TryGetValue(col,out format))
                    {
                        dynamic allColumns=null,column=null;
                        try {allColumns=Native.Columns;column=allColumns.Item(col);object f=column.NumberFormat;format=f==null?null:Convert.ToString(f,CultureInfo.InvariantCulture);formats[col]=format;}
                        finally {Release((object)column);Release((object)allColumns);}
                    }
                    if(format=="General" || format=="@")return D.Obj("column",col,"label",label,"text",text,"value",raw,"numberFormat",format);
                    if(format!=null && System.Text.RegularExpressions.Regex.IsMatch(format,@"^0+$"))
                    {
                        text=Convert.ToDouble(raw,CultureInfo.InvariantCulture).ToString(format,CultureInfo.InvariantCulture);
                        return D.Obj("column",col,"label",label,"text",text,"value",raw,"numberFormat",format);
                    }
                    string key=row+":"+col;JObject cached;
                    if(!display.TryGetValue(key,out cached))
                    {
                        dynamic cell=cells.Item(row,col);
                        try { cached=D.Obj("text",Convert.ToString(cell.Text,CultureInfo.InvariantCulture).Trim(),"format",Convert.ToString(cell.NumberFormat,CultureInfo.InvariantCulture));display[key]=cached; }
                        finally {Release((object)cell);}
                    }
                    text=D.Field(cached,"text");format=D.Field(cached,"format");
                }
                return D.Obj("column",col,"label",label,"text",text,"value",raw,"numberFormat",format);
            }
            public string Text(int row,int col) { return D.Field(ReadCell(row,col,""),"text"); }
            public void SetText(int row, int col, string value)
            {
                dynamic cell = cells.Item(row, col);
                try { cell.NumberFormat = "@"; cell.Value2 = value; }
                finally { Release((object)cell); }
            }
            public int[] Bounds() { return new[] {lastRow,lastColumn}; }
            public void Dispose() { Release((object)cells); Release((object)Native); cells = null; Native = null; }
        }
        private sealed class Header
        {
            public int Row, LastRow, LastCol, Number, Motif, State;
            public readonly List<KeyValuePair<int, string>> Columns = new List<KeyValuePair<int, string>>();
        }
        private static Header FindHeader(Sheet sheet)
        {
            int[] bounds = sheet.Bounds();
            for (int r = 1; r <= Math.Min(bounds[0], 60); r++)
            {
                var h = new Header { Row = r, LastRow = bounds[0], LastCol = bounds[1] };
                for (int c = 1; c <= bounds[1]; c++)
                {
                    string label = sheet.Text(r, c), normalized = D.Normalize(label);
                    h.Columns.Add(new KeyValuePair<int, string>(c, label));
                    if (new[] { "numero", "numero de facture", "n° facture", "n° de facture" }.Contains(normalized)) h.Number = c;
                    if (normalized == "code motif" || (normalized == "motif" && h.Motif == 0)) h.Motif = c;
                    if (System.Text.RegularExpressions.Regex.IsMatch(normalized, @"^etat (du |de )?traitement")) h.State = c;
                }
                if (h.Number > 0) return h;
            }
            return null;
        }
        private sealed class Candidate { public int Index; public Header Header; }
        private static string Fingerprint(string path)
        { using(var stream=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read)) using(var hash=System.Security.Cryptography.SHA256.Create()) return BitConverter.ToString(hash.ComputeHash(stream)).Replace("-",""); }
        public ScanResult Scan(string directory, string user, JObject importedFiles)
        {
            if (!Directory.Exists(directory)) throw new DirectoryNotFoundException("Dossier source introuvable : " + directory);
            string[] files = Directory.GetFiles(directory).Where(f => new[] { ".xlsx", ".xlsm", ".xls" }.Contains(Path.GetExtension(f).ToLowerInvariant()) && !Path.GetFileName(f).StartsWith("~$")).OrderBy(f => f).ToArray();
            if (files.Length == 0) throw new InvalidOperationException("Aucun fichier Excel trouve dans le dossier source.");
            var result = new ScanResult { Files = files.Length };
            var pendingFiles=new List<string>();var hashes=new Dictionary<string,string>();
            foreach(string path in files)
                try { Report(Path.GetFileName(path),"Vérification du fichier",0,0);string hash=Fingerprint(path);if(D.Text(importedFiles[Path.GetFullPath(path).ToUpperInvariant()])==hash)result.Skipped++;else {pendingFiles.Add(path);hashes[path]=hash;} }
                catch(Exception ex) {result.Errors.Add(Path.GetFileName(path)+" : "+ex.Message);}
            if(pendingFiles.Count==0)return result;
            using (var excel = new ExcelSession())
                foreach (string file in pendingFiles)
                {
                    string fingerprint=hashes[file];Report(Path.GetFileName(file),"Ouverture du classeur",0,0);
                    int errorCount=result.Errors.Count, rowStart=result.Rows.Count;
                    dynamic book = null, sheets = null;
                    try
                    {
                        book = excel.Open(file, true); sheets = book.Worksheets;
                        var candidates = new List<Candidate>();
                        for (int i = 1; i <= (int)sheets.Count; i++)
                            using (var sheet = new Sheet(sheets.Item(i)))
                            { Header h = FindHeader(sheet); if (h != null) candidates.Add(new Candidate { Index = i, Header = h }); }
                        if (candidates.Count == 0) { result.Errors.Add("En-tete Numero introuvable dans " + Path.GetFileName(file)); continue; }
                        
                        foreach (Candidate candidate in candidates.OrderByDescending(c => (c.Header.Motif > 0 ? 1 : 0) + (c.Header.State > 0 ? 1 : 0)))
                            using (var sheet = new Sheet(sheets.Item(candidate.Index)))
                            {
                                Header h = candidate.Header;
                                for (int r = h.Row + 1; r <= h.LastRow; r++)
                                {
                                    if((r-h.Row)%200==1)Report(Path.GetFileName(file),sheet.Name,r-h.Row,h.LastRow-h.Row);
                                    string number = sheet.Text(r, h.Number);
                                    if (number.Length == 0) continue;

                                    var cells = new JArray(); string client = "", type = "", motif = "", state = "";
                                    foreach (var column in h.Columns.Where(c => c.Value.Length > 0))
                                    {
                                        JObject cell = sheet.ReadCell(r, column.Key, column.Value); cells.Add(cell);
                                        string label = D.Normalize(column.Value), display = D.Field(cell, "text");
                                        if (label == "client") client = display;
                                        if (label == "type de document") type = display;
                                        if (column.Key == h.Motif) motif = display;
                                        if (column.Key == h.State) state = display;
                                    }
                                    string now = D.Now();
                                    result.Rows.Add(D.Obj("id", Guid.NewGuid().ToString(), "schema", "factures-v2", "sourceKey", file + "|FACTURE|" + number,
                                        "sourceFile", Path.GetFileName(file), "sourcePath", Path.GetFullPath(file), "sourceSheet", sheet.Name, "sourceRow", r,
                                        "sourceHeaderRow", h.Row, "sourceValues", cells, "numeroFacture", number, "raisonSociale", client, "siret", "", "typeFacture", type,
                                        "dateLimite", "", "motif", motif, "etatTraitement", state, "agent", "", "statut", "À affecter", "dateImport", now,
                                        "dateAffectation", null, "datePriseEnCharge", null, "dateFin", null, "dmtSecondes", null,
                                        "journal", new JArray(D.Obj("date", now, "auteur", user, "action", "Import facture", "detail", Path.GetFileName(file))), "_hasSourceMotif", h.Motif > 0));
                                }
                            }
                    }
                    catch (Exception ex) { result.Errors.Add(Path.GetFileName(file) + " : " + ex.Message); }

                    finally
                    {
                        try { if (book != null) book.Close(false); }
                        finally { Release((object)sheets); Release((object)book); }
                    }
                    if(result.Errors.Count==errorCount && fingerprint==Fingerprint(file)) result.Fingerprints[Path.GetFullPath(file).ToUpperInvariant()]=fingerprint;
                    else { result.Rows.RemoveRange(rowStart,result.Rows.Count-rowStart); if(result.Errors.Count==errorCount) result.Errors.Add("Fichier modifie pendant l'import : " + file); }
                }
            return result;
        }
        public ExportResult Export(List<JObject> rows)
        {
            var result = new ExportResult();
            using (var excel = new ExcelSession())
                foreach (var group in rows.GroupBy(r => D.Field(r, "sourcePath"), StringComparer.OrdinalIgnoreCase))
                {
                    string file = group.Key;
                    if (!File.Exists(file)) { result.Errors.Add("Fichier introuvable : " + file); continue; }
                    dynamic book = null, sheets = null;
                    try
                    {
                        book = excel.Open(file, false);
                        if ((bool)book.ReadOnly) throw new IOException("Fichier ouvert en lecture seule. Fermez-le dans Excel avant de reessayer.");
                        sheets = book.Worksheets;
                        var pending = new List<JObject>(); bool backedUp = false;
                        foreach (var sheetGroup in group.GroupBy(r => D.Field(r, "sourceSheet"), StringComparer.OrdinalIgnoreCase))
                        {
                            object native = null;
                            try { native = sheets.Item(sheetGroup.Key); }
                            catch { result.Errors.Add("Feuille introuvable : " + sheetGroup.Key); continue; }
                            using (var sheet = new Sheet(native))
                            {
                                Header h = FindHeader(sheet);
                                if (h == null) { result.Errors.Add("En-tete Numero introuvable : " + sheetGroup.Key); continue; }
                                var targets = new Dictionary<string, List<int>>(StringComparer.OrdinalIgnoreCase);
                                for (int r = h.Row + 1; r <= h.LastRow; r++)
                                {
                                    string num = sheet.Text(r, h.Number); if (num.Length == 0) continue;
                                    if (!targets.ContainsKey(num)) targets[num] = new List<int>(); targets[num].Add(r);
                                }
                                var valid = new List<JObject>();
                                foreach (JObject row in sheetGroup)
                                {
                                    List<int> positions; string number = D.Field(row, "numeroFacture").Trim();
                                    if (!targets.TryGetValue(number, out positions) || positions.Count == 0)
                                    { result.Errors.Add("Facture " + number + " absente ou presente plusieurs fois dans " + sheetGroup.Key + ". Aucun ecrasement."); continue; }
                                    int sourceRow=(int?)row["sourceRow"] ?? 0;
                                    if(positions.Count>1 && !positions.Contains(sourceRow)) { result.Errors.Add("Facture ambigue : " + number); continue; }
                                    row["_exportRow"] = positions.Count==1?positions[0]:sourceRow;
                                    if(valid.Any(v=>(int)v["_exportRow"]==(int)row["_exportRow"])) { result.Errors.Add("Plusieurs traitements ciblent la meme cellule : " + number); valid.RemoveAll(v=>(int)v["_exportRow"]==(int)row["_exportRow"]); continue; }
                                    valid.Add(row);
                                }
                                if (valid.Count == 0) continue;
                                if (!backedUp)
                                {
                                    string backups = Path.Combine(Path.GetDirectoryName(file), "Sauvegardes_EPITHETE"); Directory.CreateDirectory(backups);
                                    string backup = Path.Combine(backups, Path.GetFileNameWithoutExtension(file) + "." + DateTime.Now.ToString("yyyyMMdd-HHmmss-fff") + "." + Guid.NewGuid().ToString("N").Substring(0, 8) + Path.GetExtension(file));
                                    File.Copy(file, backup, false); backedUp = true;
                                }
                                if (h.State == 0) { h.State = h.LastCol + 1; sheet.SetText(h.Row, h.State, "Etat du traitement ( noter Traité)"); }
                                foreach (JObject row in valid)
                                { sheet.SetText((int)row["_exportRow"], h.State, D.Field(row, "etatTraitement")); pending.Add(row); }
                            }
                        }
                        if (pending.Count > 0) { book.Save(); result.Files++; result.Saved.AddRange(pending); }
                    }
                    catch (Exception ex) { result.Errors.Add("Impossible d'enregistrer " + Path.GetFileName(file) + " : " + ex.Message); }
                    finally
                    {
                        try { if (book != null) book.Close(false); }
                        finally { Release((object)sheets); Release((object)book); }
                    }
                }
            return result;
        }
    }
}
