﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using Microsoft.Win32;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using D = EpitheteDesktop.JsonData;

namespace EpitheteDesktop
{
    public sealed class ManagerRow
    {
        public string Id { get; set; } public string Numero { get; set; } public string Client { get; set; }
        public string Type { get; set; } public string Motif { get; set; } public string Source { get; set; }
        public string Agent { get; set; } public string Statut { get; set; } public string DateAffectation { get; set; }
        public string DateFin { get; set; } public string Etat { get; set; } public string Dmt { get; set; }
        public string Export { get; set; } public string Original { get; set; } public string Decision { get; set; }
        public string Date { get; set; } public string User { get; set; } public string Files { get; set; }
        public string Added { get; set; } public string Duplicates { get; set; } public string Skipped { get; set; }
    }
    public sealed class CdoRow
    {
        public string Period { get; set; } public string Refused { get; set; } public string Litigation { get; set; }
        public string Task { get; set; } public string Escalation { get; set; } public string Statu { get; set; }
        public string Agents { get; set; } public string DmtHours { get; set; } public string ProductionHours { get; set; }
    }
    internal sealed class KpiBucket
    {
        public int refused, litigation, task, escalation, statu, unknown, other, timed, missing;
        public double seconds; public HashSet<string> agents = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
    }

    internal sealed class ManagerWindow : Window
    {
        private readonly StaWorker worker = new StaWorker();
        private InvoiceService service;
        private FileStore store;
        private JObject state, ledger;
        private readonly ObservableCollection<ManagerRow> queueRows = new ObservableCollection<ManagerRow>();
        private readonly ObservableCollection<ManagerRow> assignedRows = new ObservableCollection<ManagerRow>();
        private readonly ObservableCollection<ManagerRow> doneRows = new ObservableCollection<ManagerRow>();
        private readonly ObservableCollection<ManagerRow> importRows = new ObservableCollection<ManagerRow>();
        private readonly ObservableCollection<ManagerRow> duplicateRows = new ObservableCollection<ManagerRow>();
        private UserControl root;
        private bool busy;

        public ManagerWindow()
        {
            Title = "ÉPITHÈTE · ETAFAC — Manager natif V4.3.2";
            Width = 1480; Height = 920; MinWidth = 1050; MinHeight = 680;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Epithete.ManagerWindow.xaml"))
            {
                if (stream == null) throw new InvalidOperationException("Ressource XAML du Manager introuvable.");
                root = XamlReader.Load(stream) as UserControl;
            }
            if (root == null) throw new InvalidDataException("La fenêtre XAML du Manager est invalide.");
            Content = root;
            BindGrids(); WireEvents();
            Loaded += async delegate { await Initialize(); };
            Closed += delegate { worker.Dispose(); };
        }

        private T Get<T>(string name) where T : class { T item = root.FindName(name) as T; if (item == null) throw new InvalidOperationException("Contrôle XAML introuvable : " + name); return item; }
        private static string DataDirectory()
        {
            string config = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "desktop-config.json");
            if (!File.Exists(config)) config = Path.Combine(Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar)), "desktop-config.json");
            if (!File.Exists(config)) return FileStore.DefaultDataDirectory;
            JObject value = FileStore.Read(config) as JObject; string directory = value == null ? "" : D.Field(value, "dataDirectory");
            if (String.IsNullOrWhiteSpace(directory)) throw new InvalidDataException("desktop-config.json : dataDirectory obligatoire.");
            return Path.IsPathRooted(directory) ? directory : Path.GetFullPath(Path.Combine(Path.GetDirectoryName(config), directory));
        }
        private void BindGrids()
        {
            Get<DataGrid>("QueueGrid").ItemsSource = queueRows; Get<DataGrid>("AssignedGrid").ItemsSource = assignedRows;
            Get<DataGrid>("DoneGrid").ItemsSource = doneRows; Get<DataGrid>("ImportGrid").ItemsSource = importRows;
            Get<DataGrid>("DuplicateGrid").ItemsSource = duplicateRows;
        }
        private void WireEvents()
        {
            Get<Button>("RefreshButton").Click += async delegate { await Refresh(); };
            Get<Button>("QuitButton").Click += delegate { Close(); };
            Get<Button>("ResetFilters").Click += delegate { Get<TextBox>("SearchBox").Clear(); Get<ComboBox>("YearFilter").SelectedIndex = 0; Get<ComboBox>("MonthFilter").SelectedIndex = 0; Get<ComboBox>("StatusFilter").SelectedIndex = 0; ApplyFilters(); };
            Get<TextBox>("SearchBox").TextChanged += delegate { ApplyFilters(); };
            Get<ComboBox>("YearFilter").SelectionChanged += delegate { ApplyFilters(); };
            Get<ComboBox>("MonthFilter").SelectionChanged += delegate { ApplyFilters(); };
            Get<ComboBox>("StatusFilter").SelectionChanged += delegate { ApplyFilters(); };
            Get<Button>("SelectAllQueue").Click += delegate { Get<DataGrid>("QueueGrid").SelectAll(); };
            Get<Button>("AssignButton").Click += async delegate { await AssignSelected(); };
            Get<Button>("AddAgentButton").Click += async delegate { await AddAgent(); };
            Get<Button>("ExportButton").Click += async delegate { await Export(); };
            Get<Button>("ImportButton").Click += async delegate { await Import(); };
            Get<Button>("AcceptDuplicates").Click += async delegate { await DecideDuplicates("accept"); };
            Get<Button>("RejectDuplicates").Click += async delegate { await DecideDuplicates("reject"); };
            Get<Button>("SaveSourceDirectory").Click += async delegate { await SaveSource(); };
            Get<Button>("SaveDataDirectory").Click += delegate { SaveDataPath(); };
            Get<Button>("MaintenanceButton").Click += async delegate { await Maintenance(); };
            Get<ComboBox>("KpiGroup").SelectionChanged += delegate { if(state!=null) RenderKpisAndCharts(); };
            Get<Button>("SaveManualKpi").Click += async delegate { await SaveManualKpi(false); };
            Get<Button>("ResetManualKpi").Click += async delegate { await SaveManualKpi(true); };
            Get<ComboBox>("ManualPeriod").SelectionChanged += delegate { if(state!=null) FillManualKpi(); };
        }
        private void BindExcelProgress(ExcelFiles excel)
        {
            excel.Progress = delegate(JObject p) { Dispatcher.BeginInvoke(new Action(delegate { Get<TextBlock>("ImportStatus").Text = "Lecture : " + D.Field(p,"file") + " · " + D.Field(p,"sheet") + " · ligne " + D.Field(p,"row") + "/" + D.Field(p,"total"); })); };
        }
        private async Task Initialize()
        {
            try
            {
                store = new FileStore(DataDirectory()); var excel = new ExcelFiles(); BindExcelProgress(excel);
                service = new InvoiceService(store, true, Environment.UserName, excel);
                Get<TextBox>("DataDirectoryBox").Text = store.DirectoryPath;
                await Refresh();
            }
            catch (Exception ex) { SetStatus("Erreur au démarrage : " + ex.Message, true); }
        }
        private void SetStatus(string message, bool error)
        {
            Get<TextBlock>("FooterStatus").Text = message;
            Get<TextBlock>("ConnectionStatus").Text = error ? "Erreur" : "Manager natif connecté";
            Get<TextBlock>("ConnectionStatus").Foreground = error ? System.Windows.Media.Brushes.Firebrick : System.Windows.Media.Brushes.SeaGreen;
        }
        private async Task<JObject> Execute(string command, JObject body)
        {
            if (service == null) throw new InvalidOperationException("Le service Manager n'est pas initialisé.");
            return await worker.Run(delegate { return service.Execute(command, body); });
        }
        private async Task Refresh()
        {
            if (busy || service == null) return; busy = true;
            try
            {
                state = await Execute("state", null); ledger = await Execute("ledger", null);
                JObject cfg = state["config"] as JObject; if (cfg != null && !Get<TextBox>("SourceDirectoryBox").IsFocused) Get<TextBox>("SourceDirectoryBox").Text = D.Field(cfg,"sourceDirectory");
                PopulateFilters(); Render(); SetStatus("Données actualisées · " + D.Array(state["traitements"]).Count + " lignes", false);
            }
            catch (Exception ex) { SetStatus("Actualisation impossible : " + ex.Message, true); }
            finally { busy = false; }
        }
        private void PopulateFilters()
        {
            var years = new SortedSet<string>(); var months = new SortedSet<string>();
            foreach (JObject r in D.Array(state["traitements"]).OfType<JObject>())
            {
                DateTime dt; string date = First(r,"dateFin","dateAffectation","dateImport");
                if (DateTime.TryParse(date, CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal, out dt)) { years.Add(dt.Year.ToString()); months.Add(dt.Month.ToString("00")); }
            }
            ComboBox y = Get<ComboBox>("YearFilter"), m = Get<ComboBox>("MonthFilter"); string oldY = Selected(y), oldM = Selected(m);
            y.Items.Clear(); y.Items.Add("Toutes"); foreach (string v in years) y.Items.Add(v); y.SelectedItem = years.Contains(oldY) ? oldY : "Toutes";
            m.Items.Clear(); m.Items.Add("Tous"); foreach (string v in months) m.Items.Add(v); m.SelectedItem = months.Contains(oldM) ? oldM : "Tous";
        }
        private static string Selected(ComboBox combo) { if (combo.SelectedItem == null) return ""; ComboBoxItem item = combo.SelectedItem as ComboBoxItem; return item == null ? Convert.ToString(combo.SelectedItem) : Convert.ToString(item.Content); }
        private void ApplyFilters() { if (state != null) Render(); }
        private static string First(JObject r, params string[] keys) { foreach (string k in keys) if (!String.IsNullOrEmpty(D.Field(r,k))) return D.Field(r,k); return ""; }
        private static string FormatDate(string value) { DateTime dt; return DateTime.TryParse(value,CultureInfo.InvariantCulture,DateTimeStyles.AssumeLocal,out dt) ? dt.ToLocalTime().ToString("dd/MM/yyyy HH:mm") : value; }
        private static string Duration(JObject r) { double sec; return Double.TryParse(D.Field(r,"dmtSecondes"),NumberStyles.Any,CultureInfo.InvariantCulture,out sec) ? TimeSpan.FromSeconds(Math.Max(0,sec)).ToString(@"hh\:mm\:ss") : "—"; }
        private static string SourceMotif(JObject r)
        {
            foreach (JObject cell in D.Array(r["sourceValues"]).OfType<JObject>())
            { string label = D.Normalize(D.Field(cell,"label")); if ((label=="code motif" || label=="motif") && !String.IsNullOrWhiteSpace(D.Field(cell,"text"))) return D.Field(cell,"text"); }
            return First(r,"motif","etatTraitement");
        }
        private ManagerRow MapRow(JObject r)
        {
            return new ManagerRow { Id=D.Field(r,"id"), Numero=First(r,"numeroFacture"), Client=First(r,"raisonSociale"), Type=First(r,"typeFacture"), Motif=SourceMotif(r), Source=First(r,"sourceFile"), Agent=First(r,"agent"), Statut=First(r,"statut","etatTraitement"), DateAffectation=FormatDate(D.Field(r,"dateAffectation")), DateFin=FormatDate(D.Field(r,"dateFin")), Etat=First(r,"etatTraitement"), Dmt=Duration(r), Export=String.IsNullOrEmpty(D.Field(r,"dateExport")) ? "En attente" : "Exporté" };
        }
        private bool InFilter(JObject r)
        {
            string search = Get<TextBox>("SearchBox").Text.Trim(); string year = Selected(Get<ComboBox>("YearFilter")); string month = Selected(Get<ComboBox>("MonthFilter")); string status = Selected(Get<ComboBox>("StatusFilter"));
            string hay = String.Join(" ", new[]{D.Field(r,"numeroFacture"),D.Field(r,"raisonSociale"),D.Field(r,"sourceFile"),D.Field(r,"agent"),SourceMotif(r),D.Field(r,"etatTraitement")}).ToLowerInvariant();
            if (search.Length>0 && hay.IndexOf(search,StringComparison.OrdinalIgnoreCase)<0) return false;
            DateTime dt; string date=First(r,"dateFin","dateAffectation","dateImport");
            if ((year!="Toutes" || month!="Tous") && (!DateTime.TryParse(date,CultureInfo.InvariantCulture,DateTimeStyles.AssumeLocal,out dt) || (year!="Toutes" && dt.Year.ToString()!=year) || (month!="Tous" && dt.Month.ToString("00")!=month))) return false;
            bool noAgent=String.IsNullOrEmpty(D.Field(r,"agent")), done=!String.IsNullOrEmpty(D.Field(r,"dateFin"));
            if (status=="À affecter" && (!noAgent || done)) return false;
            if (status=="Affecté" && (noAgent || done || !String.IsNullOrEmpty(D.Field(r,"datePriseEnCharge")))) return false;
            if (status=="En cours" && (noAgent || done)) return false;
            if (status=="Terminé" && !done) return false;
            return true;
        }
        private List<JObject> Filtered()
        { return D.Array(state==null?null:state["traitements"]).OfType<JObject>().Where(InFilter).ToList(); }
        private void Render()
        {
            List<JObject> rows=Filtered(); queueRows.Clear(); assignedRows.Clear(); doneRows.Clear();
            foreach(JObject r in rows)
            {
                bool unassigned=String.IsNullOrEmpty(D.Field(r,"agent")) && String.IsNullOrEmpty(D.Field(r,"dateFin"));
                bool done=!String.IsNullOrEmpty(D.Field(r,"dateFin"));
                if(unassigned) queueRows.Add(MapRow(r)); else if(done) doneRows.Add(MapRow(r)); else assignedRows.Add(MapRow(r));
            }
            Get<TextBlock>("QueueCount").Text=queueRows.Count+" ligne(s)"; Get<TextBlock>("DoneCount").Text=doneRows.Count+" ligne(s)";
            int total=rows.Count, active=assignedRows.Count, doneCount=doneRows.Count;
            Get<TextBlock>("KpiTotal").Text=total.ToString("N0"); Get<TextBlock>("KpiQueue").Text=queueRows.Count.ToString("N0"); Get<TextBlock>("KpiActive").Text=active.ToString("N0"); Get<TextBlock>("KpiDone").Text=doneCount.ToString("N0");
            double[] durations=rows.Where(r=>!String.IsNullOrEmpty(D.Field(r,"dateFin"))).Select(r=>{double v;return Double.TryParse(D.Field(r,"dmtSecondes"),NumberStyles.Any,CultureInfo.InvariantCulture,out v)?v:-1;}).Where(v=>v>=0).ToArray();
            Get<TextBlock>("KpiDmt").Text=durations.Length==0?"—":TimeSpan.FromSeconds(durations.Average()).ToString(@"hh\:mm\:ss");
            DrawBars(Get<StackPanel>("AgentChart"),rows.Where(r=>!String.IsNullOrEmpty(D.Field(r,"dateFin"))).GroupBy(r=>D.Field(r,"agent")).Select(g=>new KeyValuePair<string,int>(String.IsNullOrEmpty(g.Key)?"Non affecté":g.Key,g.Count())).OrderByDescending(x=>x.Value).Take(10).ToList(),"#C8102E");
            var statusGroups=new List<KeyValuePair<string,int>> { new KeyValuePair<string,int>("À affecter",queueRows.Count),new KeyValuePair<string,int>("En cours / affectées",assignedRows.Count),new KeyValuePair<string,int>("Terminées",doneRows.Count) };
            DrawBars(Get<StackPanel>("StatusChart"),statusGroups,"#287C8E");
            Get<TextBlock>("DashboardSummary").Text="Périmètre filtré : "+total.ToString("N0")+" lignes. "+queueRows.Count+" à affecter, "+active+" affectées ou en cours et "+doneCount+" terminées. DMT calculée sur "+durations.Length+" durée(s) renseignée(s).";
            PopulateAgents(); RenderLedger(); RenderKpisAndCharts();
        }
        private static readonly string[][] MotifGroups = new string[][] {
            new string[]{"statu","JUSTIF_ABS","TRANSAC_INC","EMMET_INC","CONTRAT_TERM","DOUBLE_FACT","DOUBLON","CMD_ERR"},
            new string[]{"task","DEST_ERR","DEST_INC","AUTRE","ADR_ERR","SIRET_ERR","CODE_ROUTAGE_ERR","REF_CT_ABSENT","REF_ERR","PU_ERR","REM_ERR","QTE_ERR","ART_ERR","MODPAI_ERR","QUALITE_ERR","LIVR_INCOMP"},
            new string[]{"escalade","TX_TVA_ER","MONTANT TOTAL_ERR","CALCUL_ERR","NON_CONFORME"}
        };
        private static DateTime? ParseDate(string value) { DateTime d; return DateTime.TryParse(value,CultureInfo.InvariantCulture,DateTimeStyles.AssumeLocal,out d)?(DateTime?)d:null; }
        private string GroupPeriod(DateTime d)
        {
            string group=Selected(Get<ComboBox>("KpiGroup"));
            if(group=="Année") return d.Year.ToString("0000");
            if(group=="Mois") return d.ToString("yyyy-MM",CultureInfo.InvariantCulture);
            if(group=="Semaine ISO") { int week=CultureInfo.InvariantCulture.Calendar.GetWeekOfYear(d,CalendarWeekRule.FirstFourDayWeek,DayOfWeek.Monday); int year=d.Year; if(d.Month==1&&week>=52)year--; if(d.Month==12&&week==1)year++; return year.ToString("0000")+"-S"+week.ToString("00"); }
            return d.ToString("yyyy-MM-dd",CultureInfo.InvariantCulture);
        }
        private static string ScopeValue(string value,string all) { return String.IsNullOrEmpty(value)||value==all?"":value; }
        private string ManualScope()
        {
            string year=ScopeValue(Selected(Get<ComboBox>("YearFilter")),"Toutes"), month=ScopeValue(Selected(Get<ComboBox>("MonthFilter")),"Tous");
            string group=Selected(Get<ComboBox>("KpiGroup")); string g=group=="Semaine ISO"?"week":group=="Mois"?"month":group=="Année"?"year":"day";
            return new JArray(year,month,"","","","","","","",g).ToString(Formatting.None);
        }
        private JObject ManualEntry(string period)
        {
            JObject cfg=state["config"] as JObject; JObject all=cfg==null?null:cfg["manualKpis"] as JObject; JObject periods=all==null?null:all[ManualScope()] as JObject;
            return periods==null?null:periods[period] as JObject;
        }
        private void RenderKpisAndCharts()
        {
            if(state==null)return;
            var buckets=new SortedDictionary<string,KpiBucket>(StringComparer.Ordinal); KpiBucket total=new KpiBucket();
            var rows=D.Array(state["traitements"]).OfType<JObject>().Where(InFilter).ToList();
            foreach(JObject r in rows)
            {
                DateTime? imp=ParseDate(D.Field(r,"dateImport"));
                if(imp.HasValue) { string follow=""; foreach(JObject c in D.Array(r["sourceValues"]).OfType<JObject>())if(D.Normalize(D.Field(c,"label"))=="suivi de la facture"){follow=D.Field(c,"text");break;} string f=D.Normalize(follow); string key=GroupPeriod(imp.Value); if(!buckets.ContainsKey(key))buckets[key]=new KpiBucket(); if(f.Contains("refus")){buckets[key].refused++;total.refused++;}else if(f.Contains("litig")){buckets[key].litigation++;total.litigation++;}else{buckets[key].other++;total.other++;} }
                DateTime? end=ParseDate(D.Field(r,"dateFin")); if(!end.HasValue)continue;
                string period=GroupPeriod(end.Value); if(!buckets.ContainsKey(period))buckets[period]=new KpiBucket(); KpiBucket b=buckets[period]; string motif=SourceMotif(r).Trim().ToUpperInvariant(); string category="";
                foreach(string[] group in MotifGroups)if(group.Skip(1).Contains(motif,StringComparer.OrdinalIgnoreCase)){category=group[0];break;}
                if(category=="task"){b.task++;total.task++;}else if(category=="escalade"){b.escalation++;total.escalation++;}else if(category=="statu"){b.statu++;total.statu++;}else{b.unknown++;total.unknown++;}
                string agent=D.Field(r,"agent");if(agent.Length>0){b.agents.Add(agent.ToUpperInvariant());total.agents.Add(agent.ToUpperInvariant());}
                double sec;if(Double.TryParse(D.Field(r,"dmtSecondes"),NumberStyles.Any,CultureInfo.InvariantCulture,out sec)&&sec>=0){b.seconds+=sec;b.timed++;total.seconds+=sec;total.timed++;}else{b.missing++;total.missing++;}
            }
            JObject cfg=state["config"] as JObject; JObject all=cfg==null?null:cfg["manualKpis"] as JObject; JObject manual=all==null?null:all[ManualScope()] as JObject;
            if(manual!=null)foreach(JProperty prop in manual.Properties())if(prop.Name!="total"&&!buckets.ContainsKey(prop.Name))buckets[prop.Name]=new KpiBucket();
            var output=new ObservableCollection<CdoRow>();
            foreach(var pair in buckets)output.Add(ToCdoRow(pair.Key,pair.Value)); output.Add(ToCdoRow("total",total));
            Get<DataGrid>("CdoGrid").ItemsSource=output;
            Get<ComboBox>("ManualPeriod").ItemsSource=null; var periods=buckets.Keys.ToList(); periods.Add("total"); string old=Selected(Get<ComboBox>("ManualPeriod")); Get<ComboBox>("ManualPeriod").ItemsSource=periods; Get<ComboBox>("ManualPeriod").SelectedItem=periods.Contains(old)?old:(periods.Count>0?periods[0]:"total"); FillManualKpi();
            int manualCount=0;if(manual!=null)foreach(JObject e in manual.OfType<JProperty>().Select(x=>x.Value as JObject).Where(x=>x!=null)){JObject v=e["values"] as JObject;if(v!=null)manualCount+=v.Properties().Count();}
            Get<TextBlock>("KpiQuality").Text=total.unknown+" traitement(s) à motif non classé · "+total.other+" facture(s) avec suivi autre ou absent · "+total.missing+" traitement(s) sans durée. "+manualCount+" zone(s) saisie(s) manuellement ; les factures restent inchangées.";
            RenderAnalytics(rows,buckets,total);
        }
        private CdoRow ToCdoRow(string period,KpiBucket b)
        {
            JObject entry=ManualEntry(period); JObject vals=entry==null?null:entry["values"] as JObject;
            int task=vals!=null&&vals["task"]!=null?(int)vals["task"]:b.task, esc=vals!=null&&vals["escalade"]!=null?(int)vals["escalade"]:b.escalation, statu=vals!=null&&vals["statu"]!=null?(int)vals["statu"]:b.statu, agents=vals!=null&&vals["agents"]!=null?(int)vals["agents"]:b.agents.Count;
            return new CdoRow{Period=period=="total"?"Total / moyenne":period,Refused=b.refused.ToString("N0"),Litigation=b.litigation.ToString("N0"),Task=task.ToString("N0"),Escalation=esc.ToString("N0"),Statu=statu.ToString("N0"),Agents=agents.ToString("N0"),DmtHours=b.timed==0?"—":(b.seconds/b.timed/3600).ToString("0.00",CultureInfo.GetCultureInfo("fr-FR")),ProductionHours=b.timed==0?"—":(b.seconds/3600).ToString("0.00",CultureInfo.GetCultureInfo("fr-FR"))};
        }
        private void FillManualKpi()
        {
            if(state==null||Get<ComboBox>("ManualPeriod").SelectedItem==null)return;string period=Selected(Get<ComboBox>("ManualPeriod"));JObject e=ManualEntry(period),v=e==null?null:e["values"] as JObject;
            Get<TextBox>("ManualTask").Text=v==null||v["task"]==null?"":D.Text(v["task"]);Get<TextBox>("ManualEscalade").Text=v==null||v["escalade"]==null?"":D.Text(v["escalade"]);Get<TextBox>("ManualStatu").Text=v==null||v["statu"]==null?"":D.Text(v["statu"]);Get<TextBox>("ManualAgents").Text=v==null||v["agents"]==null?"":D.Text(v["agents"]);
            Get<TextBlock>("ManualKpiStatus").Text=e==null?"Calcul automatique":("Saisie manuelle · "+D.Field(e,"updatedBy"));
        }
        private async Task SaveManualKpi(bool reset)
        {
            try
            {
                string period=Selected(Get<ComboBox>("ManualPeriod"));if(period.Length==0)throw new InvalidOperationException("Aucune période disponible."); JObject entry=ManualEntry(period);var values=new JObject();
                if(!reset){foreach(var pair in new[]{new KeyValuePair<string,string>("task","ManualTask"),new KeyValuePair<string,string>("escalade","ManualEscalade"),new KeyValuePair<string,string>("statu","ManualStatu"),new KeyValuePair<string,string>("agents","ManualAgents")}){string raw=Get<TextBox>(pair.Value).Text.Trim();if(raw.Length==0)continue;long n;if(!Int64.TryParse(raw,out n)||n<0||n>100000000)throw new InvalidOperationException("Saisir des nombres entiers entre 0 et 100 000 000.");values[pair.Key]=n;}}
                await Execute("manualKpi",D.Obj("scope",ManualScope(),"period",period,"expectedVersion",entry==null?"":D.Field(entry,"version"),"values",values));await Refresh();Get<TextBlock>("ManualKpiStatus").Text=reset?"Calcul automatique rétabli.":"Chiffres manuels enregistrés.";
            }catch(Exception ex){Get<TextBlock>("ManualKpiStatus").Text=ex.Message;}
        }
        private void RenderAnalytics(List<JObject> rows,SortedDictionary<string,KpiBucket> buckets,KpiBucket total)
        {
            var done=rows.Where(r=>!String.IsNullOrEmpty(D.Field(r,"dateFin"))).ToList();
            DrawBars(Get<StackPanel>("ProductionAgentChart"),done.GroupBy(r=>D.Field(r,"agent")).Select(g=>new KeyValuePair<string,int>(String.IsNullOrEmpty(g.Key)?"Non renseigné":g.Key,g.Count())).OrderByDescending(x=>x.Value).Take(10).ToList(),"#21978F");
            var dmt=done.Select(r=>new{agent=String.IsNullOrEmpty(D.Field(r,"agent"))?"Non renseigné":D.Field(r,"agent"),sec=Seconds(r)}).Where(x=>x.sec>=0).GroupBy(x=>x.agent).Select(g=>new KeyValuePair<string,int>(g.Key,(int)Math.Round(g.Average(x=>x.sec)/36.0))).OrderByDescending(x=>x.Value).ToList();DrawBars(Get<StackPanel>("DmtAgentChart"),dmt,"#657BC5");
            DrawBars(Get<StackPanel>("MotifChart"),done.GroupBy(SourceMotif).Select(g=>new KeyValuePair<string,int>(String.IsNullOrEmpty(g.Key)?"Non renseigné":g.Key,g.Count())).OrderByDescending(x=>x.Value).Take(8).ToList(),"#21978F");
            DrawBars(Get<StackPanel>("OutcomeChart"),new List<KeyValuePair<string,int>>{new KeyValuePair<string,int>("Création de tâche",total.task),new KeyValuePair<string,int>("Escalade",total.escalation),new KeyValuePair<string,int>("Statu quo",total.statu),new KeyValuePair<string,int>("Non classé",total.unknown)},"#657BC5");
            var extracted=rows.Where(r=>!String.IsNullOrEmpty(D.Field(r,"dateImport"))).ToList();int refus=0,litig=0,other=0;foreach(JObject r in extracted){string follow="";foreach(JObject c in D.Array(r["sourceValues"]).OfType<JObject>())if(D.Normalize(D.Field(c,"label"))=="suivi de la facture"){follow=D.Normalize(D.Field(c,"text"));break;}if(follow.Contains("refus"))refus++;else if(follow.Contains("litig"))litig++;else other++;}
            DrawBars(Get<StackPanel>("FollowChart"),new List<KeyValuePair<string,int>>{new KeyValuePair<string,int>("Refusées",refus),new KeyValuePair<string,int>("En litige",litig),new KeyValuePair<string,int>("Autre / non renseigné",other)},"#D98268");
            DrawBars(Get<StackPanel>("TypeChart"),rows.GroupBy(r=>D.Field(r,"typeFacture")).Select(g=>new KeyValuePair<string,int>(String.IsNullOrEmpty(g.Key)?"Non renseigné":g.Key,g.Count())).OrderByDescending(x=>x.Value).Take(8).ToList(),"#287C8E");
            var trend=buckets.Select(k=>new KeyValuePair<string,int>(k.Key,k.Value.refused+k.Value.litigation+k.Value.other)).ToList();DrawBars(Get<StackPanel>("TrendChart"),trend,"#657BC5");
        }
        private static double Seconds(JObject r){double v;return Double.TryParse(D.Field(r,"dmtSecondes"),NumberStyles.Any,CultureInfo.InvariantCulture,out v)&&v>=0?v:-1;}

        private void DrawBars(Panel host,List<KeyValuePair<string,int>> values,string color)
        {
            host.Children.Clear(); int max=values.Count==0?1:Math.Max(1,values.Max(v=>v.Value));
            foreach(var item in values)
            {
                var row=new Grid { Margin=new Thickness(0,4,0,4) }; row.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(145)}); row.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(1,GridUnitType.Star)}); row.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(38)});
                var name=new TextBlock{Text=item.Key,VerticalAlignment=VerticalAlignment.Center,TextTrimming=TextTrimming.CharacterEllipsis,Foreground=System.Windows.Media.Brushes.SlateGray}; Grid.SetColumn(name,0);row.Children.Add(name);
                var track=new Border{Height=12,Background=(System.Windows.Media.Brush)new System.Windows.Media.BrushConverter().ConvertFromString("#EEF1F6"),CornerRadius=new CornerRadius(6),VerticalAlignment=VerticalAlignment.Center};
                var fill=new Border{Height=12,Width=Math.Max(2,220.0*item.Value/max),Background=(System.Windows.Media.Brush)new System.Windows.Media.BrushConverter().ConvertFromString(color),CornerRadius=new CornerRadius(6),HorizontalAlignment=HorizontalAlignment.Left}; track.Child=fill;Grid.SetColumn(track,1);row.Children.Add(track);
                var number=new TextBlock{Text=item.Value.ToString("N0"),TextAlignment=TextAlignment.Right,VerticalAlignment=VerticalAlignment.Center,FontWeight=FontWeights.SemiBold};Grid.SetColumn(number,2);row.Children.Add(number);host.Children.Add(row);
            }
            if(values.Count==0)host.Children.Add(new TextBlock{Text="Aucune donnée sur cette période.",Foreground=System.Windows.Media.Brushes.Gray,Margin=new Thickness(4,10,4,10)});
        }
        private void PopulateAgents()
        {
            JObject cfg=state["config"] as JObject; var names=D.Array(cfg==null?null:cfg["agents"]).Select(D.Text).Concat(D.Array(state["traitements"]).OfType<JObject>().Select(r=>D.Field(r,"agent"))).Where(x=>x.Length>0).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x=>x).ToList();
            ComboBox combo=Get<ComboBox>("AgentPicker"); string old=Selected(combo);combo.Items.Clear();foreach(string n in names)combo.Items.Add(n);if(names.Contains(old))combo.SelectedItem=old;else if(combo.Items.Count>0)combo.SelectedIndex=0;
        }
        private void RenderLedger()
        {
            importRows.Clear();duplicateRows.Clear(); if(ledger==null)return; JObject imports=ledger["imports"] as JObject;
            foreach(JObject r in D.Array(imports==null?null:imports["history"]).OfType<JObject>().OrderByDescending(r=>D.Field(r,"date")))
                importRows.Add(new ManagerRow{Date=FormatDate(D.Field(r,"date")),User=D.Field(r,"user"),Files=D.Field(r,"files"),Added=D.Field(r,"added"),Duplicates=D.Field(r,"duplicates"),Skipped=D.Field(r,"skipped")});
            foreach(JObject r in D.Array(imports==null?null:imports["duplicates"]).OfType<JObject>().Where(r=>D.Field(r,"decision")=="pending"))
            { JObject candidate=r["row"] as JObject; duplicateRows.Add(new ManagerRow{Id=D.Field(r,"id"),Numero=candidate==null?"":D.Field(candidate,"numeroFacture"),Source=candidate==null?"":D.Field(candidate,"sourceFile"),Original=D.Field(r,"originalId"),Decision=D.Field(r,"decision"),Date=FormatDate(D.Field(r,"date"))}); }
            Get<TextBlock>("ImportStatus").Text=importRows.Count+" import(s) historisés · "+duplicateRows.Count+" doublon(s) en attente";
        }
        private async Task AssignSelected()
        {
            var selected=Get<DataGrid>("QueueGrid").SelectedItems.Cast<ManagerRow>().ToList(); string agent=Selected(Get<ComboBox>("AgentPicker"));
            if(selected.Count==0){SetStatus("Sélectionnez au moins une facture.",true);return;} if(agent.Length==0){SetStatus("Choisissez un agent.",true);return;}
            try{JObject result=await Execute("assign",D.Obj("ids",new JArray(selected.Select(r=>r.Id)),"agent",agent));SetStatus(D.Field(result,"affectees")+" facture(s) affectée(s) à "+agent+".",false);await Refresh();}catch(Exception ex){SetStatus(ex.Message,true);}
        }
        private async Task AddAgent()
        {
            string name = Get<TextBox>("NewAgentBox").Text.Trim();
            if (name.Length == 0) { SetStatus("Saisissez le nom de session Windows du nouvel agent.", true); return; }
            try { await Execute("agents", D.Obj("name", name)); Get<TextBox>("NewAgentBox").Clear(); await Refresh(); SetStatus("Agent ajouté : " + name.ToUpperInvariant(), false); }
            catch (Exception ex) { SetStatus(ex.Message, true); }
        }
        private async Task Export()
        {
            try{JObject result=await Execute("export",null);SetStatus(D.Field(result,"exportees")+" facture(s) exportée(s). "+D.Array(result["erreurs"]).Count+" erreur(s).",D.Array(result["erreurs"]).Count>0);await Refresh();}catch(Exception ex){SetStatus(ex.Message,true);}
        }
        private async Task Import()
        {
            try{Get<Button>("ImportButton").IsEnabled=false;Get<TextBlock>("ImportStatus").Text="Import Excel en cours…";JObject result=await Execute("import",null);Get<TextBlock>("ImportStatus").Text="Import terminé · "+D.Field(result,"ajoutees")+" ajoutée(s) · "+D.Field(result,"doublonsIgnores")+" doublon(s) · "+D.Field(result,"dureeSecondes")+" s";await Refresh();}catch(Exception ex){SetStatus("Import impossible : "+ex.Message,true);}finally{Get<Button>("ImportButton").IsEnabled=true;}
        }
        private async Task DecideDuplicates(string decision)
        {
            var selected=Get<DataGrid>("DuplicateGrid").SelectedItems.Cast<ManagerRow>().ToList();if(selected.Count==0){SetStatus("Sélectionnez les doublons à traiter.",true);return;}
            try{JObject result=await Execute("duplicates",D.Obj("ids",new JArray(selected.Select(r=>r.Id)),"decision",decision));SetStatus(D.Field(result,"count")+" doublon(s) traité(s).",false);await Refresh();}catch(Exception ex){SetStatus(ex.Message,true);}
        }
        private async Task SaveSource()
        {
            try{await Execute("config",D.Obj("sourceDirectory",Get<TextBox>("SourceDirectoryBox").Text.Trim()));Get<TextBlock>("SettingsStatus").Text="Répertoire source enregistré.";await Refresh();}catch(Exception ex){Get<TextBlock>("SettingsStatus").Text=ex.Message;}
        }
        private void SaveDataPath()
        {
            try
            {
                string target=Get<TextBox>("DataDirectoryBox").Text.Trim();if(!Path.IsPathRooted(target)||!Directory.Exists(target)||!File.Exists(Path.Combine(target,"epithete-traitements.json")))throw new InvalidDataException("Choisissez un dossier existant contenant epithete-traitements.json.");
                var check=new FileStore(target);worker.Run(delegate{check.ReadRecords();return true;}).GetAwaiter().GetResult();
                string config=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"desktop-config.json");AtomicFile.Write(config,Encoding.UTF8.GetBytes(D.Obj("dataDirectory",Path.GetFullPath(target)).ToString(Formatting.Indented)));
                Get<TextBlock>("SettingsStatus").Text="Chemin enregistré. Fermez puis relancez le Manager pour appliquer la nouvelle base.";
            }
            catch(Exception ex){Get<TextBlock>("SettingsStatus").Text=ex.Message;}
        }
        private async Task Maintenance()
        { try{JObject result=await Execute("maintenance",null);Get<TextBlock>("SettingsStatus").Text="Reconstruction demandée. État : "+D.Field(result,"busy");}catch(Exception ex){Get<TextBlock>("SettingsStatus").Text=ex.Message;} }
    }
}
