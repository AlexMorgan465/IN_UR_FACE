﻿using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;
namespace EpitheteDesktop
{
    internal sealed class StaWorker : IDisposable
    {
        private readonly BlockingCollection<Action> queue = new BlockingCollection<Action>();
        private readonly Thread thread;
        public StaWorker()
        {
            thread = new Thread(delegate() { foreach (Action action in queue.GetConsumingEnumerable()) action(); });
            thread.Name = "Epithete-fichiers-Excel"; thread.IsBackground = true; thread.SetApartmentState(ApartmentState.STA); thread.Start();
        }
        public Task<T> Run<T>(Func<T> action)
        {
            var task = new TaskCompletionSource<T>();
            queue.Add(delegate { try { task.SetResult(action()); } catch (Exception ex) { task.SetException(ex); } });
            return task.Task;
        }
        public void Dispose() { queue.CompleteAdding(); }
    }
}
