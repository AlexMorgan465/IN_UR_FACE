﻿VERSION COURANTE V4.2 — ETAFAC : consulter V4.2-NOTES.md pour la saisie manuelle des KPI et le mode Agent hors ligne.

VERSION COURANTE V4.1 : consulter V4.1-NOTES.md pour la nouvelle interface et le chargement en arrière-plan.

MISE À JOUR V4 : consulter V4-NOTES.md pour le stockage quotidien, les sauvegardes et le déploiement. Les instructions V3 ci-dessous décrivent la version précédente.

ÉPITHÈTE V3.0 — PERFORMANCES ET INTERFACE — 21 octobre 2026

MISE À JOUR
1. Fermer TOUTES les anciennes versions Agent et Manager. Sauvegarder le dossier data COMPLET.
2. Décompresser chaque paquet portable dans un nouveau dossier local. Copier l'ancien desktop-config.json pour conserver le dataDirectory du DP.
3. Lancer d'abord le Manager V3.0. Il prépare automatiquement les fichiers par agent à partir de la base existante et reprend les mises à jour V2. Attendre l'affichage des indicateurs.
4. Lancer ensuite les agents V3.0. Vérifier V3.0 dans la barre de titre et le logo de l'interface. Ne plus lancer les anciens raccourcis V1/V2.
Aucune réimportation des classeurs n'est nécessaire pour migrer les traitements existants.
Le premier démarrage Manager effectue la préparation ; ce travail n'est pas répété à chaque actualisation.

STOCKAGE PAR AGENT
La base epithete-traitements.json reste le catalogue des lignes et affectations.
affectations-v3 : un JSON de lignes affectées par agent, plus index.json.
agents-v3 : un JSON de mises à jour par agent, plus ready.marker de migration.
Un agent lit seulement son fichier d'affectations et son fichier de mises à jour. Il ne recharge pas le contenu de la base globale lorsque son index est à jour.
Les agents écrivent dans leurs fichiers respectifs, sous verrou par session, sans verrou global Manager. Les modifications du même agent restent sérialisées.
Le Manager consolide les JSON par agent ; les fichiers inchangés sont mis en cache. Un état inchangé ne retransmet pas les lignes à l'interface et ne reconstruit pas ses tableaux.
Les affectations modifiées mettent à jour les lots des agents concernés. L'index est publié après les fichiers ; une préparation interrompue retombe sur la base principale.
Les anciens fichiers traitements-v2 sont conservés. Après migration validée, V3 ne les consulte plus. Ne plus utiliser V2 après cette migration.
Sauvegarder TOUT data : base, configuration, historique d'import, traitements-v2, affectations-v3 et agents-v3. Le JSON central seul ne contient pas toutes les mises à jour de traitement.
Les outils tiers lisant directement la base doivent aussi intégrer les mises à jour agents-v3.

IMPORT EXCEL
Lecture d'une plage UsedRange.Value2 en mémoire, au lieu des accès Excel pour chaque cellule texte. Les cellules texte se traitent sans appels COM individuels. Formats généraux et numéros à zéros initiaux uniformes se traitent en mémoire ; les formats complexes/mélangés conservent un recours à l'affichage Excel pour préserver les dates et montants.
Fichiers inchangés : vérification SHA-256, aucune ouverture de classeur ; si tous sont inchangés, Excel n'est même pas lancé. Les fichiers doivent toujours être lus pour cette vérification d'empreinte.
Progression visible par fichier, feuille et tranche de lignes. Durée totale affichée après l'import. Les actualisations automatiques Manager sont suspendues pendant cette opération.
Une zone utilisée dépassant deux millions de cellules est signalée pour éviter une allocation incontrôlée ; nettoyer les lignes/colonnes inutiles dans Excel.
Historique, contrôle des doublons entre tous les fichiers et décisions d'acceptation/ignorance conservés. Un fichier modifié est relu sans écraser les traitements connus.

INTERFACE
Retrait de la barre native ajoutée dans V2.2 et de son bouton Fermer.
Navigation haute plus compacte, actions secondaires discrètes, Quitter intégré à l'interface, indicateur de synchronisation, barre de sélection en masse, suivi d'import.
Tableaux Manager paginés et construits seulement pour l'onglet visible. Recherche temporisée pour ne pas reconstruire le tableau à chaque touche.
Agent : 100 lignes affectées affichées au départ, Afficher plus ; historique chargé à l'ouverture et par tranches de 100. Profil WebView2 local réutilisé pour les prochains démarrages.
Croix Windows et Quitter : fermeture immédiate de cette application, même si une opération reste bloquée. Une opération en cours ou une saisie non enregistrée peut être interrompue. Aucun autre programme de l'utilisateur n'est fermé.

EXPORTS ET DONNÉES EXISTANTES
Export des terminés non exportés selon les filtres courants ; bouton par ligne pour export ou réexport manuel.
Une modification agent remet la ligne à exporter. Les modifications faites pendant l'export ne sont pas marquées comme déjà exportées.
Sauvegarde du classeur avant écriture. Lecture seule ou emplacement ambigu : erreur visible et ligne non marquée.
Conserver les mêmes droits de création/modification sur le DP. Les paquets portables n'incluent aucune base métier ; donnees-fournies dans le projet complet contient les données du projet transmis, à ne jamais recopier par-dessus la production.

PRÉREQUIS ET SÉCURITÉ
Windows x64, .NET Framework 4.8, WebView2 ; Excel de bureau pour Manager.
Distribution portable sans installateur, service, port ou script de déploiement. Aucun réglage Symantec, exclusion antivirus, pare-feu ou politique Windows modifié. Aucun prérequis téléchargé automatiquement.
La protection contre les macros est conservée dans l'instance Excel automatisée uniquement ; aucun réglage global d'Office n'est changé. Un blocage Symantec dépend de sa détection et doit être diagnostiqué à partir de son alerte.
Sources src et ui ; EXE compilés dans bin. Recompiler.cmd / Compiler.ps1 recompile les EXE sur Windows sans changer la politique d'exécution.

TESTS ET LIMITES
Test synthétique exécuté : 5 000 lignes / 25 agents, catalogue de 3 325 782 octets ; un agent avec 200 affectations charge 135 093 octets au démarrage. Une nouvelle lecture inchangée n'ajoute aucun octet JSON lu. Ces mesures sont locales et ne préjugent pas de la latence SMB réelle.
25 agents enregistrent en parallèle pendant que le verrou central Manager est tenu ; catalogue inchangé, toutes les mises à jour consolidées, un fichier de mises à jour par agent.
Migration V2 conservant le traitement, index nouvel agent, état inchangé sans relecture du contenu : validés.
Lecture de 2 000 cellules texte dans une plage simulée sans aucun appel cellule individuel ; numéro 00012 préservé ; fichier inchangé ne créant aucune instance Excel : validés.
Tests existants du cœur : droits, doublons, réimport idempotent, export incrémental/individuel, modification concurrente pendant export : réussis.
Interface logique : 2 500 lignes paginées, affectation de 1 000 en une requête, navigation de tous les onglets, listes Agent par 100/200 : réussis.
Sortie du processus malgré un thread bloqué : testée.
Limites : environnement Linux. Lancement WPF/WebView2, rendu final, Excel COM réel, partage SMB et Symantec non exécutés ici. Faire une recette sur deux postes avant généralisation, en mesurant le premier import et le suivant.
