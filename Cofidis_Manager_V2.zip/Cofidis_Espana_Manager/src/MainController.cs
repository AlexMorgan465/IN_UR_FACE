using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;

namespace Cofidis_Espana_Manager
{
    // Logica del panel. La interfaz se carga desde ui\MainWindow.xaml (incrustado en el EXE).
    internal sealed class MainController
    {
        private readonly Window ventana;
        private List<Tratamiento> todos = new List<Tratamiento>();
        private List<Tratamiento> filtrados = new List<Tratamiento>();
        private List<EstadisticaDia> estadisticas = new List<EstadisticaDia>();
        private bool inicializando = true;
        private Lector lector;
        private static readonly string[] Decisiones = { "sin información para pre-estudio", "RExBU", "RExB1", "RExIG", "RExRECIENTE", "RExNT", "RExPR", "RExVEDACON", "RExFICHEROS NEG", "RExTIPO CTTO", "RExSCORE", "RExRIESGO", "RExLI", "RExAN", "RExBQ" };

        private readonly DatePicker desde, hasta;
        private readonly ComboBox agente, taf, estado;
        private readonly TextBlock rutaTexto, estadoTexto, kpiTotal, kpiFinal, kpiCurso, kpiDmt, kpiAgentes;
        private readonly ItemsControl barrasDecision, barrasTaf, barrasDmt;
        private readonly DataGrid evolucion, tablaDetalle, tablaStats;

        private T Obtener<T>(string nombre) where T : class
        {
            T elemento = ventana.FindName(nombre) as T;
            if (elemento == null) throw new InvalidOperationException("Elemento de interfaz no encontrado: " + nombre);
            return elemento;
        }

        public MainController(Window ventana)
        {
            this.ventana = ventana;
            desde = Obtener<DatePicker>("Desde");
            hasta = Obtener<DatePicker>("Hasta");
            agente = Obtener<ComboBox>("Agente");
            taf = Obtener<ComboBox>("Taf");
            estado = Obtener<ComboBox>("Estado");
            rutaTexto = Obtener<TextBlock>("RutaTexto");
            estadoTexto = Obtener<TextBlock>("EstadoTexto");
            kpiTotal = Obtener<TextBlock>("KpiTotal");
            kpiFinal = Obtener<TextBlock>("KpiFinal");
            kpiCurso = Obtener<TextBlock>("KpiCurso");
            kpiDmt = Obtener<TextBlock>("KpiDmt");
            kpiAgentes = Obtener<TextBlock>("KpiAgentes");
            barrasDecision = Obtener<ItemsControl>("BarrasDecision");
            barrasTaf = Obtener<ItemsControl>("BarrasTaf");
            barrasDmt = Obtener<ItemsControl>("BarrasDmt");
            evolucion = Obtener<DataGrid>("Evolucion");
            tablaDetalle = Obtener<DataGrid>("TablaDetalle");
            tablaStats = Obtener<DataGrid>("TablaStats");

            Obtener<Button>("ActualizarBoton").Click += delegate { Actualizar(); };
            Obtener<Button>("LimpiarBoton").Click += Limpiar_Click;
            Obtener<Button>("AjustesBoton").Click += Ajustes_Click;
            Obtener<Button>("CsvDetalleBoton").Click += delegate { Exportar(false, false); };
            Obtener<Button>("XlsxDetalleBoton").Click += delegate { Exportar(true, false); };
            Obtener<Button>("CsvStatsBoton").Click += delegate { Exportar(false, true); };
            Obtener<Button>("XlsxStatsBoton").Click += delegate { Exportar(true, true); };
            SelectionChangedEventHandler filtro = delegate { if (!inicializando) Filtrar(); };
            desde.SelectedDateChanged += filtro;
            hasta.SelectedDateChanged += filtro;
            agente.SelectionChanged += filtro;
            taf.SelectionChanged += filtro;
            estado.SelectionChanged += filtro;

            try { lector = new Lector(); rutaTexto.Text = lector.Raiz; }
            catch (Exception ex)
            {
                MessageBox.Show("Error en config.json: " + ex.Message + "\n\nPuede corregir la ruta con el botón de ajustes.");
                lector = null;
                inicializando = false;
                return;
            }
            inicializando = false;
            Actualizar();
        }

        private static List<string> ConTodos(IEnumerable<string> valores)
        {
            return new[] { "Todos" }.Concat(valores.Where(x => !string.IsNullOrWhiteSpace(x)).Distinct().OrderBy(x => x)).ToList();
        }

        private void Actualizar()
        {
            if (lector == null) return;
            try
            {
                var lectura = lector.Leer();
                todos = lectura.Datos;
                inicializando = true;
                string a = agente.SelectedItem as string, t = taf.SelectedItem as string, s = estado.SelectedItem as string;
                agente.ItemsSource = ConTodos(todos.Select(x => x.Usuario));
                taf.ItemsSource = ConTodos(todos.Select(x => x.Taf));
                estado.ItemsSource = ConTodos(todos.Select(x => x.Estado));
                agente.SelectedItem = (a != null && agente.Items.Contains(a)) ? a : "Todos";
                taf.SelectedItem = (t != null && taf.Items.Contains(t)) ? t : "Todos";
                estado.SelectedItem = (s != null && estado.Items.Contains(s)) ? s : "Todos";
                inicializando = false;
                Filtrar();
                estadoTexto.Text = todos.Count + " registros cargados · " + lectura.Errores.Count + " archivo(s) con error";
                if (lectura.Errores.Count > 0)
                    MessageBox.Show("Algunos archivos no se pudieron leer:\n" + string.Join("\n", lectura.Errores.Take(8)), "Advertencia", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            catch (Exception ex) { inicializando = false; MessageBox.Show("Error al actualizar: " + ex.Message); }
        }

        private void Limpiar_Click(object sender, RoutedEventArgs e)
        {
            inicializando = true;
            desde.SelectedDate = null; hasta.SelectedDate = null;
            agente.SelectedItem = "Todos"; taf.SelectedItem = "Todos"; estado.SelectedItem = "Todos";
            inicializando = false;
            Filtrar();
        }

        private void Ajustes_Click(object sender, RoutedEventArgs e)
        {
            var dialogo = new AjustesVentana(lector != null ? lector.Raiz : string.Empty) { Owner = ventana };
            if (dialogo.ShowDialog() != true) return;
            try
            {
                lector = new Lector();
                rutaTexto.Text = lector.Raiz;
                Actualizar();
            }
            catch (Exception ex) { MessageBox.Show("No se pudo aplicar la nueva ruta:\n" + ex.Message); }
        }

        private static bool EsFinalizado(Tratamiento x)
        {
            return x.FechaFin.HasValue && (x.Estado.Equals("Finalizado", StringComparison.OrdinalIgnoreCase) || x.Estado.Equals("Terminado", StringComparison.OrdinalIgnoreCase) || x.Estado.Equals("Termine", StringComparison.OrdinalIgnoreCase) || x.Estado.Equals("Terminé", StringComparison.OrdinalIgnoreCase));
        }

        private void Filtrar()
        {
            DateTime? d = desde.SelectedDate, h = hasta.SelectedDate;
            string a = (agente.SelectedItem as string) ?? "Todos", t = (taf.SelectedItem as string) ?? "Todos", s = (estado.SelectedItem as string) ?? "Todos";
            filtrados = todos.Where(x => (!d.HasValue || x.FechaInicio.Date >= d.Value.Date) && (!h.HasValue || x.FechaInicio.Date <= h.Value.Date)
                && (a == "Todos" || x.Usuario == a) && (t == "Todos" || x.Taf == t) && (s == "Todos" || x.Estado == s)).OrderByDescending(x => x.FechaInicio).ToList();
            tablaDetalle.ItemsSource = filtrados;
            var terminados = filtrados.Where(x => EsFinalizado(x)).ToList();
            kpiTotal.Text = filtrados.Count.ToString("N0");
            kpiFinal.Text = terminados.Count.ToString("N0");
            kpiCurso.Text = filtrados.Count(x => !x.FechaFin.HasValue).ToString("N0");
            kpiAgentes.Text = filtrados.Select(x => x.Usuario).Distinct().Count().ToString();
            kpiDmt.Text = terminados.Count == 0 ? "-" : TimeSpan.FromSeconds(terminados.Average(x => x.DmtSegundos ?? 0)).ToString(@"hh\:mm\:ss");
            estadisticas = terminados.GroupBy(x => x.FechaInicio.Date).OrderBy(g => g.Key).Select(g => CrearEstadistica(g.Key, g.ToList())).ToList();
            tablaStats.ItemsSource = estadisticas;
            evolucion.ItemsSource = estadisticas;
            barrasDecision.ItemsSource = CrearBarras(terminados.GroupBy(x => x.Decision).Where(g => !string.IsNullOrWhiteSpace(g.Key)).Select(g => new KeyValuePair<string, double>(g.Key, g.Count())));
            barrasTaf.ItemsSource = CrearBarras(terminados.GroupBy(x => x.Taf).Select(g => new KeyValuePair<string, double>(g.Key, g.Count())));
            barrasDmt.ItemsSource = CrearBarras(terminados.GroupBy(x => x.Taf).Select(g => new KeyValuePair<string, double>(g.Key, g.Average(x => x.DmtSegundos ?? 0))));
        }

        private static List<Barra> CrearBarras(IEnumerable<KeyValuePair<string, double>> origen)
        {
            var lista = origen.OrderByDescending(x => x.Value).Take(18).ToList();
            double max = lista.Count == 0 ? 1 : Math.Max(1, lista.Max(x => x.Value));
            return lista.Select(x => new Barra { Nombre = x.Key, Valor = x.Value.ToString("N0"), Anchura = Math.Max(2, x.Value / max * 220) }).ToList();
        }

        private static EstadisticaDia CrearEstadistica(DateTime dia, List<Tratamiento> items)
        {
            Func<string, int> contar = decision => items.Count(x => string.Equals(x.Decision.Trim(), decision, StringComparison.OrdinalIgnoreCase));
            int rechazados = Decisiones.Skip(1).Sum(x => contar(x));
            int sinInfo = contar("sin información para pre-estudio");
            return new EstadisticaDia
            {
                Fecha = dia.ToString("dd/MM/yyyy"), Tratados = items.Count, SinInformacion = sinInfo,
                RExBU = contar("RExBU"), RExB1 = contar("RExB1"), RExIG = contar("RExIG"), RExRECIENTE = contar("RExRECIENTE"),
                RExNT = contar("RExNT"), RExPR = contar("RExPR"), RExVEDACON = contar("RExVEDACON"),
                RExFICHEROSNEG = contar("RExFICHEROS NEG"), RExTIPOCTTO = contar("RExTIPO CTTO"), RExSCORE = contar("RExSCORE"),
                RExRIESGO = contar("RExRIESGO"), RExLI = contar("RExLI"), RExAN = contar("RExAN"), RExBQ = contar("RExBQ"),
                OkParaEstudio = items.Count - rechazados - sinInfo,
                PorcentajeRechazo = items.Count == 0 ? 0 : (double)rechazados / items.Count
            };
        }

        private void Exportar(bool excel, bool stats)
        {
            try
            {
                var dialog = new SaveFileDialog
                {
                    Title = stats ? "Exportar estadísticas" : "Exportar consolidación",
                    Filter = excel ? "Excel (*.xlsx)|*.xlsx" : "CSV (*.csv)|*.csv",
                    FileName = (stats ? "estadisticas_" : "consolidacion_") + DateTime.Now.ToString("yyyyMMdd") + (excel ? ".xlsx" : ".csv")
                };
                if (dialog.ShowDialog() != true) return;
                string[] encabezados = stats ? Exportador.CabecerasEstadisticas : Exportador.CabecerasDetalle;
                IEnumerable<string[]> filas = stats ? estadisticas.Select(Exportador.Estadistica) : filtrados.Select(Exportador.Detalle);
                if (excel) Exportador.Xlsx(dialog.FileName, encabezados, filas); else Exportador.Csv(dialog.FileName, encabezados, filas);
                estadoTexto.Text = "Exportación completada: " + dialog.FileName;
            }
            catch (Exception ex) { MessageBox.Show("Error al exportar: " + ex.Message); }
        }
    }
}
