$ErrorActionPreference='Stop'
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$csc=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (!(Test-Path $csc)) { $csc=Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe' }
if (!(Test-Path $csc)) { throw 'Compilador csc.exe de .NET Framework no encontrado.' }
$framework=Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319'
$refs=@('PresentationCore.dll','PresentationFramework.dll','WindowsBase.dll','System.Xaml.dll','System.Core.dll','System.Xml.dll','System.IO.Compression.dll','System.IO.Compression.FileSystem.dll','System.Security.dll')
foreach($r in $refs) {if (!(Test-Path (Join-Path $framework $r))) {throw "Referencia WPF no encontrada: $r"}}
foreach($project in @('Agent','Manager')) {
 $dest=Join-Path $root "$project\bin"
 New-Item -ItemType Directory -Force -Path $dest | Out-Null
 $args=@('/nologo','/target:winexe','/platform:anycpu','/out:'+ (Join-Path $dest "CofidisEspana$project.exe"),'/reference:'+ (Join-Path $root 'lib\Newtonsoft.Json.dll'))
 foreach($r in $refs){$args+='/reference:'+(Join-Path $framework $r)}
 $args+=@(Join-Path $root 'Common.cs'),(Join-Path $root "$project\Program.cs")
 & $csc $args
 if ($LASTEXITCODE -ne 0) {throw "Compilacion fallida: $project"}
 Copy-Item (Join-Path $root 'lib\Newtonsoft.Json.dll') $dest -Force
 Copy-Item (Join-Path $root "$project\MainWindow.xaml") $dest -Force
 Copy-Item (Join-Path $root "$project\config.json") $dest -Force
 Write-Host "Compilado: $dest" -ForegroundColor Green
}
