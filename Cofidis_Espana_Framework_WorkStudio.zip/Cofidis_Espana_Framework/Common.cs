using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
public class Record {
 public string Id {get;set;} public string Usuario {get;set;} public string Referencia {get;set;} public string Taf {get;set;} public string Decision {get;set;} public string Comentario {get;set;}
 public DateTime FechaInicio {get;set;} public DateTime? FechaFin {get;set;} public string Estado {get;set;}
 [JsonIgnore] public double? DmtSegundos {get {return FechaFin.HasValue ? (double?)(FechaFin.Value-FechaInicio).TotalSeconds : null;}}
}
public class Storage {
 public readonly string Root;
 public Storage(){ string path=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"config.json"); if(!File.Exists(path))throw new FileNotFoundException("Falta config.json",path); var cfg=JObject.Parse(File.ReadAllText(path)); string root=(string)cfg["RutaDatos"]; if(string.IsNullOrWhiteSpace(root))throw new Exception("RutaDatos está vacía"); Root=Path.GetFullPath(Environment.ExpandEnvironmentVariables(root)); Directory.CreateDirectory(Root); }
 public string FileFor(string user,DateTime date){return Path.Combine(Root,date.ToString("MM-yyyy"),user+"-"+date.ToString("MM-yyyy")+".json");}
 public List<Record> ReadFile(string file){if(!File.Exists(file))return new List<Record>();var data=JsonConvert.DeserializeObject<List<Record>>(File.ReadAllText(file));if(data==null)throw new InvalidDataException("JSON vacío: "+file);return data;}
 public List<Record> ReadMine(){string user=Environment.UserName;return Directory.GetFiles(Root,"*.json",SearchOption.AllDirectories).Where(f=>Path.GetFileName(f).StartsWith(user+"-",StringComparison.OrdinalIgnoreCase)).SelectMany(ReadFile).Where(r=>string.Equals(r.Usuario,user,StringComparison.OrdinalIgnoreCase)).ToList();}
 public List<Record> ReadAll(){return Directory.GetFiles(Root,"*.json",SearchOption.AllDirectories).SelectMany(ReadFile).ToList();}
 public void Save(Record record){string path=FileFor(record.Usuario,record.FechaInicio);Directory.CreateDirectory(Path.GetDirectoryName(path));List<Record> items=ReadFile(path);int i=items.FindIndex(x=>x.Id==record.Id);if(i>=0)items[i]=record;else items.Add(record);string temp=path+".tmp";File.WriteAllText(temp,JsonConvert.SerializeObject(items,Formatting.Indented));if(File.Exists(path))File.Replace(temp,path,null);else File.Move(temp,path);}
}
public class Bar {public string Name{get;set;} public int Count{get;set;} public double Percent{get;set;}}
public class Daily {public string Fecha{get;set;}public int Tratados{get;set;}public int SinInformacion{get;set;}public int RExBU{get;set;}public int RExB1{get;set;}public int RExIG{get;set;}public int RExRECIENTE{get;set;}public int RExNT{get;set;}public int RExPR{get;set;}public int RExVEDACON{get;set;}public int RExFICHEROSNEG{get;set;}public int RExTIPOCTTO{get;set;}public int RExSCORE{get;set;}public int RExRIESGO{get;set;}public int RExLI{get;set;}public int RExAN{get;set;}public int RExBQ{get;set;}public int OkParaEstudio{get;set;}public string PorcentajeRechazo{get;set;}}
