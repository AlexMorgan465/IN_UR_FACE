COFIDIS ESPANA - VERSION .NET FRAMEWORK / WORKSTUDIO
===================================================
Dos aplicaciones WPF nativas: Agent y Manager.
Compilacion: Windows PowerShell, sin dotnet SDK. Ejecutar build.ps1 desde ISE o con una politica de scripts autorizada por IT.
Tambien se puede ejecutar el contenido del script dentro de ISE (si esta permitido).
Requiere .NET Framework 4.x, csc.exe, ensamblados WPF, y permiso para compilar y ejecutar aplicaciones.
No utiliza MSBuild, NuGet, WebView2 ni puertos HTTP.
XAML se carga dinamicamente con XamlReader, por lo que es editable.
Los archivos JSON estan en la ruta configurada en config.json. Copie el mismo RutaDatos en Agent y Manager.
Cada usuario tiene un JSON por mes: MM-yyyy/usuario-MM-yyyy.json.
Manager lee todos los archivos JSON de la raiz configurada.
LIMITACIONES: no incluye control de acceso por usuario (ACL), ni bloqueo entre dos instancias del mismo agente. No desplegar sin estas protecciones. Estadisticas OK para estudio y rechazo son formulas provisionales; validar con negocio.
La compilacion en Windows no ha podido verificarse en este entorno.
