@echo off
powershell.exe -NoLogo -NoProfile -File "%~dp0Lancer.ps1"
