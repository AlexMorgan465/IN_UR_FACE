@echo off
powershell.exe -NoLogo -NoProfile -File "%~dp0Recompiler.ps1"
if errorlevel 1 pause
