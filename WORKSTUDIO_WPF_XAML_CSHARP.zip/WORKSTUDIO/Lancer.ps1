[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
try {
    $exe = Join-Path $PSScriptRoot 'bin\WorkStudio.exe'
    $inputs = @('src','ui','templates','examples') | ForEach-Object { Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot $_) -Recurse -File }
    $inputs += Get-Item -LiteralPath (Join-Path $PSScriptRoot 'Recompiler.ps1')
    $rebuild = !(Test-Path -LiteralPath $exe)
    if (!$rebuild) { $rebuild = @($inputs | Where-Object { $_.LastWriteTimeUtc -gt (Get-Item -LiteralPath $exe).LastWriteTimeUtc }).Count -gt 0 }
    if ($rebuild) {
        & (Join-Path $PSScriptRoot 'Recompiler.ps1')
        if ($LASTEXITCODE -ne 0) { throw 'Compilation impossible. Consultez le message precedent.' }
    }
    Start-Process -FilePath $exe -WorkingDirectory $PSScriptRoot | Out-Null
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    Read-Host 'Entree pour fermer'
    exit 1
}
