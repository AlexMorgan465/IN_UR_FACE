﻿[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$Project,
    [ValidateSet('Debug','Release')][string]$Configuration = 'Debug',
    [string]$OutputDirectory,
    [switch]$Run
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
try {
    $projectPath = (Resolve-Path -LiteralPath $Project).ProviderPath
    if ([IO.Path]::GetExtension($projectPath) -ne '.csproj') { throw 'Selectionnez un fichier .csproj.' }
    [xml]$xml = Get-Content -LiteralPath $projectPath -Raw
    $sdk = $xml.DocumentElement.HasAttribute('Sdk')
    $assembly = @($xml.SelectNodes("//*[local-name()='AssemblyName']")) | Select-Object -Last 1
    $name = if ($assembly) { $assembly.InnerText } else { [IO.Path]::GetFileNameWithoutExtension($projectPath) }
    if ([string]::IsNullOrWhiteSpace($OutputDirectory)) { $OutputDirectory = Join-Path ([IO.Path]::GetDirectoryName($projectPath)) ('bin\' + $Configuration + '\WorkStudio') }
    $OutputDirectory = [IO.Path]::GetFullPath($OutputDirectory)
    New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
    # A trailing backslash before a closing native quote is ambiguous on Windows.
    $outputArg = $OutputDirectory.TrimEnd('\') + '/'
    if ($sdk) {
        $dotnet = Get-Command dotnet.exe -ErrorAction SilentlyContinue
        if (!$dotnet) { throw 'SDK .NET absent. Le modele .NET 8 WPF exige un SDK .NET compatible installe par votre service IT.' }
        & $dotnet.Source build $projectPath --configuration $Configuration --nologo '-v:minimal' "-p:OutputPath=$outputArg"
    } else {
        $candidates = New-Object 'System.Collections.Generic.List[string]'
        $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
        if (Test-Path -LiteralPath $vswhere) {
            & $vswhere -latest -products '*' -requires Microsoft.Component.MSBuild -find 'MSBuild\**\Bin\MSBuild.exe' | ForEach-Object { $candidates.Add($_) }
        }
        $candidates.Add((Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\MSBuild.exe'))
        $candidates.Add((Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\MSBuild.exe'))
        $msbuild = $candidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
        if (!$msbuild) { throw 'MSBuild introuvable. Demandez les outils de compilation .NET Framework/WPF au service IT.' }
        & $msbuild $projectPath /t:Build /nologo /v:minimal "/p:Configuration=$Configuration" "/p:OutputPath=$outputArg" /p:GenerateFullPaths=true
    }
    if ($LASTEXITCODE -ne 0) { throw "Compilation echouee (code $LASTEXITCODE). Consultez les erreurs ci-dessus. Pour MSB3644, le pack de ciblage .NET Framework 4.8 est requis ; pour MSB4019, les outils WPF/MSBuild sont requis." }
    $exe = Join-Path $OutputDirectory ($name + '.exe')
    if (!(Test-Path -LiteralPath $exe)) { throw "Compilation terminee mais executable WPF absent : $exe" }
    Write-Output ('Executable : ' + $exe)
    if ($Run) {
        $application = Start-Process -FilePath $exe -WorkingDirectory ([IO.Path]::GetDirectoryName($projectPath)) -PassThru
        $application.WaitForExit()
        exit $application.ExitCode
    }
    exit 0
} catch {
    [Console]::Error.WriteLine($_.Exception.Message)
    exit 1
}
