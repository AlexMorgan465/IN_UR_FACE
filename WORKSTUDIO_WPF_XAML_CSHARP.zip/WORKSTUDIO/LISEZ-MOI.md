# WorkStudio — WPF, XAML & C#

## Démarrer

1. Extraire tout le ZIP dans un dossier où vous pouvez écrire.
2. Lancer `Lancer.cmd`, ou exécuter `Lancer.ps1` depuis PowerShell.
3. Au premier lancement, PowerShell compile WorkStudio depuis les sources. L'ancien exécutable n'est pas livré dans cette version.
4. Choisir **Nouveau projet → WPF · .NET Framework 4.8**, saisir un nom comme `MonApplication`, puis choisir son dossier parent. Le modèle .NET 8 est également disponible si un SDK compatible est installé.

Sur une première utilisation sans projet récent, un projet WPF de démarrage est créé automatiquement. Si vous utilisiez déjà WorkStudio, votre dernier dossier est rouvert.

## Coder

- `App.xaml` et `App.xaml.cs` : démarrage et ressources de l'application.
- `MainWindow.xaml` : interface native WPF.
- `MainWindow.xaml.cs` : logique C# ; `Bonjour_Click` modifie le `TextBlock` nommé `StatusText`.
- `.csproj` : vrai projet MSBuild, ouvrable dans Visual Studio.
- **XAML ↔ C# / F7** : passer entre les deux fichiers associés.
- **+ Fenêtre / + UserControl** : créer les deux fichiers et inscrire les éléments dans le `.csproj` classique. Les projets SDK incluent les fichiers automatiquement.
- Pour afficher une fenêtre ajoutée depuis votre code : `new MaFenetre().Show();`.
- Pour employer un contrôle, déclarer `xmlns:local="clr-namespace:MonApplication"` sur le conteneur XAML puis y insérer `<local:MonControle />`.
- Ctrl S : enregistrer ; Ctrl Maj S : tout enregistrer ; Ctrl F : rechercher et remplacer.

L'éditeur propose des onglets, numéros de lignes, coloration XML/XAML/C#, indentation et brouillons de récupération. Il ne propose pas encore le concepteur visuel XAML de Visual Studio, la complétion sémantique, les points d'arrêt ou le débogage pas à pas.

## Compiler et exécuter

Choisir le profil **WPF · projet XAML + C# (PowerShell)**. Ce profil est sélectionné à l'ouverture des dossiers comportant un `.csproj`.

**Compiler** enregistre les fichiers modifiés puis lance PowerShell, qui appelle MSBuild pour .NET Framework ou `dotnet build` pour le modèle SDK. Les conflits avec une modification externe bloquent l'enregistrement au lieu d'écraser le fichier.

**Exécuter / F5** compile et ouvre l'application WPF dans sa propre fenêtre native. Le bouton **■** arrête la compilation ou l'application et son groupe de processus. La commande reste active jusqu'à la fermeture de l'application.

Les erreurs de compilation apparaissent dans la console ; les diagnostics reconnus avec fichier et numéro de ligne sont cliquables. Le journal donne le chemin de l'exécutable et de ses dépendances. Le résultat lancé par l'éditeur se trouve dans `%LOCALAPPDATA%\WorkStudio\Builds\…\app`. Conserver l'ensemble du dossier pour une application .NET 8, pas seulement l'EXE.

Si le dossier contient plusieurs projets, cliquer sur le `.csproj` voulu avant de compiler. Les projets peuvent aussi contenir des références de projets ; MSBuild les traite selon leur configuration.

Le modèle créé contient `Compiler.ps1` pour compiler indépendamment de WorkStudio, depuis le dossier du projet :

```powershell
.\Compiler.ps1 -Project '.\MonApplication.csproj'
.\Compiler.ps1 -Project '.\MonApplication.csproj' -Configuration Release
.\Compiler.ps1 -Project '.\MonApplication.csproj' -Run
```

## Prérequis Windows

- Windows 64 bits et .NET Framework 4.8 pour WorkStudio lui-même.
- Runtime Microsoft Edge WebView2 pour l'éditeur hybride existant. Les DLL WebView2 et Newtonsoft.Json fournies dans l'archive d'origine sont conservées.
- Projets WPF .NET Framework 4.8 : MSBuild, tâches WPF et pack de ciblage .NET Framework 4.8. La présence du runtime seul ne garantit pas celle du pack de ciblage. Le script recherche MSBuild de Visual Studio / Build Tools via vswhere, puis celui de Windows.
- Projets WPF .NET 8 : SDK .NET compatible et composants de ciblage Windows Desktop. Une restauration peut demander un accès réseau si les composants nécessaires ne sont pas présents.
- Les scripts doivent être autorisés par la politique PowerShell de votre poste. Cette version ne modifie pas cette politique et ne désactive aucune protection. Si une politique bloque un script, utiliser la procédure de validation de votre service IT.

MSB3644 indique généralement un pack de ciblage manquant ; MSB4019, des cibles de compilation manquantes. Le script affiche ces pistes. Les programmes compilés s'exécutent avec les droits de votre session Windows.

## Autres profils conservés

Les profils Web, console C# / scripts, WPF entièrement écrit en C#, ÉPITHÈTE et JSON Studio restent présents. Les anciens profils C# utilisent le compilateur .NET Framework C# 5 et peuvent compiler les brouillons sans enregistrer ; le profil **WPF projet XAML** utilise les fichiers enregistrés et le compilateur choisi par MSBuild / le SDK.

Le panneau web sert à l'aperçu HTML ; le profil WPF projet masque ce panneau et agrandit l'éditeur. L'aperçu XAML est l'application compilée elle-même.

## Vérification

La syntaxe JavaScript, la structure XML des deux modèles de projet et la logique de l'interface avec un hôte simulé ont été vérifiées dans l'environnement de préparation Linux. La compilation et l'exécution Windows WPF n'ont pas pu être exécutées dans cet environnement.

Tests fournis pour un poste Windows disposant des prérequis :

```powershell
.\validation\Tester-Wpf.ps1
# Ajouter les vérifications du modèle SDK :
.\validation\Tester-Wpf.ps1 -Sdk
```

Ces tests recompilent WorkStudio, génèrent les deux modèles, ajoutent une fenêtre et un contrôle, vérifient les inscriptions dans le projet, compilent réellement le modèle Framework (et le modèle SDK si demandé), puis vérifient le rejet d'un XAML invalide. Ils utilisent un dossier temporaire distinct.

Test de logique d'interface, facultatif avec Node.js : `node validation/UiLogicTests.cjs`. Il utilise un DOM et un moteur natif simulés et ne remplace pas un test Windows.

Documentation de référence :
- https://learn.microsoft.com/en-us/dotnet/desktop/wpf/app-development/building-a-wpf-application-wpf
- https://learn.microsoft.com/en-us/dotnet/core/project-sdk/msbuild-props-desktop
