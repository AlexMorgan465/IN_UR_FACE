using System;
using System.IO;
using System.Linq;
using System.Xml;
using WorkStudio;
using Newtonsoft.Json.Linq;
internal static class WpfTests {
 static void Assert(bool value,string message) { if(!value)throw new Exception(message);Console.WriteLine("PASS "+message); }
 public static int Main(string[] args) {try {
 string root=args[0];Directory.CreateDirectory(root);string home=Path.Combine(root,"drafts");
 foreach(bool sdk in new[]{false,true}) {
 string name=sdk?"DemoSdk":"DemoFramework",folder=Path.Combine(root,name);Directory.CreateDirectory(folder);WpfProjects.Create(folder,name,sdk);
 var xml=new XmlDocument();xml.Load(Path.Combine(folder,name+".csproj"));
 Assert(sdk?xml.DocumentElement.GetAttribute("Sdk")=="Microsoft.NET.Sdk":xml.SelectNodes("//*[local-name()='ApplicationDefinition']").Count==1,"Project model "+name);
 foreach(string file in new[]{"App.xaml","MainWindow.xaml"}) {var xaml=new XmlDocument();xaml.Load(Path.Combine(folder,file));Assert(xaml.DocumentElement!=null,"Well formed "+name+"/"+file);}
 var ws=new Workspace(home);Assert(J.S(ws.Open(folder),"profile")=="wpf-project","WPF project detection");Assert(Runner.SelectProject(ws,"MainWindow.xaml")==name+".csproj","Compile from XAML selects csproj");
 WpfProjects.Add(ws,name+".csproj","MaFenetre",false);WpfProjects.Add(ws,name+".csproj","MaCarte",true);
 Assert(File.Exists(Path.Combine(folder,"MaFenetre.xaml.cs"))&&File.Exists(Path.Combine(folder,"MaCarte.xaml.cs")),"Paired code behind creation");
 Assert(((JArray)ws.State()["files"]).Any(x=>(string)x=="MaCarte.xaml"),"XAML appears in explorer");
 Assert(!ws.Dirty,"Project update saved before compilation");
 if(!sdk){xml.Load(Path.Combine(folder,name+".csproj"));Assert(xml.SelectNodes("//*[local-name()='Page']").Count==3&&xml.SelectNodes("//*[local-name()='Compile']").Count==4,"Framework csproj includes new items");}
 bool duplicate=false;try{WpfProjects.Add(ws,name+".csproj","MaFenetre",false);}catch(IOException){duplicate=true;}Assert(duplicate,"Duplicate item refused");
 }
 foreach(string bad in new[]{"Deux mots","class","a.b","../oops","99Test"}){bool rejected=false;try{WpfProjects.Identifier(bad);}catch(IOException){rejected=true;}Assert(rejected,"Invalid identifier refused: "+bad);}
 return 0;
 }catch(Exception error){Console.Error.WriteLine(error);return 1;} }
}
