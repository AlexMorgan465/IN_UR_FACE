[CmdletBinding()]
param([switch]$Sdk)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$testRoot = Join-Path ([IO.Path]::GetTempPath()) ('WorkStudio WPF ete ' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $testRoot | Out-Null
try {
    & (Join-Path $root 'Recompiler.ps1')
    if ($LASTEXITCODE -ne 0) { throw 'Compilation WorkStudio en echec.' }
    $framework = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
    $compiler = Join-Path $framework 'csc.exe'
    $testExe = Join-Path $testRoot 'WpfTests.exe'
    $options = @('/nologo','/target:exe','/langversion:5','/codepage:65001',('/out:'+$testExe),
        '/reference:System.Core.dll','/reference:System.Xml.dll','/reference:System.Numerics.dll',
        ('/reference:'+(Join-Path $root 'lib\Newtonsoft.Json.dll')),
        ('/resource:'+(Join-Path $root 'templates\Compiler-Wpf.ps1')+',WorkStudio.Templates.Compiler-Wpf.ps1'))
    foreach ($file in @('src\Workspace.cs','src\Runner.cs','src\WpfProjects.cs','validation\WpfTests.cs')) { $options += Join-Path $root $file }
    & $compiler @options
    if ($LASTEXITCODE -ne 0) { throw 'Compilation des tests en echec.' }
    Copy-Item -LiteralPath (Join-Path $root 'lib\Newtonsoft.Json.dll') -Destination $testRoot
    & $testExe $testRoot
    if ($LASTEXITCODE -ne 0) { throw 'Tests de generation en echec.' }
    $models = @('DemoFramework')
    if ($Sdk) { $models += 'DemoSdk' }
    foreach ($model in $models) {
        $project = Join-Path $testRoot ($model+'\'+$model+'.csproj')
        & powershell.exe -NoLogo -NoProfile -NonInteractive -File (Join-Path $root 'templates\Compiler-Wpf.ps1') -Project $project
        if ($LASTEXITCODE -ne 0) { throw "Compilation reelle $model en echec. Verifiez les prerequis affiches." }
        $badXaml = Join-Path $testRoot ($model+'\MainWindow.xaml')
        $original = [IO.File]::ReadAllText($badXaml)
        try {
            [IO.File]::WriteAllText($badXaml, '<Window><Broken>')
            & powershell.exe -NoLogo -NoProfile -NonInteractive -File (Join-Path $root 'templates\Compiler-Wpf.ps1') -Project $project
            if ($LASTEXITCODE -eq 0) { throw 'Un XAML invalide a ete accepte.' }
            Write-Host "PASS $model : erreur XAML signalee" -ForegroundColor Green
        } finally { [IO.File]::WriteAllText($badXaml,$original) }
    }
    Write-Host "Tests WPF termines. Dossier : $testRoot" -ForegroundColor Green
} catch { Write-Host $_.Exception.Message -ForegroundColor Red; exit 1 }
