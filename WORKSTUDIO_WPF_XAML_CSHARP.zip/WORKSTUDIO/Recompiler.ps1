[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
try {
    $root = $PSScriptRoot
    $framework = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
    $compiler = Join-Path $framework 'csc.exe'
    if (!(Test-Path -LiteralPath $compiler)) { throw 'Compilateur .NET Framework x64 introuvable.' }
    $out = Join-Path $root 'bin'
    New-Item -ItemType Directory -Force -Path $out | Out-Null
    $options = @('/nologo','/target:winexe','/platform:x64','/optimize+','/langversion:5','/codepage:65001',
        ('/out:' + (Join-Path $out 'WorkStudio.exe')), ('/win32manifest:' + (Join-Path $root 'src\app.manifest')))
    foreach ($reference in @('System.dll','System.Core.dll','System.Xml.dll','System.Numerics.dll','System.Xaml.dll','System.Windows.Forms.dll')) { $options += '/reference:' + (Join-Path $framework $reference) }
    foreach ($reference in @('WindowsBase.dll','PresentationCore.dll','PresentationFramework.dll')) { $options += '/reference:' + (Join-Path $framework ('WPF\' + $reference)) }
    foreach ($reference in @('Newtonsoft.Json.dll','Microsoft.Web.WebView2.Core.dll','Microsoft.Web.WebView2.Wpf.dll')) { $options += '/reference:' + (Join-Path $root ('lib\' + $reference)) }
    foreach ($file in Get-ChildItem -LiteralPath (Join-Path $root 'ui') -File) { $options += '/resource:' + $file.FullName + ',WorkStudio.UI.' + $file.Name }
    $templates = @{
        'examples\web\index.html'='demo.html'; 'examples\web\style.css'='demo.css';
        'examples\web\app.js'='demo.js'; 'examples\csharp\Main.cs'='demo.cs';
        'templates\Compiler-Wpf.ps1'='Compiler-Wpf.ps1'
    }
    foreach ($entry in $templates.GetEnumerator()) { $options += '/resource:' + (Join-Path $root $entry.Key) + ',WorkStudio.Templates.' + $entry.Value }
    $options += @(Get-ChildItem -LiteralPath (Join-Path $root 'src') -Filter '*.cs' | ForEach-Object { $_.FullName })
    & $compiler @options
    if ($LASTEXITCODE -ne 0) { throw "Compilation WorkStudio echouee (code $LASTEXITCODE)." }
    Copy-Item -LiteralPath (Join-Path $root 'src\app.config') -Destination (Join-Path $out 'WorkStudio.exe.config') -Force
    Get-ChildItem -LiteralPath (Join-Path $root 'lib') -Filter '*.dll' | Copy-Item -Destination $out -Force
    Write-Host 'WorkStudio WPF compile.' -ForegroundColor Green
} catch { Write-Error $_; exit 1 }
