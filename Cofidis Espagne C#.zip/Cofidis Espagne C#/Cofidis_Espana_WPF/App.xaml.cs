using System.Windows;
namespace Cofidis_Espana;
public partial class App : Application { }
