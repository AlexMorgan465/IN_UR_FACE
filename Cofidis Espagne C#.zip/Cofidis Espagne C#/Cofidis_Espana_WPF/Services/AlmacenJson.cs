using System.IO;
using System.Text.Json;
using Cofidis_Espana.Models;
namespace Cofidis_Espana.Services;
public sealed class AlmacenJson
{
    private readonly string raiz;
    private readonly string usuario = Environment.UserName;
    private static readonly JsonSerializerOptions Opciones = new() { WriteIndented = true, PropertyNameCaseInsensitive = true };
    public string RutaDatos => raiz;
    public AlmacenJson()
    {
        string configuracion = Path.Combine(AppContext.BaseDirectory, "config.json");
        if (!File.Exists(configuracion)) throw new FileNotFoundException("No se encuentra config.json", configuracion);
        using var documento = JsonDocument.Parse(File.ReadAllText(configuracion));
        string? valor = documento.RootElement.GetProperty("RutaDatos").GetString();
        if (string.IsNullOrWhiteSpace(valor)) throw new InvalidDataException("RutaDatos está vacía en config.json");
        raiz = Path.GetFullPath(Environment.ExpandEnvironmentVariables(valor));
        Directory.CreateDirectory(raiz);
    }
    private string Archivo(DateTime fecha) => Path.Combine(raiz, fecha.ToString("MM-yyyy"), $"{usuario}-{fecha:MM-yyyy}.json");
    public List<Tratamiento> LeerArchivo(string ruta)
    {
        if (!File.Exists(ruta)) return new();
        return JsonSerializer.Deserialize<List<Tratamiento>>(File.ReadAllText(ruta), Opciones)
            ?? throw new InvalidDataException($"JSON vacío o inválido: {ruta}");
    }
    public List<Tratamiento> LeerMes(DateTime fecha) => LeerArchivo(Archivo(fecha));
    public List<Tratamiento> LeerTodos()
    {
        if (!Directory.Exists(raiz)) return new();
        var lista = new List<Tratamiento>();
        foreach (string ruta in Directory.EnumerateFiles(raiz, $"{usuario}-*.json", SearchOption.AllDirectories))
            lista.AddRange(LeerArchivo(ruta).Where(x => string.Equals(x.Usuario, usuario, StringComparison.OrdinalIgnoreCase)));
        return lista;
    }
    public void Guardar(Tratamiento registro)
    {
        string ruta = Archivo(registro.FechaInicio);
        Directory.CreateDirectory(Path.GetDirectoryName(ruta)!);
        var registros = LeerArchivo(ruta);
        int posicion = registros.FindIndex(x => x.Id == registro.Id);
        if (posicion >= 0) registros[posicion] = registro;
        else registros.Add(registro);
        string temporal = ruta + ".tmp";
        File.WriteAllText(temporal, JsonSerializer.Serialize(registros, Opciones));
        File.Move(temporal, ruta, true);
    }
}
