namespace Cofidis_Espana.Models;
public sealed class Tratamiento
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Usuario { get; set; } = "";
    public string Referencia { get; set; } = "";
    public string Taf { get; set; } = "";
    public string Decision { get; set; } = "";
    public string Comentario { get; set; } = "";
    public DateTime FechaInicio { get; set; }
    public DateTime? FechaFin { get; set; }
    public string Estado { get; set; } = "En curso";
    public double? DmtSegundos => FechaFin.HasValue ? Math.Max(0, (FechaFin.Value - FechaInicio).TotalSeconds) : null;
    public string Dmt => DmtSegundos.HasValue ? TimeSpan.FromSeconds(DmtSegundos.Value).ToString(@"hh\:mm\:ss") : "—";
}
