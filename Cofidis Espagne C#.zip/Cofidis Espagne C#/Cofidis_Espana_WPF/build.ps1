$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
dotnet publish .\Cofidis_Espana.csproj -c Release -r win-x64 --self-contained false -p:PublishSingleFile=false
if ($LASTEXITCODE -ne 0) { throw 'Error de compilación.' }
Write-Host 'Aplicación compilada en bin\Release\net8.0-windows\win-x64\publish' -ForegroundColor Green
