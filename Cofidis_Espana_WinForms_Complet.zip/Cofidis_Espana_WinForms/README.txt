COFIDIS ESPANA - WINFORMS / C# / POWERSHELL
==========================================
COMPILACION
- Abrir build.ps1 en PowerShell ISE y ejecutar desde el editor (o usar una consola donde la politica corporativa permita scripts).
- No se requiere dotnet, PresentationCore.dll ni SDK .NET 8.
- Requiere .NET Framework 4.x con System.Windows.Forms y csc.exe disponibles.
- Ejecutables: Agent/bin/CofidisEspanaAgent.exe y Manager/bin/CofidisEspanaManager.exe.
- El script copia config.json y Newtonsoft.Json.dll junto a cada EXE.

CONFIGURACION
- Editar Agent/config.json y Manager/config.json ANTES de compilar.
- Despues de compilar, editar el config.json situado JUNTO AL EXE para cambiar la ruta.
- RutaDatos admite variables %LOCALAPPDATA% o ruta UNC como \\\\servidor\\compartido\\CofidisEspana.
- Para consolidar todos los agentes, deben apuntar al mismo directorio compartido.
- Archivos mensuales por usuario: MM-yyyy/USUARIO-MM-yyyy.json.
- Las referencias duplicadas estan permitidas. Solo un tratamiento activo por agente.
- La aplicacion Agent no presenta datos de otros usuarios.
- Para impedir acceso fisico a archivos de otros agentes, configurar permisos NTFS/compartido.

MANAGER
- Panel de control: KPI y graficos de barras GDI+ por TAF, decision, agente, dia y DMT medio.
- Consolidacion y estadisticas diarias con filtros por fecha, usuario, TAF y estado.
- Exportaciones CSV UTF-8 con separador ';', compatibles con Excel.
- No se genera XLSX nativo en esta version; los CSV se abren con Excel.
- 'Tratados' y 'Ok para estudio' se tratan como decisiones diferentes.
- Porcentaje de rechazo = decisiones REx* / tratamientos terminados.
- Validar estas reglas de negocio antes de usar para facturacion o reporting oficial.

LIMITACIONES
- Sin proteccion interprocesos ni transaccion de archivos compartidos: no ejecutar dos instancias Agent para el mismo usuario.
- La lectura Manager es manual con Actualizar JSON.
- No compilado en Windows en este entorno: probar en un equipo de test antes de despliegue.
