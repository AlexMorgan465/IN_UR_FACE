$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$compiler = "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if (!(Test-Path $compiler)) { $compiler = "$env:WINDIR\Microsoft.NET\Framework\v4.0.30319\csc.exe" }
if (!(Test-Path $compiler)) { throw 'Compilador csc.exe no encontrado.' }
$lib = Join-Path $PSScriptRoot 'lib\Newtonsoft.Json.dll'
foreach ($app in @('Agent','Manager')) {
  $dir = Join-Path $PSScriptRoot $app
  $bin = Join-Path $dir 'bin'
  New-Item -ItemType Directory -Force -Path $bin | Out-Null
  $exe = Join-Path $bin ("CofidisEspana"+$app+".exe")
  $src = Join-Path $dir 'Program.cs'
  $common = Join-Path $PSScriptRoot 'Shared\Core.cs'
  & $compiler /nologo /target:winexe /optimize+ "/out:$exe" "/reference:$lib" /reference:System.dll /reference:System.Core.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll /reference:System.Web.Extensions.dll $common $src
  if ($LASTEXITCODE -ne 0) { throw "Error compilando $app (codigo $LASTEXITCODE)" }
  Copy-Item $lib (Join-Path $bin 'Newtonsoft.Json.dll') -Force
  Copy-Item (Join-Path $dir 'config.json') (Join-Path $bin 'config.json') -Force
  Write-Host "OK: $exe" -ForegroundColor Green
}
