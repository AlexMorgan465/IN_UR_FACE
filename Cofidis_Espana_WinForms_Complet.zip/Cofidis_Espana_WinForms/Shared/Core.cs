using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

public class Registro {
 public string Id {get;set;} public string Usuario {get;set;} public string Referencia {get;set;} public string Taf {get;set;} public string Decision {get;set;} public string Comentario {get;set;}
 public DateTime FechaInicio {get;set;} public DateTime? FechaFin {get;set;} public string Estado {get;set;}
 [JsonIgnore] public double? DmtSegundos {get{return FechaFin.HasValue?(double?)(FechaFin.Value-FechaInicio).TotalSeconds:null;}}
 [JsonIgnore] public string Dmt {get{return DmtSegundos.HasValue?TimeSpan.FromSeconds(Math.Max(0,DmtSegundos.Value)).ToString(@"hh\:mm\:ss"):"";}}
}
public class Datos {
 public string Raiz {get;private set;}
 public Datos(string config){ if(!File.Exists(config))throw new FileNotFoundException("Falta config.json",config); var obj=JObject.Parse(File.ReadAllText(config)); string p=(string)obj["RutaDatos"];if(string.IsNullOrWhiteSpace(p))throw new Exception("RutaDatos vacía");Raiz=Path.GetFullPath(Environment.ExpandEnvironmentVariables(p));Directory.CreateDirectory(Raiz); }
 public string Ruta(Registro r){return Path.Combine(Raiz,r.FechaInicio.ToString("MM-yyyy"),r.Usuario+"-"+r.FechaInicio.ToString("MM-yyyy")+".json");}
 public List<Registro> Leer(string p){if(!File.Exists(p))return new List<Registro>();var x=JsonConvert.DeserializeObject<List<Registro>>(File.ReadAllText(p));if(x==null)throw new InvalidDataException("JSON inválido: "+p);return x;}
 public List<Registro> Todos(){return Directory.GetFiles(Raiz,"*.json",SearchOption.AllDirectories).SelectMany(Leer).ToList();}
 public List<Registro> Mios(){string u=Environment.UserName;return Directory.GetFiles(Raiz,u+"-*.json",SearchOption.AllDirectories).SelectMany(Leer).Where(x=>string.Equals(x.Usuario,u,StringComparison.OrdinalIgnoreCase)).ToList();}
 public void Guardar(Registro r){string p=Ruta(r);Directory.CreateDirectory(Path.GetDirectoryName(p));var list=Leer(p);int i=list.FindIndex(x=>x.Id==r.Id);if(i>=0)list[i]=r;else list.Add(r);string temp=p+"."+Guid.NewGuid().ToString("N")+".tmp";File.WriteAllText(temp,JsonConvert.SerializeObject(list,Formatting.Indented));if(File.Exists(p))File.Replace(temp,p,null);else File.Move(temp,p);}
}
public static class Csv {
 public static void Exportar(string path,string[] headers,IEnumerable<string[]> rows){using(var w=new StreamWriter(path,false,new System.Text.UTF8Encoding(true))){w.WriteLine(string.Join(";",headers.Select(E)));foreach(var r in rows)w.WriteLine(string.Join(";",r.Select(E)));}}
 static string E(string s){return "\""+(s??"").Replace("\"","\"\"")+"\"";}
}
public static class Ui {
 public static System.Drawing.Color Red=System.Drawing.Color.FromArgb(196,0,35);
 public static System.Windows.Forms.Label Label(string s,int x,int y,int w=260){return new System.Windows.Forms.Label{Text=s,Left=x,Top=y,Width=w,Height=23,Font=new System.Drawing.Font("Segoe UI",9,System.Drawing.FontStyle.Bold)};}
 public static System.Windows.Forms.Button Button(string s,int x,int y,int w=240){return new System.Windows.Forms.Button{Text=s,Left=x,Top=y,Width=w,Height=36,BackColor=Red,ForeColor=System.Drawing.Color.White,FlatStyle=System.Windows.Forms.FlatStyle.Flat,Font=new System.Drawing.Font("Segoe UI",9,System.Drawing.FontStyle.Bold)};}
 public static System.Windows.Forms.DataGridView Grid(){return new System.Windows.Forms.DataGridView{Dock=System.Windows.Forms.DockStyle.Fill,ReadOnly=true,AllowUserToAddRows=false,AllowUserToDeleteRows=false,AutoSizeColumnsMode=System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill,BackgroundColor=System.Drawing.Color.White,SelectionMode=System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect,MultiSelect=false,RowHeadersVisible=false};}
}
