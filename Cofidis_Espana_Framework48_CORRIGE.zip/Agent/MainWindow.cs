﻿using System; using System.IO; using System.Linq; using System.Collections.Generic; using System.Windows; using System.Windows.Controls; using System.Windows.Markup; using System.Windows.Media; using System.Web.Script.Serialization; using Microsoft.Win32; using System.Text; using System.IO.Compression; using System.Xml;
namespace CofidisEspana48 { public partial class MainWindow : Window {
private TextBlock UsuarioTexto;
private TextBlock RutaTexto;
private TextBox ReferenciaCaja;
private ComboBox TafCaja;
private Button AgregarBoton;
private ComboBox DecisionCaja;
private TextBox ComentarioCaja;
private Button FinalizarBoton;
private TextBlock EstadoTexto;
private TextBlock InicioTexto;
private TextBlock ResumenTexto;
private TextBox BusquedaCaja;
private DataGrid Tabla;
private Button AutoButton0;
private IEnumerable<Button> Buttons(string key){switch(key){case "Agregar_Click": return new Button[]{AgregarBoton};case "Finalizar_Click": return new Button[]{FinalizarBoton};case "Actualizar_Click": return new Button[]{AutoButton0};default:return new Button[0];}}
public MainWindow(){InitializeComponent();Wire();try{Init();}catch(Exception ex){MessageBox.Show(ex.Message,"Error",MessageBoxButton.OK,MessageBoxImage.Error);}}

private string ConfigRuta(){string cfg=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"config.json");var obj=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(cfg));string path=Convert.ToString(obj["RutaDatos"]);if(string.IsNullOrWhiteSpace(path))throw new Exception("RutaDatos vacía");return Path.GetFullPath(Environment.ExpandEnvironmentVariables(path));}
private void InitializeComponent(){string path=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"MainWindow.xaml");var xml=File.ReadAllText(path);var root=(Window)XamlReader.Parse(xml);this.Title=root.Title;this.Width=root.Width;this.Height=root.Height;this.MinWidth=root.MinWidth;this.MinHeight=root.MinHeight;this.Background=root.Background;this.FontFamily=root.FontFamily;this.Resources=root.Resources;var contenu=root.Content;root.Content=null;this.Content=contenu;
  UsuarioTexto = (TextBlock)root.FindName("UsuarioTexto");
  RutaTexto = (TextBlock)root.FindName("RutaTexto");
  ReferenciaCaja = (TextBox)root.FindName("ReferenciaCaja");
  TafCaja = (ComboBox)root.FindName("TafCaja");
  AgregarBoton = (Button)root.FindName("AgregarBoton");
  DecisionCaja = (ComboBox)root.FindName("DecisionCaja");
  ComentarioCaja = (TextBox)root.FindName("ComentarioCaja");
  FinalizarBoton = (Button)root.FindName("FinalizarBoton");
  EstadoTexto = (TextBlock)root.FindName("EstadoTexto");
  InicioTexto = (TextBlock)root.FindName("InicioTexto");
  ResumenTexto = (TextBlock)root.FindName("ResumenTexto");
  BusquedaCaja = (TextBox)root.FindName("BusquedaCaja");
  Tabla = (DataGrid)root.FindName("Tabla");
  AutoButton0 = (Button)root.FindName("AutoButton0");
}

private string usuario=Environment.UserName, raiz; private List<Tratamiento> registros=new List<Tratamiento>(); private Tratamiento activo;
private string[] tafs={"46580","46603","46578","46650","46628","46575"};
private string[] decisiones={"fecha","Tratados","sin información para pre-estudio","RExBU","RExB1","RExIG","RExRECIENTE","RExNT","RExPR","RExVEDACON","RExFICHEROS NEG","RExTIPO CTTO","RExSCORE","RExRIESGO","RExLI","RExAN","RExBQ"};
private string Archivo(DateTime dt){return Path.Combine(raiz,dt.ToString("MM-yyyy"),usuario+"-"+dt.ToString("MM-yyyy")+".json");}
private List<Tratamiento> Leer(string f){return File.Exists(f)?new JavaScriptSerializer(){MaxJsonLength=int.MaxValue}.Deserialize<List<Tratamiento>>(File.ReadAllText(f)):new List<Tratamiento>();}
private void Cargar(){registros=new List<Tratamiento>();if(Directory.Exists(raiz))foreach(var f in Directory.GetFiles(raiz,usuario+"-*.json",SearchOption.AllDirectories))registros.AddRange(Leer(f).Where(t=>string.Equals(t.Usuario,usuario,StringComparison.OrdinalIgnoreCase)));var abiertos=registros.Where(t=>t.Estado=="En curso").OrderBy(t=>t.FechaInicio).ToList();activo=abiertos.FirstOrDefault();if(abiertos.Count>1){MessageBox.Show("Hay varios tratamientos abiertos. Contacte al responsable.");AgregarBoton.IsEnabled=false;}if(activo!=null){ReferenciaCaja.Text=activo.Referencia;TafCaja.SelectedItem=activo.Taf;DecisionCaja.SelectedItem=activo.Decision;ComentarioCaja.Text=activo.Comentario;}ActualizarEstado();MostrarTabla();}
private void Guardar(Tratamiento t){string f=Archivo(t.FechaInicio);Directory.CreateDirectory(Path.GetDirectoryName(f));var lista=Leer(f);int i=lista.FindIndex(a=>a.Id==t.Id);if(i<0)lista.Add(t);else lista[i]=t;string tmp=f+"."+Guid.NewGuid().ToString("N")+".tmp";File.WriteAllText(tmp,new JavaScriptSerializer(){MaxJsonLength=int.MaxValue}.Serialize(lista),Encoding.UTF8);if(File.Exists(f))File.Replace(tmp,f,null);else File.Move(tmp,f);}
private void ActualizarEstado(){bool b=activo!=null;ReferenciaCaja.IsEnabled=!b;TafCaja.IsEnabled=!b;AgregarBoton.IsEnabled=!b;DecisionCaja.IsEnabled=b;ComentarioCaja.IsEnabled=b;FinalizarBoton.IsEnabled=b;EstadoTexto.Text=b?"En curso · "+activo.Referencia+" · TAF "+activo.Taf:"Sin tratamiento activo";InicioTexto.Text=b?"Inicio: "+activo.FechaInicio.ToString("dd/MM/yyyy HH:mm:ss"):"Puede iniciar una nueva llamada";}
private void MostrarTabla(){string q=BusquedaCaja.Text.Trim();var hoy=registros.Where(t=>t.FechaInicio.Date==DateTime.Today&&(q.Length==0||t.Referencia.IndexOf(q,StringComparison.OrdinalIgnoreCase)>=0||t.Taf.IndexOf(q,StringComparison.OrdinalIgnoreCase)>=0||t.Decision.IndexOf(q,StringComparison.OrdinalIgnoreCase)>=0)).OrderByDescending(t=>t.FechaInicio).ToList();Tabla.ItemsSource=hoy;ResumenTexto.Text=registros.Count(t=>t.FechaInicio.Date==DateTime.Today&&t.Estado=="Finalizado")+" finalizados hoy · "+(activo==null?"Sin llamada activa":"1 llamada en curso");}
private void Agregar_Click(object s,RoutedEventArgs e){if(activo!=null)return;string r=ReferenciaCaja.Text.Trim(),t=TafCaja.SelectedItem as string;if(r.Length==0||string.IsNullOrWhiteSpace(t)){MessageBox.Show("Introduzca una referencia y seleccione un TAF.");return;}try{Cargar();if(activo!=null){MessageBox.Show("Ya existe un tratamiento en curso.");return;}var n=new Tratamiento{Usuario=usuario,Referencia=r,Taf=t,FechaInicio=DateTime.Now};Guardar(n);activo=n;registros=registros.Concat(new[]{n}).ToList();DecisionCaja.SelectedItem=null;ComentarioCaja.Clear();ActualizarEstado();MostrarTabla();}catch(Exception ex){MessageBox.Show(ex.Message);}}
private void Finalizar_Click(object s,RoutedEventArgs e){if(activo==null)return;string dec=DecisionCaja.SelectedItem as string;if(string.IsNullOrWhiteSpace(dec)){MessageBox.Show("Seleccione una decisión.");return;}try{activo.Decision=dec;activo.Comentario=ComentarioCaja.Text.Trim();activo.FechaFin=DateTime.Now;activo.Estado="Finalizado";Guardar(activo);activo=null;ReferenciaCaja.Clear();TafCaja.SelectedItem=null;DecisionCaja.SelectedItem=null;ComentarioCaja.Clear();Cargar();}catch(Exception ex){MessageBox.Show(ex.Message);}}
private void Actualizar_Click(object s,RoutedEventArgs e){try{Cargar();}catch(Exception ex){MessageBox.Show(ex.Message);}}
private void Busqueda_TextChanged(object s,TextChangedEventArgs e){if(Tabla!=null&&registros!=null)MostrarTabla();}
private void Init(){TafCaja.ItemsSource=tafs;DecisionCaja.ItemsSource=decisiones;UsuarioTexto.Text="Hola, "+usuario;raiz=ConfigRuta();RutaTexto.Text=raiz;Cargar();}
private void Wire(){AgregarBoton.Click+=Agregar_Click;FinalizarBoton.Click+=Finalizar_Click;BusquedaCaja.TextChanged+=Busqueda_TextChanged;foreach(var b in Buttons("Actualizar_Click"))b.Click+=Actualizar_Click;}

}}