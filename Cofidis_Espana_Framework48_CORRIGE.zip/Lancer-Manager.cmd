@echo off
cd /d "%~dp0"
if not exist "%~dp0Manager\bin\Cofidis-Espana-Manager.exe" (echo Compilez avec Compiler.cmd & pause & exit /b 1)
start "" "%~dp0Manager\bin\Cofidis-Espana-Manager.exe"
