﻿using System; using System.IO; using System.Linq; using System.Collections.Generic; using System.Windows; using System.Windows.Controls; using System.Windows.Markup; using System.Windows.Media; using System.Web.Script.Serialization; using Microsoft.Win32; using System.Text; using System.IO.Compression; using System.Xml;
namespace CofidisEspana48 { public partial class MainWindow : Window {
private TextBlock RutaTexto;
private DatePicker Desde;
private DatePicker Hasta;
private ComboBox Agente;
private ComboBox Taf;
private ComboBox Estado;
private TextBlock KpiTotal;
private TextBlock KpiFinal;
private TextBlock KpiCurso;
private TextBlock KpiDmt;
private TextBlock KpiAgentes;
private ItemsControl BarrasDecision;
private ItemsControl BarrasTaf;
private DataGrid Evolucion;
private ItemsControl BarrasDmt;
private DataGrid TablaDetalle;
private DataGrid TablaStats;
private TextBlock EstadoTexto;
private Button AutoButton0;
private Button AutoButton1;
private Button AutoButton2;
private Button AutoButton3;
private Button AutoButton4;
private Button AutoButton5;
private IEnumerable<Button> Buttons(string key){switch(key){case "Actualizar_Click": return new Button[]{AutoButton0};case "Limpiar_Click": return new Button[]{AutoButton1};case "CsvDetalle_Click": return new Button[]{AutoButton2};case "XlsxDetalle_Click": return new Button[]{AutoButton3};case "CsvStats_Click": return new Button[]{AutoButton4};case "XlsxStats_Click": return new Button[]{AutoButton5};default:return new Button[0];}}
public MainWindow(){InitializeComponent();Wire();try{Init();}catch(Exception ex){MessageBox.Show(ex.Message,"Error",MessageBoxButton.OK,MessageBoxImage.Error);}}

private string ConfigRuta(){string cfg=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"config.json");var obj=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(cfg));string path=Convert.ToString(obj["RutaDatos"]);if(string.IsNullOrWhiteSpace(path))throw new Exception("RutaDatos vacía");return Path.GetFullPath(Environment.ExpandEnvironmentVariables(path));}
private void InitializeComponent(){string path=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"MainWindow.xaml");var xml=File.ReadAllText(path);var root=(Window)XamlReader.Parse(xml);this.Title=root.Title;this.Width=root.Width;this.Height=root.Height;this.MinWidth=root.MinWidth;this.MinHeight=root.MinHeight;this.Background=root.Background;this.FontFamily=root.FontFamily;this.Resources=root.Resources;var contenu=root.Content;root.Content=null;this.Content=contenu;
  RutaTexto = (TextBlock)root.FindName("RutaTexto");
  Desde = (DatePicker)root.FindName("Desde");
  Hasta = (DatePicker)root.FindName("Hasta");
  Agente = (ComboBox)root.FindName("Agente");
  Taf = (ComboBox)root.FindName("Taf");
  Estado = (ComboBox)root.FindName("Estado");
  KpiTotal = (TextBlock)root.FindName("KpiTotal");
  KpiFinal = (TextBlock)root.FindName("KpiFinal");
  KpiCurso = (TextBlock)root.FindName("KpiCurso");
  KpiDmt = (TextBlock)root.FindName("KpiDmt");
  KpiAgentes = (TextBlock)root.FindName("KpiAgentes");
  BarrasDecision = (ItemsControl)root.FindName("BarrasDecision");
  BarrasTaf = (ItemsControl)root.FindName("BarrasTaf");
  Evolucion = (DataGrid)root.FindName("Evolucion");
  BarrasDmt = (ItemsControl)root.FindName("BarrasDmt");
  TablaDetalle = (DataGrid)root.FindName("TablaDetalle");
  TablaStats = (DataGrid)root.FindName("TablaStats");
  EstadoTexto = (TextBlock)root.FindName("EstadoTexto");
  AutoButton0 = (Button)root.FindName("AutoButton0");
  AutoButton1 = (Button)root.FindName("AutoButton1");
  AutoButton2 = (Button)root.FindName("AutoButton2");
  AutoButton3 = (Button)root.FindName("AutoButton3");
  AutoButton4 = (Button)root.FindName("AutoButton4");
  AutoButton5 = (Button)root.FindName("AutoButton5");
}

private List<Tratamiento> todos=new List<Tratamiento>(),filtrados=new List<Tratamiento>();private List<EstadisticaDia> estadisticas=new List<EstadisticaDia>();private bool inicializando=true;private string raiz;
private string[] decisiones={"sin información para pre-estudio","RExBU","RExB1","RExIG","RExRECIENTE","RExNT","RExPR","RExVEDACON","RExFICHEROS NEG","RExTIPO CTTO","RExSCORE","RExRIESGO","RExLI","RExAN","RExBQ"};
private void Init(){raiz=ConfigRuta();RutaTexto.Text=raiz;inicializando=false;Actualizar();}
private void Actualizar(){try{var l=new List<Tratamiento>();int errors=0;if(Directory.Exists(raiz))foreach(var f in Directory.GetFiles(raiz,"*.json",SearchOption.AllDirectories)){if(Path.GetFileName(f).Equals("config.json",StringComparison.OrdinalIgnoreCase))continue;try{l.AddRange(new JavaScriptSerializer(){MaxJsonLength=int.MaxValue}.Deserialize<List<Tratamiento>>(File.ReadAllText(f)));}catch{errors++;}}todos=l.GroupBy(t=>t.Id).Select(g=>g.First()).ToList();inicializando=true;string a=Agente.SelectedItem as string,t=Taf.SelectedItem as string,s=Estado.SelectedItem as string;Agente.ItemsSource=new[]{"Todos"}.Concat(todos.Select(x=>x.Usuario).Distinct().OrderBy(x=>x)).ToList();Taf.ItemsSource=new[]{"Todos"}.Concat(todos.Select(x=>x.Taf).Distinct().OrderBy(x=>x)).ToList();Estado.ItemsSource=new[]{"Todos"}.Concat(todos.Select(x=>x.Estado).Distinct().OrderBy(x=>x)).ToList();Agente.SelectedItem=Agente.Items.Contains(a)?a:"Todos";Taf.SelectedItem=Taf.Items.Contains(t)?t:"Todos";Estado.SelectedItem=Estado.Items.Contains(s)?s:"Todos";inicializando=false;Filtrar();EstadoTexto.Text=todos.Count+" registros · "+errors+" archivos con error";}catch(Exception ex){MessageBox.Show(ex.Message);}}
private void Filtrar(){if(inicializando)return;DateTime? d=Desde.SelectedDate,h=Hasta.SelectedDate;string a=Agente.SelectedItem as string??"Todos",t=Taf.SelectedItem as string??"Todos",s=Estado.SelectedItem as string??"Todos";filtrados=todos.Where(x=>(!d.HasValue||x.FechaInicio.Date>=d.Value.Date)&&(!h.HasValue||x.FechaInicio.Date<=h.Value.Date)&&(a=="Todos"||x.Usuario==a)&&(t=="Todos"||x.Taf==t)&&(s=="Todos"||x.Estado==s)).OrderByDescending(x=>x.FechaInicio).ToList();TablaDetalle.ItemsSource=filtrados;var fin=filtrados.Where(x=>x.FechaFin.HasValue).ToList();KpiTotal.Text=filtrados.Count.ToString("N0");KpiFinal.Text=fin.Count.ToString("N0");KpiCurso.Text=filtrados.Count(x=>!x.FechaFin.HasValue).ToString("N0");KpiAgentes.Text=filtrados.Select(x=>x.Usuario).Distinct().Count().ToString();KpiDmt.Text=fin.Count==0?"—":TimeSpan.FromSeconds(fin.Average(x=>x.DmtSegundos??0)).ToString(@"hh\:mm\:ss");estadisticas=fin.GroupBy(x=>x.FechaInicio.Date).OrderBy(g=>g.Key).Select(g=>Stats(g.Key,g.ToList())).ToList();TablaStats.ItemsSource=estadisticas;Evolucion.ItemsSource=estadisticas;BarrasDecision.ItemsSource=Barras(fin.GroupBy(x=>x.Decision).Select(g=>new KeyValuePair<string,double>(g.Key,g.Count())));BarrasTaf.ItemsSource=Barras(fin.GroupBy(x=>x.Taf).Select(g=>new KeyValuePair<string,double>(g.Key,g.Count())));BarrasDmt.ItemsSource=Barras(fin.GroupBy(x=>x.Taf).Select(g=>new KeyValuePair<string,double>(g.Key,g.Average(x=>x.DmtSegundos??0))));}
private List<Barra> Barras(IEnumerable<KeyValuePair<string,double>> values){var a=values.OrderByDescending(x=>x.Value).Take(18).ToList();double max=a.Count==0?1:Math.Max(1,a.Max(x=>x.Value));return a.Select(x=>new Barra{Nombre=x.Key,Valor=x.Value.ToString("N0"),Anchura=Math.Max(2,x.Value/max*220)}).ToList();}
private EstadisticaDia Stats(DateTime date,List<Tratamiento> items){var z=new EstadisticaDia();z.Fecha=date.ToString("dd/MM/yyyy");z.Tratados=items.Count;z.SinInformacion=Count(items,"sin información para pre-estudio");z.RExBU=Count(items,"RExBU");z.RExB1=Count(items,"RExB1");z.RExIG=Count(items,"RExIG");z.RExRECIENTE=Count(items,"RExRECIENTE");z.RExNT=Count(items,"RExNT");z.RExPR=Count(items,"RExPR");z.RExVEDACON=Count(items,"RExVEDACON");z.RExFICHEROSNEG=Count(items,"RExFICHEROS NEG");z.RExTIPOCTTO=Count(items,"RExTIPO CTTO");z.RExSCORE=Count(items,"RExSCORE");z.RExRIESGO=Count(items,"RExRIESGO");z.RExLI=Count(items,"RExLI");z.RExAN=Count(items,"RExAN");z.RExBQ=Count(items,"RExBQ");int rej=decisiones.Skip(1).Sum(x=>Count(items,x));z.OkParaEstudio=items.Count-rej-z.SinInformacion;z.PorcentajeRechazo=items.Count==0?0:(double)rej/items.Count;return z;}
private int Count(List<Tratamiento> a,string d){return a.Count(x=>string.Equals(x.Decision,d,StringComparison.OrdinalIgnoreCase));}
private void Exportar(bool excel,bool stats){try{var dialog=new SaveFileDialog{Filter=excel?"Excel (*.xlsx)|*.xlsx":"CSV (*.csv)|*.csv",FileName=(stats?"estadisticas_":"consolidacion_")+DateTime.Now.ToString("yyyyMMdd")+(excel?".xlsx":".csv")};if(dialog.ShowDialog()!=true)return;var data=stats?estadisticas.Cast<object>().ToList():filtrados.Cast<object>().ToList();var props=(stats?typeof(EstadisticaDia):typeof(Tratamiento)).GetProperties().Where(p=>p.CanRead).ToArray();var lines=new List<string>();lines.Add(string.Join(";",props.Select(p=>p.Name)));foreach(var x in data)lines.Add(string.Join(";",props.Select(p=>"""+Convert.ToString(p.GetValue(x,null)).Replace(""","""")+""")));File.WriteAllLines(dialog.FileName,lines,Encoding.UTF8);EstadoTexto.Text="Exportado: "+dialog.FileName;}catch(Exception ex){MessageBox.Show(ex.Message);}}
private void Wire(){foreach(var b in Buttons("Actualizar_Click"))b.Click+=(s,e)=>Actualizar();foreach(var b in Buttons("Limpiar_Click"))b.Click+=(s,e)=>{inicializando=true;Desde.SelectedDate=null;Hasta.SelectedDate=null;Agente.SelectedItem="Todos";Taf.SelectedItem="Todos";Estado.SelectedItem="Todos";inicializando=false;Filtrar();};foreach(var b in Buttons("CsvDetalle_Click"))b.Click+=(s,e)=>Exportar(false,false);foreach(var b in Buttons("XlsxDetalle_Click"))b.Click+=(s,e)=>Exportar(true,false);foreach(var b in Buttons("CsvStats_Click"))b.Click+=(s,e)=>Exportar(false,true);foreach(var b in Buttons("XlsxStats_Click"))b.Click+=(s,e)=>Exportar(true,true);Desde.SelectedDateChanged+=(s,e)=>Filtrar();Hasta.SelectedDateChanged+=(s,e)=>Filtrar();Agente.SelectionChanged+=(s,e)=>Filtrar();Taf.SelectionChanged+=(s,e)=>Filtrar();Estado.SelectionChanged+=(s,e)=>Filtrar();}

}}