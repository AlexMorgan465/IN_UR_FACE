@echo off
cd /d "%~dp0"
if not exist "%~dp0Agent\bin\Cofidis-Espana-Agent.exe" (echo Compilez avec Compiler.cmd & pause & exit /b 1)
start "" "%~dp0Agent\bin\Cofidis-Espana-Agent.exe"
