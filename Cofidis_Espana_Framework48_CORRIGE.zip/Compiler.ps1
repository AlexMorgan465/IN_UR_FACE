﻿param([ValidateSet('Agent','Manager','Tous')][string]$Cible='Tous')
$ErrorActionPreference='Stop'
Set-Location $PSScriptRoot
function Locate-Csc {
 foreach($p in @("$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\csc.exe", "$env:WINDIR\Microsoft.NET\Framework\v4.0.30319\csc.exe")) {if(Test-Path $p){return $p}}
 throw 'csc.exe introuvable. Verifier .NET Framework 4.x.'
}
function Locate-Ref([string]$name,[string]$fx) {
 $file="$name.dll"
 $candidates=@(
  (Join-Path $fx $file),
  (Join-Path $fx "WPF\$file"),
  "$env:ProgramFiles (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\$file",
  "$env:ProgramFiles (x86)\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.8\Facades\$file",
  "$env:WINDIR\Microsoft.NET\assembly\GAC_MSIL\$name",
  "$env:WINDIR\Microsoft.NET\assembly\GAC_64\$name",
  "$env:WINDIR\assembly\GAC_MSIL\$name"
 )
 foreach($p in $candidates) {
  if(Test-Path $p -PathType Leaf){return $p}
  if(Test-Path $p -PathType Container){$hit=Get-ChildItem -LiteralPath $p -Filter $file -Recurse -File -ErrorAction SilentlyContinue | Select-Object -First 1;if($hit){return $hit.FullName}}
 }
 throw "Bibliotheque $file introuvable (Framework/GAC). Verifier l'activation du composant .NET Framework WPF."
}
try {
 $csc=Locate-Csc
 $fx=Split-Path $csc -Parent
 $names=@('mscorlib','System','System.Core','System.Xml','System.Web.Extensions','System.Xaml','Microsoft.CSharp','WindowsBase','PresentationCore','PresentationFramework')
 $refs=@();foreach($n in $names){$refs+=Locate-Ref $n $fx}
 Write-Host "Compilateur : $csc" -ForegroundColor Cyan
 $roles=if($Cible -eq 'Tous'){@('Agent','Manager')}else{@($Cible)}
 foreach($role in $roles){
  $dir=Join-Path $PSScriptRoot $role
  $out=Join-Path $dir 'bin'
  New-Item -ItemType Directory -Force -Path $out | Out-Null
  $exe=Join-Path $out "Cofidis-Espana-$role.exe"
  $argsC=@('/nologo','/target:winexe','/platform:anycpu','/optimize+','/langversion:5','/codepage:65001',"/out:$exe")
  foreach($r in $refs){$argsC+="/reference:$r"}
  $sources=@(Get-ChildItem -Path $dir -Filter '*.cs' -Recurse -File | Where-Object {$_.FullName -notmatch '[\\/](obj|bin)[\\/]'})
  if($sources.Count -eq 0){throw "Aucun fichier .cs pour $role"}
  $argsC+=@($sources | ForEach-Object {$_.FullName})
  Write-Host "Compilation $role ($($sources.Count) sources)..." -ForegroundColor Yellow
  & $csc @argsC
  if($LASTEXITCODE -ne 0){throw "Compilation $role echouee. Voir les erreurs C# ci-dessus."}
  Copy-Item (Join-Path $dir 'MainWindow.xaml') $out -Force
  if(!(Test-Path (Join-Path $out 'config.json'))){Copy-Item (Join-Path $dir 'config.json') $out -Force}
  Write-Host "OK : $exe" -ForegroundColor Green
 }
 Write-Host 'Compilation terminee.' -ForegroundColor Green
} catch {Write-Host "ERREUR : $($_.Exception.Message)" -ForegroundColor Red;exit 1}
