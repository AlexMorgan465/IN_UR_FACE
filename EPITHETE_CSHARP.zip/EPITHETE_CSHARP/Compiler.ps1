[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
try {
    $racineProjet = $PSScriptRoot
    if (-not [Environment]::Is64BitOperatingSystem) { throw 'Cette version cible Windows x64.' }
    $releaseFramework = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -ErrorAction Stop).Release
    if ($releaseFramework -lt 528040) { throw '.NET Framework 4.8 ou 4.8.1 est requis.' }
    $framework = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
    $csc = Join-Path $framework 'csc.exe'
    if (-not (Test-Path -LiteralPath $csc)) { throw 'Compilateur C# Windows introuvable.' }
    $wpf = Join-Path $framework 'WPF'
    $sortie = Join-Path $racineProjet 'bin'
    if (-not (Test-Path -LiteralPath $sortie)) { New-Item -ItemType Directory -Path $sortie | Out-Null }
    $references = @('System.dll','System.Core.dll','System.Numerics.dll','System.Xaml.dll','Microsoft.CSharp.dll') | ForEach-Object { Join-Path $framework $_ }
    $references += @('WindowsBase.dll','PresentationCore.dll','PresentationFramework.dll') | ForEach-Object { Join-Path $wpf $_ }
    $references += @('Microsoft.Web.WebView2.Core.dll','Microsoft.Web.WebView2.Wpf.dll','Newtonsoft.Json.dll') | ForEach-Object { Join-Path $racineProjet "lib\$_" }
    foreach ($reference in $references) { if (-not (Test-Path -LiteralPath $reference)) { throw "Reference manquante : $reference" } }
    foreach ($role in @('Agent','Manager')) {
        $exe = Join-Path $sortie "EPITHETE-$role.exe"
        $argsCompilation = @('/nologo','/target:winexe','/platform:x64','/optimize+','/langversion:5','/codepage:65001',"/out:$exe", "/win32manifest:$(Join-Path $racineProjet 'src\app.manifest')")
        if ($role -eq 'Manager') { $argsCompilation += '/define:MANAGER' }
        foreach ($reference in $references) { $argsCompilation += "/reference:$reference" }
        $uiDirectory = Join-Path $racineProjet ('ui\' + $role.ToLowerInvariant())
        foreach ($fichier in Get-ChildItem -LiteralPath $uiDirectory -File) {
            if ($fichier.Extension -in @('.html','.css','.js')) { $argsCompilation += "/resource:$($fichier.FullName),Epithete.UI.$($fichier.Name)" }
        }
        foreach ($source in Get-ChildItem -LiteralPath (Join-Path $racineProjet 'src') -Filter '*.cs' -File) { $argsCompilation += $source.FullName }
        & $csc @argsCompilation
        if ($LASTEXITCODE -ne 0) { throw "La compilation $role a echoue. Fermez les EXE ouverts avant de recompiler." }
        Copy-Item -LiteralPath (Join-Path $racineProjet 'src\app.config') -Destination ($exe + '.config') -Force
        Write-Host "Compile : $exe" -ForegroundColor Green
    }
    Get-ChildItem -LiteralPath (Join-Path $racineProjet 'lib') -Filter '*.dll' -File | Copy-Item -Destination $sortie -Force
    Write-Host 'Compilation terminee. Lancez Lancer-Agent.cmd ou Lancer-Manager.cmd.' -ForegroundColor Green
}
catch { Write-Host "ERREUR : $($_.Exception.Message)" -ForegroundColor Red; exit 1 }
